import type { CheckResult, CheckCategory, ScanInput } from '../../../types'

type Check = Omit<CheckResult, 'scoreImpact'>

function check(partial: Check): Check { return partial }

export function analyzeHttps(input: ScanInput): Omit<CheckResult, 'scoreImpact'>[] {
  const checks: Check[] = []
  const final = (() => { try { return new URL(input.finalUrl) } catch { return null } })()

  if (!final) {
    checks.push(check({
      checkId: 'https.invalid-final-url', module: 'https', category: 'https', severity: 'info', status: 'info',
      title: 'Unable to determine final URL',
      evidence: 'The scanner could not determine the final URL of the website.',
      description: 'URL resolution could not be verified in this scan.',
      impact: 'No direct impact can be assessed without URL data.',
      recommendation: 'Re-run the scan. If the problem persists, verify the website is reachable.',
      remediation: 'N/A',
    }))
    return checks
  }

  const isHttps = final.protocol === 'https:'
  checks.push(check({
    checkId: 'https.enabled', module: 'https', category: 'https',
    severity: isHttps ? 'passed' : 'critical',
    status: isHttps ? 'pass' : 'fail',
    title: isHttps ? 'HTTPS is enabled' : 'HTTPS is not enabled',
    evidence: isHttps
      ? `The website responds over HTTPS (final URL: ${input.finalUrl}).`
      : `The website responds over plain HTTP (final URL: ${input.finalUrl}).`,
    description: isHttps
      ? 'Traffic between visitors and the website is encrypted in transit.'
      : 'The website is served over unencrypted HTTP. Data transmitted between visitors and the site can be read or modified by anyone on the network path.',
    impact: isHttps
      ? 'Protects confidentiality and integrity of data in transit.'
      : 'Critical: login credentials, session tokens and personal data can be intercepted. Browsers also label HTTP sites as "Not Secure", damaging trust.',
    recommendation: isHttps
      ? 'No action required. Keep certificates valid and renew them before expiry.'
      : 'Obtain a TLS certificate (e.g. Let\u2019s Encrypt) and serve the entire site over HTTPS.',
    remediation: isHttps
      ? 'N/A'
      : 'Install a certificate, redirect all HTTP traffic to HTTPS with a 301, and enable HSTS once stable.',
  }))

  const original = (() => { try { return new URL(input.url) } catch { return null } })()
  if (original && original.protocol === 'http:' && isHttps) {
    checks.push(check({
      checkId: 'https.redirect', module: 'https', category: 'https', severity: 'passed', status: 'pass',
      title: 'HTTP redirects to HTTPS',
      evidence: `Requesting ${input.url} redirected to ${input.finalUrl}.`,
      description: 'Visitors typing the HTTP address are automatically redirected to the encrypted version.',
      impact: 'Prevents accidental unencrypted connections.',
      recommendation: 'No action required.',
      remediation: 'N/A',
    }))
  }

  const hsts = input.headers['strict-transport-security']
  if (isHttps && !hsts) {
    checks.push(check({
      checkId: 'https.hsts', module: 'https', category: 'https', severity: 'high', status: 'fail',
      title: 'HTTP Strict Transport Security (HSTS) is not configured',
      evidence: 'The Strict-Transport-Security header was not detected in the response.',
      description: 'Without HSTS, browsers have no instruction to always use HTTPS, so a first visit over HTTP (or an attacker stripping the redirect) can remain unencrypted.',
      impact: 'High: connections can be downgraded to HTTP (SSL-stripping attacks), and visitors gain no protection from HSTS preload lists.',
      recommendation: 'Enable HSTS with a long max-age once HTTPS works correctly for the whole site and all subdomains.',
      remediation: 'Strict-Transport-Security: max-age=31536000; includeSubDomains; preload — then submit to hstspreload.org.',
    }))
  } else if (isHttps && hsts) {
    checks.push(check({
      checkId: 'https.hsts', module: 'https', category: 'https', severity: 'passed', status: 'pass',
      title: 'HSTS is configured',
      evidence: `Strict-Transport-Security: ${hsts}`,
      description: 'Browsers are instructed to always connect over HTTPS for this domain.',
      impact: 'Protects against protocol downgrade and cookie theft over HTTP.',
      recommendation: 'Keep max-age high and renew before expiry.',
      remediation: 'N/A',
    }))
  }
  return checks
}
