import { useI18n } from '../lib/i18n'
import { severityColor } from '../lib/severity'
import type { Severity } from '../types'

const KEY: Record<Severity, string> = {
  critical: 'common.critical', high: 'common.high', medium: 'common.medium',
  low: 'common.low', passed: 'common.passed', info: 'common.info',
}

export function SeverityBadge({ severity }: { severity: Severity }) {
  const { t } = useI18n()
  return <span className={`badge ${severityColor[severity]}`}>{t(KEY[severity])}</span>
}
