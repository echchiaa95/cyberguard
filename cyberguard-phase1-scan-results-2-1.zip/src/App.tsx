import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom'
import { AuthProvider } from './lib/auth'
import { I18nProvider } from './lib/i18n'
import { ProtectedRoute } from './components/ProtectedRoute'
import { Layout } from './components/Layout'
import { Landing } from './pages/Landing'
import { Login, Signup, ForgotPassword, ResetPassword } from './pages/auth'
import { Dashboard } from './pages/Dashboard'
import { Websites, WebsiteDetail } from './pages/Websites'
import { ScanResults } from './pages/ScanResults'
import { History } from './pages/History'
import { Applications, Files, Monitoring, Reports, Advisor } from './pages/Prepared'
import { Pricing, Settings, Account } from './pages/Meta'

export default function App() {
  // Must mirror vite.config.ts `base` so nested routes work on GitHub Pages
  // project sites (e.g. /<repo>/app/websites) including refresh/deep links.
  const basename = import.meta.env.VITE_BASE_PATH || '/'
  return (
    <I18nProvider>
      <AuthProvider>
        <BrowserRouter basename={basename}>
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route element={<ProtectedRoute><Layout /></ProtectedRoute>}>
              <Route path="/app" element={<Dashboard />} />
              <Route path="/app/websites" element={<Websites />} />
              <Route path="/app/websites/:id" element={<WebsiteDetail />} />
              <Route path="/app/scans/:scanId" element={<ScanResults />} />
              <Route path="/app/applications" element={<Applications />} />
              <Route path="/app/files" element={<Files />} />
              <Route path="/app/reports" element={<Reports />} />
              <Route path="/app/monitoring" element={<Monitoring />} />
              <Route path="/app/history" element={<History />} />
              <Route path="/app/advisor" element={<Advisor />} />
              <Route path="/app/pricing" element={<Pricing />} />
              <Route path="/app/account" element={<Account />} />
              <Route path="/app/settings" element={<Settings />} />
            </Route>
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </I18nProvider>
  )
}
