export { }
// Shared scanner types are defined in ../../types (ScanInput, CheckResult, ScanOutput).
// Each module in ./modules receives a ScanInput and returns CheckResult[].
