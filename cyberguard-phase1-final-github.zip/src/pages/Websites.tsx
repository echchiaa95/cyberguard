import { FormEvent, useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import { useI18n } from '../lib/i18n'
import { EmptyState } from '../components/EmptyState'
import { SeverityBadge } from '../components/SeverityBadge'
import { normalizeUrl } from '../lib/utils'
import { addWebsite, createScanRecord, deleteWebsite, failScanRecord, listScans, listWebsites, saveScanResult } from '../services/db'
import { runWebsiteScan, type ScanProgressStep } from '../services/scanner'
import type { ScanRecord, Website } from '../types'

const STEPS: ScanProgressStep[] = ['fetch', 'headers', 'cookies', 'privacy', 'scoring']

export function Websites() {
  const { user } = useAuth()
  const { t } = useI18n()
  const [sites, setSites] = useState<Website[]>([])
  const [error, setError] = useState<string | null>(null)

  const load = async () => { if (user) setSites(await listWebsites(user.id)) }
  useEffect(() => { void load() }, [user])

  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setError(null)
    const raw = String(new FormData(e.currentTarget).get('url'))
    const normalized = normalizeUrl(raw)
    if (!normalized) {
      setError(t('sites.invalidUrl'))
      return
    }
    await addWebsite(user!.id, raw.trim(), normalized)
    e.currentTarget.reset()
    await load()
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">{t('sites.title')}</h1>
      <form onSubmit={submit} className="card flex flex-col gap-3 p-4 sm:flex-row">
        <input name="url" className="input flex-1" placeholder={t('sites.urlPlaceholder')} />
        <button className="btn-primary">{t('sites.add')}</button>
      </form>
      {error && <p role="alert" className="text-sm text-sev-critical">{error}</p>}
      {sites.length === 0 ? (
        <EmptyState title={t('common.noData')} hint={t('sites.urlPlaceholder')} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {sites.map((w) => (
            <WebsiteCard key={w.id} site={w} onDelete={async () => {
              if (window.confirm(t('sites.deleteConfirm'))) {
                await deleteWebsite(user!.id, w.id)
                await load()
              }
            }} />
          ))}
        </div>
      )}
    </div>
  )
}

function WebsiteCard({ site, onDelete }: { site: Website; onDelete: () => void }) {
  const { t, lang } = useI18n()
  const { user } = useAuth()
  const [last, setLast] = useState<ScanRecord | null>(null)
  useEffect(() => {
    void listScans(user!.id, site.id).then((s) => setLast(s.find((x) => x.status === 'completed') ?? null))
  }, [user, site.id])

  return (
    <div className="card flex flex-col p-5">
      <Link to={`/app/websites/${site.id}`} className="truncate font-medium text-brand-400 hover:underline">{site.url}</Link>
      <p className="mt-1 text-xs text-slate-500">
        {t('sites.lastScan')}: {last ? new Date(last.createdAt).toLocaleDateString(lang) : t('sites.never')}
      </p>
      <div className="mt-3 flex items-center gap-2">
        {last?.securityScore !== undefined && <b className="text-slate-100">{last.securityScore}</b>}
        {last?.riskLevel && <SeverityBadge severity={last.riskLevel} />}
      </div>
      <div className="mt-4 flex gap-2">
        <Link to={`/app/websites/${site.id}`} className="btn-secondary flex-1 !py-1.5 text-xs">{t('scan.new')}</Link>
        <button onClick={onDelete} className="btn-secondary !py-1.5 text-xs text-sev-critical">{t('common.delete')}</button>
      </div>
    </div>
  )
}

export function WebsiteDetail() {
  const { id } = useParams()
  const { user } = useAuth()
  const { t, lang } = useI18n()
  const nav = useNavigate()
  const [site, setSite] = useState<Website | null>(null)
  const [scans, setScans] = useState<ScanRecord[]>([])
  const [running, setRunning] = useState(false)
  const [step, setStep] = useState<ScanProgressStep>('fetch')
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    void (async () => {
      if (!user || !id) return
      const sites = await listWebsites(user.id)
      setSite(sites.find((w) => w.id === id) ?? null)
      setScans(await listScans(user.id, id))
    })()
  }, [user, id])

  const startScan = async () => {
    if (!user || !site) return
    setRunning(true)
    setError(null)
    setStep('fetch')
    const scanId = await createScanRecord(user.id, site.id, site.normalizedUrl)
    try {
      const output = await runWebsiteScan(site.normalizedUrl, setStep)
      await saveScanResult(user.id, scanId, output)
      setScans(await listScans(user.id, site.id))
      nav(`/app/scans/${scanId}`)
    } catch (e) {
      const key = (e as { messageKey?: string }).messageKey ?? 'error.scanUnavailable'
      await failScanRecord(user.id, scanId, key)
      setError(t(key))
      setScans(await listScans(user.id, site.id))
    } finally {
      setRunning(false)
    }
  }

  if (!site) return <p className="text-slate-400">{t('common.loading')}</p>

  return (
    <div className="space-y-6">
      <div>
        <Link to="/app/websites" className="text-sm text-brand-400">← {t('common.back')}</Link>
        <h1 className="mt-2 break-all text-2xl font-bold text-white">{site.url}</h1>
      </div>

      <div className="card p-6">
        <button className="btn-primary" onClick={startScan} disabled={running}>
          {running ? t('scan.running') : t('scan.new')}
        </button>
        <p className="mt-2 text-xs text-slate-500">{t('scan.stepsNote')}</p>
        {error && <p role="alert" className="mt-3 text-sm text-sev-critical">{error}</p>}
        {running && (
          <ol className="mt-4 space-y-2 text-sm">
            {STEPS.map((s, i) => {
              const active = STEPS.indexOf(step)
              return (
                <li key={s} className={i <= active ? 'text-brand-400' : 'text-slate-600'}>
                  {i < active ? '✓' : i === active ? '●' : '○'} {t(`scan.step.${s}`)}
                </li>
              )
            })}
          </ol>
        )}
      </div>

      <div className="card p-6">
        <h2 className="mb-4 font-semibold text-slate-100">{t('dash.recentScans')}</h2>
        <ul className="divide-y divide-surface-800">
          {scans.map((s) => (
            <li key={s.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
              <span className="text-sm text-slate-400">{new Date(s.createdAt).toLocaleString(lang)}</span>
              <div className="flex items-center gap-3">
                {s.status === 'completed' && s.securityScore !== undefined && (
                  <>
                    <b className="text-slate-100">{s.securityScore}</b>
                    {s.riskLevel && <SeverityBadge severity={s.riskLevel} />}
                  </>
                )}
                {s.status === 'failed' && <span className="text-sm text-sev-critical">{t('scan.failed')}</span>}
                {s.status !== 'running' && (
                  <Link to={`/app/scans/${s.id}`} className="text-sm text-brand-400 hover:underline">{t('common.view')}</Link>
                )}
              </div>
            </li>
          ))}
          {scans.length === 0 && <p className="text-sm text-slate-500">{t('common.noData')}</p>}
        </ul>
      </div>
    </div>
  )
}
