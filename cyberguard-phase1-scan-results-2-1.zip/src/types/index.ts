export type Language = 'en' | 'fr' | 'ar'

export type Severity = 'critical' | 'high' | 'medium' | 'low' | 'passed' | 'info'
export type CheckStatus = 'fail' | 'warn' | 'pass' | 'info'
export type RiskLevel = 'critical' | 'high' | 'medium' | 'low'

export type CheckCategory =
  | 'https' | 'headers' | 'cookies' | 'dns'
  | 'privacy' | 'trackers' | 'exposure' | 'web'

export interface CheckResult {
  checkId: string
  module: string
  category: CheckCategory
  severity: Severity
  status: CheckStatus
  title: string
  evidence: string
  description: string
  impact: string
  recommendation: string
  remediation: string
  /** Deterministic points deducted from the relevant score when this check is not passed. */
  scoreImpact: number
}

export interface ScanInput {
  url: string
  finalUrl: string
  status: number
  headers: Record<string, string>
  cookies: string[]
  resources: {
    scripts: string[]
    iframes: string[]
    images: string[]
    styles: string[]
    preconnects: string[]
    pixels: string[]
  }
  generator: string | null
  htmlLength: number
  dns: Record<string, unknown>
  scannedAt: string
}

export interface ScanSummary {
  critical: number
  high: number
  medium: number
  low: number
  passed: number
  info: number
}

export interface ScanOutput {
  scanId?: string
  target: string
  scannedAt: string
  isDemo: boolean
  securityScore: number
  privacyScore: number
  riskLevel: RiskLevel
  summary: ScanSummary
  checks: CheckResult[]
  priorityFixes: { checkId: string; title: string; severity: Severity; estimatedImprovement: number }[]
}

export interface Website {
  id: string
  url: string
  normalizedUrl: string
  name?: string
  createdAt: string
}

export interface ScanRecord {
  id: string
  websiteId?: string
  target: string
  status: 'pending' | 'running' | 'completed' | 'failed'
  securityScore?: number
  privacyScore?: number
  riskLevel?: RiskLevel
  findingsCount: number
  passedCount: number
  errorMessage?: string
  createdAt: string
  completedAt?: string
}

export interface HistoryPoint {
  scanId?: string
  target: string
  securityScore: number
  privacyScore?: number
  findingsCount: number
  recordedAt: string
}

export interface Profile {
  id: string
  email: string
  fullName?: string
  preferredLanguage: Language
}
