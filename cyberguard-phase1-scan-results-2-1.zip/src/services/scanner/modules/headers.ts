import type { CheckResult, CheckCategory, ScanInput } from '../../../types'

type Check = Omit<CheckResult, 'scoreImpact'>

function check(partial: Check): Check { return partial }

export function analyzeHeaders(input: ScanInput): Omit<CheckResult, 'scoreImpact'>[] {
  const h = input.headers
  const checks: Check[] = []

  const csp = h['content-security-policy']
  if (!csp) {
    checks.push(check({
      checkId: 'headers.csp', module: 'headers', category: 'headers', severity: 'high', status: 'fail',
      title: 'Missing Content Security Policy',
      evidence: 'The Content-Security-Policy header was not detected.',
      description: 'A Content Security Policy (CSP) tells browsers which sources of scripts, styles and other content are allowed, limiting the impact of cross-site scripting (XSS).',
      impact: 'High: if an XSS vulnerability exists, attackers can load arbitrary scripts and steal sessions or deface pages.',
      recommendation: 'Start with a report-only policy, then enforce a restrictive policy.',
      remediation: "Content-Security-Policy: default-src 'self'; script-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'",
    }))
  } else if (/\b(unsafe-inline|unsafe-eval)\b/.test(csp)) {
    checks.push(check({
      checkId: 'headers.csp-unsafe', module: 'headers', category: 'headers', severity: 'medium', status: 'warn',
      title: 'CSP allows unsafe-inline or unsafe-eval',
      evidence: `Content-Security-Policy: ${csp.slice(0, 300)}`,
      description: 'The policy contains unsafe-inline or unsafe-eval, which significantly weakens CSP protection against XSS.',
      impact: 'Medium: injected inline scripts may still execute.',
      recommendation: 'Move inline scripts to external files and use nonces or hashes.',
      remediation: "Replace 'unsafe-inline' with 'nonce-{random}' per response.",
    }))
  } else {
    checks.push(check({
      checkId: 'headers.csp', module: 'headers', category: 'headers', severity: 'passed', status: 'pass',
      title: 'Content Security Policy is configured',
      evidence: `Content-Security-Policy: ${csp.slice(0, 300)}`,
      description: 'A restrictive-looking CSP was detected.',
      impact: 'Reduces the impact of cross-site scripting.',
      recommendation: 'Keep the policy strict and monitor violations.',
      remediation: 'N/A',
    }))
  }

  const frameAncestors = csp?.match(/frame-ancestors\s+([^;]+)/i)?.[1]
  const xfo = h['x-frame-options']
  if (!frameAncestors && !xfo) {
    checks.push(check({
      checkId: 'headers.clickjacking', module: 'headers', category: 'headers', severity: 'medium', status: 'fail',
      title: 'Clickjacking protection is not configured',
      evidence: 'Neither the frame-ancestors CSP directive nor the X-Frame-Options header was detected.',
      description: 'Without frame restrictions, the site can be embedded in a malicious page that tricks visitors into clicking hidden elements.',
      impact: 'Medium: attackers can perform actions on behalf of logged-in users (clickjacking).',
      recommendation: 'Restrict which origins may frame the site.',
      remediation: "Add frame-ancestors 'self' (or 'none') to the CSP, or X-Frame-Options: DENY / SAMEORIGIN.",
    }))
  } else {
    checks.push(check({
      checkId: 'headers.clickjacking', module: 'headers', category: 'headers', severity: 'passed', status: 'pass',
      title: 'Clickjacking protection is configured',
      evidence: frameAncestors ? `frame-ancestors ${frameAncestors}` : `X-Frame-Options: ${xfo}`,
      description: 'Framing of the page is restricted.',
      impact: 'Prevents clickjacking attacks.',
      recommendation: 'No action required.',
      remediation: 'N/A',
    }))
  }

  const xcto = h['x-content-type-options']
  checks.push(xcto?.toLowerCase() === 'nosniff'
    ? check({
      checkId: 'headers.xcto', module: 'headers', category: 'headers', severity: 'passed', status: 'pass',
      title: 'MIME-sniffing protection is enabled',
      evidence: 'X-Content-Type-Options: nosniff',
      description: 'Browsers are told not to guess content types, preventing certain script-injection attacks.',
      impact: 'Reduces drive-by download and MIME-confusion risk.',
      recommendation: 'No action required.', remediation: 'N/A',
    })
    : check({
      checkId: 'headers.xcto', module: 'headers', category: 'headers', severity: 'low', status: 'fail',
      title: 'MIME-sniffing protection is missing',
      evidence: 'The X-Content-Type-Options header was not detected.',
      description: 'Without nosniff, browsers may reinterpret files as a different content type.',
      impact: 'Low: can enable content-type confusion attacks in older browsers.',
      recommendation: 'Send X-Content-Type-Options: nosniff on all responses.',
      remediation: 'X-Content-Type-Options: nosniff',
    }))

  const rp = h['referrer-policy']
  checks.push(rp
    ? check({
      checkId: 'headers.referrer', module: 'headers', category: 'headers', severity: 'passed', status: 'pass',
      title: 'Referrer Policy is configured',
      evidence: `Referrer-Policy: ${rp}`,
      description: 'Controls how much URL information is sent to third parties when visitors follow links.',
      impact: 'Limits leakage of URLs that may contain sensitive parameters.',
      recommendation: 'Use strict-origin-when-cross-origin or stricter.',
      remediation: 'N/A',
    })
    : check({
      checkId: 'headers.referrer', module: 'headers', category: 'headers', severity: 'low', status: 'fail',
      title: 'Referrer Policy is missing',
      evidence: 'The Referrer-Policy header was not detected.',
      description: 'Browsers use the default referrer behavior, which may leak full URLs (including query parameters) to third parties.',
      impact: 'Low: potential privacy leakage via referrer headers.',
      recommendation: 'Send Referrer-Policy: strict-origin-when-cross-origin.',
      remediation: 'Referrer-Policy: strict-origin-when-cross-origin',
    }))

  const pp = h['permissions-policy']
  checks.push(pp
    ? check({
      checkId: 'headers.permissions', module: 'headers', category: 'headers', severity: 'passed', status: 'pass',
      title: 'Permissions Policy is configured',
      evidence: `Permissions-Policy: ${pp.slice(0, 200)}`,
      description: 'Restricts access to powerful browser features.',
      impact: 'Reduces abuse surface of sensitive APIs.',
      recommendation: 'Review allowed features regularly.', remediation: 'N/A',
    })
    : check({
      checkId: 'headers.permissions', module: 'headers', category: 'headers', severity: 'info', status: 'info',
      title: 'Permissions Policy not detected',
      evidence: 'The Permissions-Policy header was not detected.',
      description: 'No explicit restrictions on browser features (camera, microphone, geolocation, etc.) were found.',
      impact: 'Informational: by default all features remain available to scripts.',
      recommendation: 'Consider sending a restrictive Permissions-Policy.',
      remediation: 'Permissions-Policy: camera=(), microphone=(), geolocation=()',
    }))

  return checks
}
