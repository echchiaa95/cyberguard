import type { CheckResult, CheckCategory, ScanInput } from '../../../types'

type Check = Omit<CheckResult, 'scoreImpact'>

function check(partial: Check): Check { return partial }

function parseCookie(c: string) {
  const parts = c.split(';').map((s) => s.trim())
  const [pair] = parts
  const name = pair.split('=')[0]?.trim() ?? ''
  const attrs: Record<string, string | true> = {}
  for (const p of parts.slice(1)) {
    const [k, v] = p.split('=')
    attrs[k.toLowerCase()] = v ?? true
  }
  return { name, attrs }
}

export function analyzeCookies(input: ScanInput): Omit<CheckResult, 'scoreImpact'>[] {
  const cookies = input.cookies ?? []
  const checks: Check[] = []

  if (cookies.length === 0) {
    checks.push(check({
      checkId: 'cookies.none', module: 'cookies', category: 'cookies', severity: 'info', status: 'info',
      title: 'No cookies detected in the response',
      evidence: 'No Set-Cookie header was observed during this scan.',
      description: 'The initial page response did not set any cookies. Cookies may still appear after interaction or login.',
      impact: 'Informational only.',
      recommendation: 'None.',
      remediation: 'N/A',
    }))
    return checks
  }

  const missingSecure = cookies.filter((c) => !('secure' in parseCookie(c).attrs))
  checks.push(missingSecure.length === 0
    ? check({
      checkId: 'cookies.secure', module: 'cookies', category: 'cookies', severity: 'passed', status: 'pass',
      title: 'All cookies use the Secure flag',
      evidence: `${cookies.length} cookie(s) observed, all with the Secure attribute.`,
      description: 'Secure cookies are only sent over HTTPS connections.',
      impact: 'Prevents cookie theft over unencrypted connections.',
      recommendation: 'No action required.', remediation: 'N/A',
    })
    : check({
      checkId: 'cookies.secure', module: 'cookies', category: 'cookies', severity: 'high', status: 'fail',
      title: 'Cookies missing the Secure flag',
      evidence: `Cookie(s) without Secure: ${missingSecure.map((c) => parseCookie(c).name).join(', ')}`,
      description: 'These cookies may be transmitted over unencrypted HTTP connections.',
      impact: 'High: session cookies sent over HTTP can be intercepted and used to hijack accounts.',
      recommendation: 'Set the Secure attribute on every cookie, and enforce HTTPS site-wide.',
      remediation: 'Set-Cookie: name=value; Secure; HttpOnly; SameSite=Lax',
    }))

  const sessionish = cookies.filter((c) => /sess|auth|token|sid|login/i.test(parseCookie(c).name))
  const missingHttpOnly = sessionish.filter((c) => !('httponly' in parseCookie(c).attrs))
  checks.push(missingHttpOnly.length === 0
    ? check({
      checkId: 'cookies.httponly', module: 'cookies', category: 'cookies', severity: 'passed', status: 'pass',
      title: 'Session cookies use HttpOnly',
      evidence: sessionish.length ? `Session-like cookie(s) all carry HttpOnly: ${sessionish.map((c) => parseCookie(c).name).join(', ')}` : 'No session-like cookies observed.',
      description: 'HttpOnly cookies cannot be read by JavaScript, blocking the most common session-theft vector.',
      impact: 'Reduces impact of cross-site scripting.',
      recommendation: 'No action required.', remediation: 'N/A',
    })
    : check({
      checkId: 'cookies.httponly', module: 'cookies', category: 'cookies', severity: 'medium', status: 'fail',
      title: 'Session cookies accessible to JavaScript',
      evidence: `Cookie(s) without HttpOnly: ${missingHttpOnly.map((c) => parseCookie(c).name).join(', ')}`,
      description: 'JavaScript running on the page can read these session cookies.',
      impact: 'Medium: a single XSS flaw would allow session hijacking.',
      recommendation: 'Add the HttpOnly attribute to all authentication/session cookies.',
      remediation: 'Set-Cookie: name=value; HttpOnly; Secure; SameSite=Lax',
    }))

  const missingSameSite = cookies.filter((c) => !('samesite' in parseCookie(c).attrs))
  checks.push(missingSameSite.length === 0
    ? check({
      checkId: 'cookies.samesite', module: 'cookies', category: 'cookies', severity: 'passed', status: 'pass',
      title: 'All cookies declare SameSite',
      evidence: 'Every observed cookie has a SameSite attribute.',
      description: 'SameSite restricts when cookies are sent on cross-site requests, mitigating CSRF.',
      impact: 'Reduces cross-site request forgery risk.',
      recommendation: 'No action required.', remediation: 'N/A',
    })
    : check({
      checkId: 'cookies.samesite', module: 'cookies', category: 'cookies', severity: 'low', status: 'fail',
      title: 'Cookies missing SameSite',
      evidence: `Cookie(s) without SameSite: ${missingSameSite.map((c) => parseCookie(c).name).join(', ')}`,
      description: 'Without SameSite, browsers apply legacy behavior and cookies are sent on all cross-site requests.',
      impact: 'Low: increases CSRF exposure.',
      recommendation: 'Add SameSite=Lax (or None only where genuinely required, always with Secure).',
      remediation: 'Set-Cookie: name=value; SameSite=Lax',
    }))

  const crossSite = cookies.filter((c) => {
    const a = parseCookie(c).attrs
    return typeof a['samesite'] === 'string' && a['samesite'].toLowerCase() === 'none'
  })
  if (crossSite.length > 0) {
    checks.push(check({
      checkId: 'cookies.crosssite', module: 'cookies', category: 'cookies', severity: 'low', status: 'warn',
      title: 'Third-party data sharing indicator: cross-site cookies',
      evidence: `Cookie(s) with SameSite=None: ${crossSite.map((c) => parseCookie(c).name).join(', ')}`,
      description: 'SameSite=None cookies are intended for cross-site contexts and may be shared with or readable by third parties. This is an observed indicator, not proof of data sharing.',
      impact: 'Low: potential privacy risk depending on which third parties can read these cookies.',
      recommendation: 'Verify these cookies are required and shared only with intended partners.',
      remediation: 'Restrict SameSite=None cookies to the minimum set of domains that need them.',
    }))
  }

  return checks
}
