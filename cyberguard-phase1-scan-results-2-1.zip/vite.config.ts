import { defineConfig, type Plugin } from 'vite'
import react from '@vitejs/plugin-react'
import fs from 'node:fs'
import path from 'node:path'

// Injects the configured base path into the copied public/404.html so the
// GitHub Pages SPA fallback redirects to /<repo>/?p=... on project sites.
function injectBaseInto404(base: string): Plugin {
  return {
    name: 'cyberguard-inject-base-404',
    closeBundle() {
      const file = path.resolve(process.cwd(), 'dist/404.html')
      if (fs.existsSync(file)) {
        const html = fs.readFileSync(file, 'utf8')
        fs.writeFileSync(file, html.split('__BASE_PATH__').join(base))
      }
    },
  }
}

export default defineConfig(() => {
  // GitHub Pages project sites are served under /<repo>/; set VITE_BASE_PATH
  // in .env (e.g. '/my-cyberguard/') or leave '/' for a user/org site or dev.
  const base = process.env.VITE_BASE_PATH || '/'
  return {
    plugins: [react(), injectBaseInto404(base)],
    base,
    build: {
      outDir: 'dist',
      sourcemap: false,
    },
  }
})
