import type { CheckResult, CheckCategory, ScanInput } from '../../../types'

type Check = Omit<CheckResult, 'scoreImpact'>

function check(partial: Check): Check { return partial }

export function analyzeExposure(input: ScanInput): Omit<CheckResult, 'scoreImpact'>[] {
  const checks: Check[] = []
  const h = input.headers

  const server = h['server']
  checks.push(server
    ? check({
      checkId: 'exposure.server-header', module: 'exposure', category: 'exposure', severity: 'info', status: 'info',
      title: 'Technology exposure: Server header reveals software',
      evidence: `Server: ${server}`,
      description: 'The Server response header discloses the web server software, which helps attackers choose targeted techniques. This is an observed indicator, not a vulnerability by itself.',
      impact: 'Informational: minor information disclosure.',
      recommendation: 'Reduce banner detail where practical (note: obscurity is not a fix by itself — keep software patched).',
      remediation: 'server_tokens off; (nginx) or ServerTokens Prod (Apache).',
    })
    : check({
      checkId: 'exposure.server-header', module: 'exposure', category: 'exposure', severity: 'passed', status: 'pass',
      title: 'Server header does not reveal software details',
      evidence: 'No Server header value with software details was detected.',
      description: 'The server does not advertise its software stack.',
      impact: 'Slightly reduces information available to attackers.',
      recommendation: 'No action required.', remediation: 'N/A',
    }))

  const xpb = h['x-powered-by']
  if (xpb) {
    checks.push(check({
      checkId: 'exposure.x-powered-by', module: 'exposure', category: 'exposure', severity: 'info', status: 'info',
      title: 'Technology exposure: X-Powered-By header present',
      evidence: `X-Powered-By: ${xpb}`,
      description: 'This header discloses the underlying framework or language.',
      impact: 'Informational: minor information disclosure.',
      recommendation: 'Remove this header; it provides no benefit to visitors.',
      remediation: 'Disable at framework level (e.g. app.disable(\'x-powered-by\') in Express).',
    }))
  }

  if (input.generator) {
    checks.push(check({
      checkId: 'exposure.generator', module: 'exposure', category: 'exposure', severity: 'low', status: 'warn',
      title: 'Information exposure: generator meta tag',
      evidence: `<meta name="generator" content="${input.generator}">`,
      description: 'The page discloses the CMS and often its version, which helps attackers look up known vulnerabilities for that version.',
      impact: 'Low: helps attackers target known CMS vulnerabilities.',
      recommendation: 'Remove the generator meta tag and keep the CMS updated.',
      remediation: 'Remove the tag from templates; enable automatic core updates.',
    }))
  } else {
    checks.push(check({
      checkId: 'exposure.generator', module: 'exposure', category: 'exposure', severity: 'passed', status: 'pass',
      title: 'No generator meta tag detected',
      evidence: 'No <meta name="generator"> tag was found in the analyzed HTML.',
      description: 'The page does not advertise its CMS.',
      impact: 'Reduces version-based targeting.',
      recommendation: 'No action required.', remediation: 'N/A',
    }))
  }

  return checks
}
