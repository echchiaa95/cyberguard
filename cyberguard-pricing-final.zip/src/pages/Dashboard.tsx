import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import { useI18n } from '../lib/i18n'
import { ScoreRing } from '../components/ScoreRing'
import { SeverityBadge } from '../components/SeverityBadge'
import { EmptyState } from '../components/EmptyState'
import { getScanChecks, listHistory, listScans, listWebsites } from '../services/db'
import type { CheckResult, HistoryPoint, ScanRecord, Website } from '../types'

interface SitePosture {
  website: Website
  scan?: ScanRecord
  previous?: ScanRecord
}

export function Dashboard() {
  const { user } = useAuth()
  const { t, lang } = useI18n()
  const [websites, setWebsites] = useState<Website[]>([])
  const [scans, setScans] = useState<ScanRecord[]>([])
  const [history, setHistory] = useState<HistoryPoint[]>([])
  const [fixes, setFixes] = useState<Array<CheckResult & { target: string; scanId: string }>>([])
  const [loaded, setLoaded] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!user) return
    let cancelled = false
    void (async () => {
      try {
        const [w, s, h] = await Promise.all([
          listWebsites(user.id),
          listScans(user.id),
          listHistory(user.id),
        ])
        if (cancelled) return
        setWebsites(w)
        setScans(s)
        setHistory(h)

        const latestCompleted = s.filter((x) => x.status === 'completed' && x.securityScore !== undefined)
        const checksByScan = await Promise.all(
          latestCompleted.slice(0, 12).map(async (scan) => ({
            scan,
            checks: await getScanChecks(user.id, scan.id),
          })),
        )
        if (cancelled) return
        const topFixes = checksByScan.flatMap(({ scan, checks }) =>
          checks
            .filter((c) => c.status !== 'pass' && c.scoreImpact > 0 && c.severity !== 'info')
            .map((c) => ({ ...c, target: scan.target, scanId: scan.id })),
        )
          .sort((a, b) => b.scoreImpact - a.scoreImpact)
          .slice(0, 5)
        setFixes(topFixes)
        setError(null)
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : 'Unable to load dashboard')
      } finally {
        if (!cancelled) setLoaded(true)
      }
    })()
    return () => { cancelled = true }
  }, [user])

  const posture = useMemo<SitePosture[]>(() => websites.map((website) => {
    const siteScans = scans.filter((s) => s.websiteId === website.id || (!s.websiteId && s.target === website.url))
      .filter((s) => s.status === 'completed' && s.securityScore !== undefined)
    return { website, scan: siteScans[0], previous: siteScans[1] }
  }), [websites, scans])

  const scannedPosture = posture.filter((p) => p.scan)
  const averageSecurity = scannedPosture.length
    ? Math.round(scannedPosture.reduce((sum, p) => sum + (p.scan!.securityScore ?? 0), 0) / scannedPosture.length)
    : 0
  const averagePrivacy = scannedPosture.length
    ? Math.round(scannedPosture.reduce((sum, p) => sum + (p.scan!.privacyScore ?? 0), 0) / scannedPosture.length)
    : 0

  const monthStart = new Date()
  monthStart.setDate(1)
  monthStart.setHours(0, 0, 0, 0)
  const scansThisMonth = scans.filter((s) => new Date(s.createdAt) >= monthStart).length
  const attention = scannedPosture.reduce((sum, p) => sum + ((p.scan?.riskLevel === 'critical' || p.scan?.riskLevel === 'high') ? 1 : 0), 0)
  const openFindings = scannedPosture.reduce((sum, p) => sum + (p.scan?.findingsCount ?? 0), 0)

  const dailyTrend = useMemo(() => {
    const groups = new Map<string, number[]>()
    for (const point of history) {
      const key = new Date(point.recordedAt).toLocaleDateString('en-CA')
      const arr = groups.get(key) ?? []
      arr.push(point.securityScore)
      groups.set(key, arr)
    }
    return [...groups.entries()].slice(-7).map(([day, values]) => ({
      day,
      score: Math.round(values.reduce((a, b) => a + b, 0) / values.length),
    }))
  }, [history])

  const trendDelta = dailyTrend.length > 1 ? dailyTrend[dailyTrend.length - 1].score - dailyTrend[0].score : null

  if (loaded && !websites.length && !scans.length) {
    return (
      <div className="space-y-5">
        <div className="cyber-kicker">Security command center</div>
        <h1 className="mb-6 text-2xl font-bold text-white">{t('dash.overview')}</h1>
        <EmptyState title={t('dash.noScans')} action={<Link to="/app/websites" className="btn-primary">{t('sites.add')}</Link>} />
      </div>
    )
  }

  return (
    <div className="relative space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="cyber-kicker">Security command center</div>
          <h1 className="mt-3 text-3xl font-black tracking-tight text-white">{t('dash.overview')}</h1>
          <p className="mt-2 max-w-2xl text-sm text-slate-500">{t('dash.subtitle')}</p>
        </div>
        <div className="hidden rounded-xl border border-brand-500/10 bg-brand-500/5 px-3 py-2 font-mono text-[10px] text-brand-400 sm:block">● {t('dash.systemReady')}</div>
      </div>

      {error && <div className="card border-sev-critical/30 bg-sev-critical/5 p-4 text-sm text-sev-critical">{error}</div>}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <div className="card p-4 sm:p-6">
          <p className="text-[10px] font-medium uppercase tracking-[0.2em] text-slate-500">{t('dash.monitoredSites')}</p>
          <p className="mt-3 text-3xl font-black text-white">{websites.length}</p>
          <p className="mt-1 text-xs text-slate-500">{t('dash.sitesTracked')}</p>
        </div>
        <div className="card p-4 sm:p-6">
          <p className="text-[10px] font-medium uppercase tracking-[0.2em] text-slate-500">{t('dash.scansThisMonth')}</p>
          <p className="mt-3 text-3xl font-black text-white">{scansThisMonth}</p>
          <p className="mt-1 text-xs text-slate-500">{t('dash.assessments')}</p>
        </div>
        <div className="card p-4 sm:p-6">
          <p className="text-[10px] font-medium uppercase tracking-[0.2em] text-slate-500">{t('dash.openFindings')}</p>
          <p className="mt-3 text-3xl font-black text-orange-400">{openFindings}</p>
          <p className="mt-1 text-xs text-slate-500">{attention} {t('dash.highRiskSites')}</p>
        </div>
        <div className="card p-4 sm:p-6">
          <p className="text-[10px] font-medium uppercase tracking-[0.2em] text-slate-500">{t('dash.portfolioScore')}</p>
          <p className="mt-3 text-3xl font-black text-brand-400">{scannedPosture.length ? averageSecurity : '—'}</p>
          <p className="mt-1 text-xs text-slate-500">{t('dash.averageLatest')}</p>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.1fr_.9fr]">
        <div className="card p-5 sm:p-6">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="cyber-kicker">Posture trend</div>
              <h2 className="mt-2 text-xl font-bold text-white">{t('dash.securityTrend')}</h2>
              <p className="mt-1 text-sm text-slate-500">{t('dash.trendHint')}</p>
            </div>
            {trendDelta !== null && (
              <span className={trendDelta >= 0 ? 'badge border-sev-passed/30 bg-sev-passed/10 text-sev-passed' : 'badge border-sev-critical/30 bg-sev-critical/10 text-sev-critical'}>
                {trendDelta >= 0 ? '▲' : '▼'} {Math.abs(trendDelta)}
              </span>
            )}
          </div>
          {dailyTrend.length ? (
            <div className="mt-6 flex h-40 items-end gap-2 sm:gap-3">
              {dailyTrend.map((point, index) => (
                <div key={point.day} className="flex min-w-0 flex-1 flex-col items-center gap-2">
                  <span className="text-xs font-bold text-slate-300">{point.score}</span>
                  <div className="flex h-24 w-full max-w-10 items-end rounded-lg bg-surface-900/70 p-1">
                    <div className="w-full rounded-md bg-brand-500/80 transition-all" style={{ height: `${Math.max(8, point.score)}%` }} />
                  </div>
                  <span className="truncate text-[10px] text-slate-600">{index === dailyTrend.length - 1 ? t('dash.today') : new Date(`${point.day}T00:00:00`).toLocaleDateString(lang, { month: 'short', day: 'numeric' })}</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="mt-8 rounded-xl border border-surface-800 bg-surface-950/50 p-6 text-sm text-slate-500">{t('dash.trendEmpty')}</div>
          )}
        </div>

        <div className="card p-5 sm:p-6">
          <div className="cyber-kicker">Security posture</div>
          <h2 className="mt-2 text-xl font-bold text-white">{t('dash.scoreSnapshot')}</h2>
          <div className="mt-5 flex items-center justify-around gap-3">
            <ScoreRing score={averageSecurity} size={128} label="Security" />
            <ScoreRing score={averagePrivacy} size={128} label="Privacy" />
          </div>
          <div className="mt-5 grid grid-cols-2 gap-2">
            {(['critical', 'high', 'medium', 'low'] as const).map((severity) => {
              const count = scannedPosture.filter((p) => p.scan?.riskLevel === severity).length
              return <div key={severity} className="flex items-center justify-between rounded-lg border border-surface-800 bg-surface-950/50 px-3 py-2"><SeverityBadge severity={severity} /><span className="font-bold text-slate-200">{count}</span></div>
            })}
          </div>
        </div>
      </div>

      {posture.length > 0 && (
        <div className="card p-5 sm:p-6">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <div className="cyber-kicker">Attack surface</div>
              <h2 className="mt-2 text-xl font-bold text-white">{t('dash.websitePosture')}</h2>
              <p className="mt-1 text-sm text-slate-500">{t('dash.websitePostureHint')}</p>
            </div>
            <Link to="/app/websites" className="btn-secondary">{t('dash.manageSites')}</Link>
          </div>
          <div className="mt-5 grid gap-3 md:grid-cols-2">
            {posture.slice(0, 6).map(({ website, scan, previous }) => {
              const delta = scan && previous ? (scan.securityScore ?? 0) - (previous.securityScore ?? 0) : null
              return (
                <Link key={website.id} to={`/app/websites/${website.id}`} className="rounded-xl border border-surface-800 bg-surface-950/50 p-4 transition hover:border-brand-500/30 hover:bg-brand-500/5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0"><p className="truncate font-semibold text-slate-100">{website.name || website.url}</p><p className="mt-1 truncate text-xs text-slate-600">{website.url}</p></div>
                    {scan?.riskLevel ? <SeverityBadge severity={scan.riskLevel} /> : <span className="badge border-surface-700 bg-surface-900 text-slate-500">{t('dash.notScanned')}</span>}
                  </div>
                  {scan ? (
                    <div className="mt-4 flex items-end justify-between gap-3"><div><span className="text-2xl font-black text-brand-400">{scan.securityScore}</span><span className="ml-2 text-xs text-slate-500">{t('dash.securityScore')}</span></div>{delta !== null && <span className={delta >= 0 ? 'text-xs font-semibold text-sev-passed' : 'text-xs font-semibold text-sev-critical'}>{delta >= 0 ? '▲' : '▼'} {Math.abs(delta)}</span>}</div>
                  ) : <p className="mt-4 text-sm text-slate-500">{t('dash.readyForScan')}</p>}
                </Link>
              )
            })}
          </div>
        </div>
      )}

      {fixes.length > 0 && (
        <div className="card p-5 sm:p-6">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div><div className="cyber-kicker">Action plan</div><h2 className="mt-2 text-xl font-bold text-white">{t('dash.priorityFixes')}</h2><p className="mt-1 text-sm text-slate-500">{t('dash.priorityFixes.hint')}</p></div>
            <Link to="/app/history" className="text-sm font-semibold text-brand-400 hover:underline">{t('nav.history')} →</Link>
          </div>
          <ul className="mt-5 divide-y divide-surface-800">
            {fixes.map((f, i) => (
              <li key={`${f.scanId}-${f.checkId}`} className="flex flex-wrap items-center justify-between gap-3 py-3">
                <Link to={`/app/scans/${f.scanId}`} className="flex min-w-0 items-center gap-3 hover:underline"><span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-brand-500/10 text-xs font-bold text-brand-400">{String(i + 1).padStart(2, '0')}</span><span className="min-w-0"><span className="block truncate text-sm font-medium text-slate-200">{f.title}</span><span className="block truncate text-xs text-slate-600">{f.target}</span></span></Link>
                <div className="flex items-center gap-2"><SeverityBadge severity={f.severity} /><span className="badge border-sev-passed/30 bg-sev-passed/10 text-sev-passed">{t('dash.estimatedGain', { n: f.scoreImpact })}</span></div>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="card p-5 sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-3"><div><div className="cyber-kicker">Activity stream</div><h2 className="mt-2 text-xl font-bold text-white">{t('dash.recentScans')}</h2></div><Link to="/app/history" className="text-sm font-semibold text-brand-400 hover:underline">{t('dash.viewHistory')} →</Link></div>
        {scans.length === 0 ? <p className="mt-5 text-sm text-slate-500">{t('common.noData')}</p> : <ul className="mt-4 divide-y divide-surface-800">{scans.slice(0, 6).map((s) => <li key={s.id} className="flex flex-wrap items-center justify-between gap-3 py-3"><div className="min-w-0"><Link to={`/app/scans/${s.id}`} className="block max-w-[70vw] truncate text-sm font-medium text-brand-400 hover:underline sm:max-w-none">{s.target}</Link><p className="text-xs text-slate-500">{new Date(s.createdAt).toLocaleString(lang, { dateStyle: 'medium', timeStyle: 'short' })}</p></div><div className="flex items-center gap-2 text-sm">{s.securityScore !== undefined && <b className="text-slate-100">{s.securityScore}</b>}{s.riskLevel && <SeverityBadge severity={s.riskLevel} />}{s.status === 'failed' && <span className="text-sev-critical">{t('scan.failed')}</span>}</div></li>)}</ul>}
      </div>
    </div>
  )
}
