-- تفعيل Realtime للوحة التحكم المباشرة
do $$ begin alter publication supabase_realtime add table public.count_sessions; exception when duplicate_object then null; end $$;
do $$ begin alter publication supabase_realtime add table public.reports; exception when duplicate_object then null; end $$;
do $$ begin alter publication supabase_realtime add table public.observer_locations; exception when duplicate_object then null; end $$;
do $$ begin alter publication supabase_realtime add table public.support_metrics; exception when duplicate_object then null; end $$;
