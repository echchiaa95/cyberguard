import { Link } from 'react-router-dom'
import { useI18n } from '../lib/i18n'

const FEATURES = [
  { icon: '✦', title: 'scan.pro.ai.title', description: 'scan.pro.ai.desc' },
  { icon: '◌', title: 'scan.pro.monitoring.title', description: 'scan.pro.monitoring.desc' },
  { icon: '▣', title: 'scan.pro.report.title', description: 'scan.pro.report.desc' },
  { icon: '◆', title: 'scan.pro.shield.title', description: 'scan.pro.shield.desc' },
]

export function ProUpgradeSection() {
  const { t } = useI18n()

  return (
    <section className="relative overflow-hidden rounded-3xl border border-brand-500/20 bg-surface-900/55 p-5 shadow-2xl shadow-black/10 sm:p-7">
      <div className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-brand-500/10 blur-3xl" />
      <div className="pointer-events-none absolute -left-20 -bottom-24 h-52 w-52 rounded-full bg-cyan-500/5 blur-3xl" />

      <div className="relative text-center">
        <span className="inline-flex items-center gap-2 rounded-full border border-brand-500/20 bg-brand-500/5 px-4 py-1.5 text-[11px] font-bold uppercase tracking-[0.2em] text-brand-300">
          <span aria-hidden="true">🔒</span>
          {t('scan.pro.kicker')}
        </span>
        <h2 className="mt-4 text-2xl font-black tracking-tight text-white sm:text-3xl">{t('scan.pro.title')}</h2>
        <p className="mx-auto mt-2 max-w-2xl text-sm leading-6 text-slate-400">{t('scan.pro.subtitle')}</p>
      </div>

      <div className="relative mt-6 grid gap-3 sm:grid-cols-2">
        {FEATURES.map((feature) => (
          <div key={feature.title} className="group rounded-2xl border border-surface-800 bg-surface-950/55 p-4 transition hover:border-brand-500/25">
            <div className="flex items-start gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-brand-500/15 bg-brand-500/5 text-brand-300" aria-hidden="true">{feature.icon}</span>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="font-semibold text-slate-100">{t(feature.title)}</h3>
                  <span className="rounded-full border border-brand-500/15 bg-brand-500/5 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-brand-300">Pro</span>
                </div>
                <p className="mt-2 text-sm leading-6 text-slate-500 blur-[3px] select-none" aria-hidden="true">{t(feature.description)}</p>
                <p className="sr-only">{t(feature.description)}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="relative mt-6 flex flex-col items-center justify-center gap-3 sm:flex-row">
        <Link to="/app/pricing" className="btn-primary w-full text-center sm:w-auto">
          {t('scan.pro.cta')}
        </Link>
        <p className="text-xs text-slate-500">{t('scan.pro.price')}</p>
      </div>
    </section>
  )
}
