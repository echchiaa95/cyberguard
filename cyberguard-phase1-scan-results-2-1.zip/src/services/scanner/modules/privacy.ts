import type { CheckResult, CheckCategory, ScanInput } from '../../../types'

type Check = Omit<CheckResult, 'scoreImpact'>

function check(partial: Check): Check { return partial }

import { baseDomain, hostOf } from '../../../lib/utils'

export function analyzePrivacy(input: ScanInput): Omit<CheckResult, 'scoreImpact'>[] {
  const checks: Check[] = []
  const targetHost = hostOf(input.finalUrl)
  const targetBase = baseDomain(targetHost)

  const abs = (u: string): string => {
    try { return new URL(u, input.finalUrl).toString() } catch { return u }
  }
  const thirdPartyScripts = input.resources.scripts.map(abs).filter((u) => {
    try { return baseDomain(new URL(u).hostname) !== targetBase } catch { return false }
  })
  const thirdPartyPreconnects = input.resources.preconnects.filter((u) => {
    try { return baseDomain(new URL(u).hostname) !== targetBase } catch { return false }
  })

  if (thirdPartyScripts.length === 0) {
    checks.push(check({
      checkId: 'privacy.third-party-scripts', module: 'privacy', category: 'privacy', severity: 'passed', status: 'pass',
      title: 'No third-party scripts detected',
      evidence: 'All observed scripts are hosted on the website\u2019s own domain.',
      description: 'No external JavaScript sources were found on the analyzed page.',
      impact: 'Lower exposure to third-party compromise and tracking.',
      recommendation: 'No action required.', remediation: 'N/A',
    }))
  } else {
    checks.push(check({
      checkId: 'privacy.third-party-scripts', module: 'privacy', category: 'privacy', severity: 'low', status: 'warn',
      title: 'Potential privacy risk: third-party scripts detected',
      evidence: `Third-party script sources: ${thirdPartyScripts.slice(0, 10).join(', ')}${thirdPartyScripts.length > 10 ? ` (+${thirdPartyScripts.length - 10} more)` : ''}`,
      description: 'Third-party scripts execute with full page privileges and can observe user interactions. Presence of a third-party script is an observed fact; the privacy risk depends on what the provider does with the data.',
      impact: 'Low to medium: potential data collection by external providers; a compromised provider could affect your visitors.',
      recommendation: 'Audit each third-party script. Load only what is necessary and consider self-hosting or removing unused ones.',
      remediation: 'Review <script src="..."> tags; remove unused tags and add Subresource Integrity where possible.',
    }))
  }

  if (thirdPartyPreconnects.length > 0) {
    checks.push(check({
      checkId: 'privacy.preconnects', module: 'privacy', category: 'privacy', severity: 'info', status: 'info',
      title: 'Data collection indicator: third-party preconnections',
      evidence: `Preconnect targets: ${thirdPartyPreconnects.join(', ')}`,
      description: 'The page tells the browser to open early connections to external origins, which usually means content will be loaded from them.',
      impact: 'Informational: these origins may receive connection metadata (IP address, timing).',
      recommendation: 'Confirm each preconnected origin is expected.',
      remediation: 'N/A',
    }))
  }

  const fingerprintPatterns = /fingerprintjs|clientjs|imprintjs|canvas\-fingerprint|evercookie/
  const allScriptText = input.resources.scripts.join(' ')
  const htmlBlob = JSON.stringify(input.resources)
  if (fingerprintPatterns.test(allScriptText) || fingerprintPatterns.test(htmlBlob)) {
    checks.push(check({
      checkId: 'privacy.fingerprinting', module: 'privacy', category: 'privacy', severity: 'medium', status: 'warn',
      title: 'Tracking detected: fingerprinting indicator',
      evidence: 'A known fingerprinting library or pattern was observed in page resources.',
      description: 'Browser fingerprinting can identify visitors across sites without cookies, which is difficult to detect and block.',
      impact: 'Medium: visitors may be tracked across websites without consent mechanisms noticing.',
      recommendation: 'Verify whether fingerprinting is intentional, disclosed in your privacy policy, and covered by consent requirements.',
      remediation: 'Remove the fingerprinting library or gate it behind explicit consent.',
    }))
  }

  return checks
}
