import { createClient, type SupabaseClient } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined

export const isSupabaseConfigured: boolean = Boolean(
  url && anonKey && url.startsWith('https://') && !url.includes('your-project-ref')
)

export const supabase: SupabaseClient | null = isSupabaseConfigured
  ? createClient(url!, anonKey!, {
      auth: { persistSession: true, autoRefreshToken: true },
    })
  : null

export const isDemoMode: boolean =
  (import.meta.env.VITE_DEMO_MODE as string | undefined) === 'true' || !isSupabaseConfigured
