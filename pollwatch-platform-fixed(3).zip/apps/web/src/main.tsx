import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { I18nProvider } from "./lib/i18n";
import "./index.css";

// الوضع المظلم فقط — يُفرض دائماً على مستوى الجذر ولا يمكن تغييره من الواجهة.
document.documentElement.classList.add("dark");
document.documentElement.style.colorScheme = "dark";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <I18nProvider>
      <App />
    </I18nProvider>
  </React.StrictMode>
);

// تسجيل Service Worker (PWA + عمل دون اتصال) — بدون أي اعتماد على متغيرات البيئة
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("./sw.js").catch(() => {});
  navigator.serviceWorker.addEventListener("message", (e) => {
    if (e.data?.type === "SYNC_NOW") window.dispatchEvent(new CustomEvent("pollwatch:sync"));
  });
}
