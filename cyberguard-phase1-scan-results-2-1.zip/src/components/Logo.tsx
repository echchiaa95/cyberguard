export function Logo({ size = 32 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true">
      <rect width="64" height="64" rx="14" fill="#0f172a" />
      <path d="M32 10 L50 17 v14 c0 12-8 20-18 23 C22 51 14 43 14 31 V17 Z" fill="none" stroke="#10b981" strokeWidth="4" strokeLinejoin="round" />
      <path d="M24 32 l6 6 11-12" fill="none" stroke="#10b981" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}
