import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useI18n } from '../lib/i18n'
import { Logo } from '../components/Logo'
import { CyberBackground } from '../components/CyberBackground'

const FEATURES = [
  'securityScore', 'privacyScore', 'webScanner', 'appScanner',
  'fileScanner', 'monitoring', 'reports', 'advisor',
] as const

export function Landing() {
  const { t } = useI18n()
  const [faq, setFaq] = useState<number | null>(null)

  return (
    <div className="relative min-h-screen bg-[#020611] text-slate-200">
      <CyberBackground variant="hero" />
      <div className="relative z-10">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <div className="flex items-center gap-2"><Logo size={30} /><span className="font-bold text-white">CyberGuard</span></div>
        <div className="flex items-center gap-4">
          <a href="#features" className="hidden text-sm text-slate-400 hover:text-slate-200 sm:block">{t('landing.cta.tools')}</a>
          <Link to="/login" className="text-sm text-slate-400 hover:text-slate-200">Login</Link>
          <Link to="/signup" className="btn-primary">{t('landing.cta.scan')}</Link>
        </div>
      </header>

      <section className="mx-auto max-w-4xl px-6 py-20 text-center">
        <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl">
          {t('landing.hero.title')}
        </h1>
        <p className="mx-auto mt-5 max-w-2xl text-lg text-slate-400">{t('landing.hero.subtitle')}</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link to="/signup" className="btn-primary !px-6 !py-3">{t('landing.cta.scan')}</Link>
          <a href="#features" className="btn-secondary !px-6 !py-3">{t('landing.cta.tools')}</a>
        </div>
      </section>

      <section id="features" className="mx-auto max-w-6xl px-6 py-12">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((f) => (
            <div key={f} className="card p-5">
              <h3 className="font-semibold text-slate-100">{t(`landing.feature.${f}.title`)}</h3>
              <p className="mt-2 text-sm text-slate-400">{t(`landing.feature.${f}.desc`)}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-6 py-12">
        <h2 className="text-center text-2xl font-bold text-white">{t('landing.trust.title')}</h2>
        <p className="mt-3 text-center text-slate-400">{t('landing.trust.desc')}</p>
        <div className="mt-8 space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="card overflow-hidden">
              <button className="flex w-full items-center justify-between p-4 text-start font-medium"
                onClick={() => setFaq(faq === i ? null : i)}>
                {t(`landing.faq.q${i}`)}
                <span className="text-slate-500">{faq === i ? '−' : '+'}</span>
              </button>
              {faq === i && <p className="px-4 pb-4 text-sm text-slate-400">{t(`landing.faq.a${i}`)}</p>}
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-surface-800 py-8 text-center text-sm text-slate-500">
        <p>© {new Date().getFullYear()} CyberGuard — {t('landing.footer.rights')}</p>
        <p className="mx-auto mt-2 max-w-2xl">{t('landing.footer.disclaimer')}</p>
      </footer>
      </div>
    </div>
  )
}
