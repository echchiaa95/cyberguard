import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import { useI18n } from '../lib/i18n'
import { LanguageSwitcher } from '../components/LanguageSwitcher'
import { resetDemoData } from '../services/db'
import { supabase } from '../lib/supabase'
import { cn } from '../lib/utils'

interface PlanDef {
  code: 'free' | 'pro' | 'business'
  name: string
  price: string
  features: number
  featured?: boolean
}

export function Pricing() {
  const { t } = useI18n()
  const navigate = useNavigate()
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null)
  const plans: PlanDef[] = [
    { code: 'free', name: t('pricing.free.name'), price: t('pricing.free.price'), features: 7 },
    { code: 'pro', name: t('pricing.pro.name'), price: t('pricing.pro.price'), features: 13, featured: true },
    { code: 'business', name: t('pricing.business.name'), price: t('pricing.business.price'), features: 12 },
  ]
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-white">{t('pricing.title')}</h1>
        <p className="mx-auto mt-2 max-w-xl text-sm text-slate-400">{t('pricing.subtitle')}</p>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        {plans.map((p) => (
          <div key={p.code} className={cn('card p-6', p.featured && 'border-brand-500/50')}>
            <h2 className="font-semibold text-slate-100">{p.name}</h2>
            <p className="mt-2 text-2xl font-bold text-brand-400">{p.price}</p>
            <ul className="mt-4 space-y-2 text-sm text-slate-300">
              {Array.from({ length: p.features }, (_, i) => (
                <li key={i}>✓ {t(`pricing.${p.code}.f${i + 1}`)}</li>
              ))}
            </ul>
            <button
              type="button"
              className="btn-primary mt-6 w-full"
              onClick={() => {
                setSelectedPlan(p.code)
                if (p.code === 'free') navigate('/app/websites')
              }}
            >
              {t('pricing.cta')}
            </button>
          </div>
        ))}
      </div>
      {selectedPlan && (
        <div role="status" className="card border-brand-500/30 bg-brand-500/5 p-4 text-sm text-slate-300">
          {selectedPlan === 'free'
            ? 'You are already using the Free plan.'
            : `You selected the ${selectedPlan === 'pro' ? 'Pro' : 'Business'} plan. Payment and subscription activation are not implemented yet.`}
        </div>
      )}
      <p className="text-center text-xs text-slate-500">{t('pricing.note')}</p>
    </div>
  )
}

const NOTIF_KEYS = ['critical', 'score', 'ssl', 'tracker'] as const

export function Settings() {
  const { t } = useI18n()
  const { user, isDemo } = useAuth()
  const [theme, setTheme] = useState(() => localStorage.getItem('cg_theme') ?? 'dark')
  const [notif, setNotif] = useState<Record<string, boolean>>(() => {
    try {
      return JSON.parse(localStorage.getItem('cg_notif') ?? '{}') as Record<string, boolean>
    } catch {
      return {}
    }
  })
  const [saved, setSaved] = useState(false)
  const [saveError, setSaveError] = useState<string | null>(null)

  useEffect(() => {
    document.documentElement.classList.toggle('light', theme === 'light')
    document.documentElement.classList.toggle('dark', theme !== 'light')
    localStorage.setItem('cg_theme', theme)
  }, [theme])

  const save = async () => {
    setSaved(false)
    setSaveError(null)
    const payload = {
      email_critical: notif.critical ?? true,
      email_score_change: notif.score ?? true,
      email_ssl_expiration: notif.ssl ?? true,
      email_new_tracker: notif.tracker ?? false,
    }
    localStorage.setItem('cg_notif', JSON.stringify(notif))
    if (supabase && user) {
      const { error } = await supabase
        .from('notification_preferences')
        .upsert({ user_id: user.id, ...payload })
      if (error) {
        // Surface a friendly error instead of silently ignoring the failure.
        // The technical detail stays in the Supabase client/secure logs only.
        setSaveError(t('error.generic'))
        return
      }
    }
    setSaved(true)
    setTimeout(() => setSaved(false), 2500)
  }

  return (
    <div className="max-w-2xl space-y-6">
      <h1 className="text-2xl font-bold text-white">{t('settings.title')}</h1>

      <div className="card space-y-4 p-6">
        <div>
          <p className="label">{t('settings.language')}</p>
          <LanguageSwitcher />
        </div>
        <div>
          <p className="label">{t('settings.theme')}</p>
          <div className="flex gap-2">
            <button onClick={() => setTheme('dark')} className={cn('btn-secondary', theme !== 'light' && '!border-brand-500')}>
              {t('settings.theme.dark')}
            </button>
            <button onClick={() => setTheme('light')} className={cn('btn-secondary', theme === 'light' && '!border-brand-500')}>
              {t('settings.theme.light')}
            </button>
          </div>
        </div>
      </div>

      <div className="card space-y-4 p-6">
        <h2 className="font-semibold text-slate-100">{t('settings.notifications')}</h2>
        <p className="text-sm text-slate-500">{t('settings.notif.desc')}</p>
        {NOTIF_KEYS.map((k) => (
          <label key={k} className="flex items-center justify-between gap-3 text-sm text-slate-300">
            {t(`settings.notif.${k}`)}
            <input
              type="checkbox"
              className="h-4 w-4 accent-brand-500"
              checked={notif[k] ?? true}
              onChange={(e) => setNotif({ ...notif, [k]: e.target.checked })}
            />
          </label>
        ))}
        <div className="flex items-center gap-3">
          <button className="btn-primary" onClick={() => void save()}>{t('common.save')}</button>
          {saved && <p className="text-sm text-sev-passed">{t('settings.saved')}</p>}
          {saveError && <p role="alert" className="text-sm text-sev-critical">{saveError}</p>}
        </div>
        {isDemo && <p className="text-xs text-slate-500">Demo mode: preferences are stored locally only.</p>}
      </div>

      {isDemo && (
        <div className="card p-6">
          <h2 className="mb-2 font-semibold text-slate-100">Demo data</h2>
          <button className="btn-secondary text-sev-critical" onClick={() => void resetDemoData()}>
            {t('common.delete')} — reset demo session
          </button>
        </div>
      )}
    </div>
  )
}

export function Account() {
  const { user, profile } = useAuth()
  const { t } = useI18n()
  return (
    <div className="max-w-2xl space-y-6">
      <h1 className="text-2xl font-bold text-white">{t('account.title')}</h1>
      <div className="card space-y-3 p-6 text-sm">
        <h2 className="font-semibold text-slate-100">{t('account.profile')}</h2>
        <p className="text-slate-400">{profile?.fullName || '—'}</p>
        <p className="break-all text-slate-400">{user?.email}</p>
        <h2 className="pt-3 font-semibold text-slate-100">{t('account.plan')}</h2>
        <span className="badge border-brand-500/40 bg-brand-500/10 text-brand-400">{t('account.plan.free')}</span>
      </div>
    </div>
  )
}
