export function cn(...classes: (string | false | null | undefined)[]): string {
  return classes.filter(Boolean).join(' ')
}

export function normalizeUrl(input: string): string | null {
  try {
    const withScheme = /^https?:\/\//i.test(input.trim()) ? input.trim() : `https://${input.trim()}`
    const url = new URL(withScheme)
    if (url.protocol !== 'https:' && url.protocol !== 'http:') return null
    if (!url.hostname.includes('.')) return null
    return url.toString().replace(/\/$/, '')
  } catch {
    return null
  }
}

export function isPrivateHost(hostname: string): boolean {
  const h = hostname.toLowerCase().replace(/^\[|\]$/g, '')
  const isV6 = h.includes(':')
  if (h === 'localhost' || h.endsWith('.local') || h === '0.0.0.0' || h === '::' || h === '::1') return true
  if (isV6 && (h.startsWith('fe80:') || h.startsWith('fc') || h.startsWith('fd'))) return true
  const m = h.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/)
  if (!m) return false
  const [a, b] = [Number(m[1]), Number(m[2])]
  return a === 10 || a === 127 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || a === 0
}

export function formatDate(iso: string, lang: string): string {
  try {
    return new Intl.DateTimeFormat(lang, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(iso))
  } catch {
    return iso
  }
}

export function hostOf(url: string): string {
  try { return new URL(url).hostname } catch { return url }
}

/** Very small registrable-domain approximation: last two labels. */
export function baseDomain(hostname: string): string {
  const parts = hostname.toLowerCase().split('.')
  return parts.slice(-2).join('.')
}
