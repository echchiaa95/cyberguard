import type { CheckResult, CheckCategory, ScanInput } from '../../../types'

type Check = Omit<CheckResult, 'scoreImpact'>

function check(partial: Check): Check { return partial }

export function analyzeTls(input: ScanInput): Omit<CheckResult, 'scoreImpact'>[] {
  const checks: Check[] = []
  const isHttps = /^https:/i.test(input.finalUrl ?? '')

  if (!isHttps) {
    checks.push(check({
      checkId: 'tls.not-applicable', module: 'tls', category: 'https', severity: 'info', status: 'info',
      title: 'TLS details not applicable (site not served over HTTPS)',
      evidence: `Final URL: ${input.finalUrl}`,
      description: 'Certificate and protocol checks apply only to HTTPS sites.',
      impact: 'Informational only.',
      recommendation: 'Enable HTTPS first; then re-run the scan for TLS details.',
      remediation: 'N/A',
    }))
    return checks
  }

  const tls = (input as unknown as { tls?: { protocol?: string; certExpiresAt?: string; issuer?: string } }).tls
  if (!tls) {
    checks.push(check({
      checkId: 'tls.details-unavailable', module: 'tls', category: 'https', severity: 'info', status: 'info',
      title: 'TLS certificate details unavailable in this scan mode',
      evidence: 'The passive scan did not capture certificate metadata (protocol version, expiry, issuer).',
      description: 'Certificate chain, protocol version and expiry are collected by the full server-side scan. The deterministic engine does not guess them.',
      impact: 'Informational only.',
      recommendation: 'Run a full scan via the CyberGuard Edge Function to include TLS details.',
      remediation: 'N/A',
    }))
    return checks
  }

  const expires = tls.certExpiresAt ? new Date(tls.certExpiresAt) : null
  const daysLeft = expires ? Math.floor((expires.getTime() - Date.now()) / 864e5) : null
  if (daysLeft !== null && daysLeft < 0) {
    checks.push(check({
      checkId: 'tls.cert-expired', module: 'tls', category: 'https', severity: 'critical', status: 'fail',
      title: 'TLS certificate is expired',
      evidence: `Certificate expired on ${expires!.toISOString().slice(0, 10)}.`,
      description: 'Browsers block or strongly warn visitors when a certificate is expired.',
      impact: 'Critical: visitors see security warnings and may be unable to access the site; trust is severely damaged.',
      recommendation: 'Renew and install the certificate immediately.',
      remediation: 'Re-issue the certificate (e.g. via Let\u2019s Encrypt) and automate renewal.',
    }))
  } else if (daysLeft !== null && daysLeft <= 14) {
    checks.push(check({
      checkId: 'tls.cert-expiring', module: 'tls', category: 'https', severity: 'medium', status: 'warn',
      title: 'TLS certificate expires soon',
      evidence: `Certificate expires on ${expires!.toISOString().slice(0, 10)} (in ${daysLeft} days). Issuer: ${tls.issuer ?? 'unknown'}.`,
      description: 'The certificate will expire shortly. Expired certificates trigger browser warnings.',
      impact: 'Medium: risk of downtime and trust warnings if renewal is missed.',
      recommendation: 'Renew the certificate now and enable automatic renewal.',
      remediation: 'certbot renew --deploy-hook "systemctl reload nginx"',
    }))
  } else {
    checks.push(check({
      checkId: 'tls.cert-valid', module: 'tls', category: 'https', severity: 'passed', status: 'pass',
      title: 'TLS certificate is valid',
      evidence: `Valid until ${expires ? expires.toISOString().slice(0, 10) : 'unknown'}. Issuer: ${tls.issuer ?? 'unknown'}.`,
      description: 'The certificate is currently valid.',
      impact: 'Visitors connect without certificate warnings.',
      recommendation: 'Keep automatic renewal enabled.', remediation: 'N/A',
    }))
  }

  return checks
}
