import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import { useI18n } from '../lib/i18n'
import type { HistoryPoint } from '../types'
import { listHistory } from '../services/db'
import { scoreColor } from '../lib/severity'
import { EmptyState } from '../components/EmptyState'

export function History() {
  const { user } = useAuth()
  const { t, lang } = useI18n()
  const [points, setPoints] = useState<HistoryPoint[]>([])

  useEffect(() => { if (user) void listHistory(user.id).then(setPoints) }, [user])

  if (points.length === 0) {
    return (
      <div>
        <h1 className="mb-6 text-2xl font-bold text-white">{t('hist.title')}</h1>
        <EmptyState title={t('common.noData')} />
      </div>
    )
  }

  const W = 600, H = 140
  const scores = points.map((p) => p.securityScore)
  const min = Math.min(...scores, 0)
  const max = Math.max(...scores, 100)
  const x = (i: number) => (points.length <= 1 ? W / 2 : (i / (points.length - 1)) * W)
  const y = (s: number) => H - ((s - min) / Math.max(1, max - min)) * H
  const path = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${x(i)},${y(p.securityScore)}`).join(' ')

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">{t('hist.title')}</h1>

      {points.length > 1 && (
        <div className="card p-6">
          <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="Score history">
            <path d={path} fill="none" stroke="#10b981" strokeWidth="2.5" strokeLinejoin="round" />
            {points.map((p, i) => (
              <circle key={p.scanId ?? i} cx={x(i)} cy={y(p.securityScore)} r="4" fill="#10b981" />
            ))}
          </svg>
        </div>
      )}

      <div className="card overflow-x-auto p-6">
        <table className="w-full min-w-[34rem] text-sm">
          <thead>
            <tr className="text-xs uppercase tracking-wide text-slate-500">
              <th className="pb-3 text-start font-medium">{t('hist.col.date')}</th>
              <th className="pb-3 text-start font-medium">{t('hist.col.score')}</th>
              <th className="pb-3 text-start font-medium">{t('hist.col.privacy')}</th>
              <th className="pb-3 text-start font-medium">{t('hist.col.findings')}</th>
              <th className="pb-3 text-start font-medium">{t('hist.col.change')}</th>
              <th className="pb-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-surface-800">
            {points.map((p, i) => {
              const prev = i > 0 ? points[i - 1] : null
              const delta = prev ? p.securityScore - prev.securityScore : null
              return (
                <tr key={p.scanId ?? i}>
                  <td className="py-3 text-slate-300">{new Date(p.recordedAt).toLocaleDateString(lang)}</td>
                  <td className={`${scoreColor(p.securityScore)} font-bold`}>{p.securityScore}</td>
                  <td className="text-slate-300">{p.privacyScore ?? '—'}</td>
                  <td className="text-slate-300">{p.findingsCount}</td>
                  <td className={delta === null ? 'text-slate-500' : delta >= 0 ? 'text-sev-passed' : 'text-sev-critical'}>
                    {delta === null ? '—' : t(delta >= 0 ? 'hist.improved' : 'hist.declined', { n: Math.abs(delta) })}
                  </td>
                  <td className="text-end">
                    {p.scanId && <Link to={`/app/scans/${p.scanId}`} className="text-brand-400 hover:underline">{t('common.view')}</Link>}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
