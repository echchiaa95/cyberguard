import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'

// Base path must mirror vite.config.ts `base` and BrowserRouter basename.
const base = (import.meta.env.VITE_BASE_PATH as string | undefined) || '/'
const baseNoSlash = base.endsWith('/') ? base.slice(0, -1) : base

// GitHub Pages SPA fallback (see public/404.html): a deep link lands as
// <base>/?p=/app/websites — rewrite history so react-router sees the real
// route under its basename.
const redirect = new URLSearchParams(window.location.search).get('p')
if (redirect) {
  const path = redirect.startsWith('/') ? redirect : `/${redirect}`
  window.history.replaceState(null, '', baseNoSlash + path)
}

if ('serviceWorker' in navigator && import.meta.env.PROD) {
  // Registered under the configured base (project sites: /<repo>/sw.js),
  // which also makes the SW scope the project path.
  navigator.serviceWorker.register(`${baseNoSlash}/sw.js`).catch(() => {
    // Offline shell is a progressive enhancement; ignore registration failures.
  })
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
