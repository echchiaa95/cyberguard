import { DEMO_INPUT } from '../../lib/demoData'
import { isDemoMode, supabase } from '../../lib/supabase'
import { normalizeUrl, isPrivateHost } from '../../lib/utils'
import type { CheckResult, ScanInput, ScanOutput } from '../../types'
import { aggregateChecks } from './engine'
import { analyzeHttps } from './modules/https'
import { analyzeTls } from './modules/tls'
import { analyzeHeaders } from './modules/headers'
import { analyzeCookies } from './modules/cookies'
import { analyzeDns } from './modules/dns'
import { analyzePrivacy } from './modules/privacy'
import { analyzeTrackers } from './modules/trackers'
import { analyzeExposure } from './modules/exposure'

export interface ScanError { messageKey: 'error.unableToScan' | 'error.verifyUrl' | 'error.scanUnavailable' }

export function validateScanUrl(input: string): { url?: string; error?: ScanError } {
  const normalized = normalizeUrl(input)
  if (!normalized) return { error: { messageKey: 'error.verifyUrl' } }
  try {
    if (isPrivateHost(new URL(normalized).hostname)) {
      return { error: { messageKey: 'error.verifyUrl' } }
    }
  } catch {
    return { error: { messageKey: 'error.verifyUrl' } }
  }
  return { url: normalized }
}

function runModules(input: ScanInput): Omit<CheckResult, 'scoreImpact'>[] {
  return [
    ...analyzeHttps(input),
    ...analyzeTls(input),
    ...analyzeHeaders(input),
    ...analyzeCookies(input),
    ...analyzeDns(input),
    ...analyzePrivacy(input),
    ...analyzeTrackers(input),
    ...analyzeExposure(input),
  ]
}

export type ScanProgressStep = 'fetch' | 'headers' | 'cookies' | 'privacy' | 'scoring'

/**
 * Runs a passive website scan.
 *
 * Primary path: the `scan-website` Supabase Edge Function (server-side, passive).
 * Fallback (only when VITE_DEMO_MODE=true): a clearly-labeled demo dataset so the
 * complete flow can be verified end-to-end before the Edge Function is deployed.
 */
export async function runWebsiteScan(
  rawUrl: string,
  onProgress?: (step: ScanProgressStep) => void,
): Promise<ScanOutput> {
  const { url, error } = validateScanUrl(rawUrl)
  if (error || !url) throw Object.assign(new Error(error!.messageKey), { messageKey: error!.messageKey })

  let input: ScanInput | null = null
  let isDemo = false

  if (supabase) {
    onProgress?.('fetch')
    const { data, error: fnError } = await supabase.functions.invoke('scan-website', { body: { url } })
    if (!fnError && data && !data.error) {
      input = data as ScanInput
    } else if (isDemoMode) {
      input = { ...DEMO_INPUT, url, finalUrl: url }
      isDemo = true
    } else {
      const msg = (data as { error?: string } | null)?.error
      throw Object.assign(
        new Error(msg === 'Invalid URL. Please verify the URL.' ? 'error.verifyUrl' : 'error.scanUnavailable'),
        { messageKey: msg === 'Invalid URL. Please verify the URL.' ? 'error.verifyUrl' : 'error.scanUnavailable' },
      )
    }
  } else if (isDemoMode) {
    onProgress?.('fetch')
    input = { ...DEMO_INPUT, url, finalUrl: url }
    isDemo = true
  } else {
    throw Object.assign(new Error('error.scanUnavailable'), { messageKey: 'error.scanUnavailable' })
  }

  onProgress?.('headers')
  await tick()
  onProgress?.('cookies')
  await tick()
  onProgress?.('privacy')
  const checks = runModules(input!)
  onProgress?.('scoring')
  await tick()

  return aggregateChecks(checks, url, new Date().toISOString(), isDemo)
}

const tick = () => new Promise((r) => setTimeout(r, 60))

export { aggregateChecks }
