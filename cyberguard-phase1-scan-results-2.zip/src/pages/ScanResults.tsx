import { useEffect, useMemo, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import { useI18n } from '../lib/i18n'
import { ScoreRing } from '../components/ScoreRing'
import { SeverityBadge } from '../components/SeverityBadge'
import { getScanChecks, listScans } from '../services/db'
import type { CheckCategory, CheckResult, ScanRecord } from '../types'
import { cn } from '../lib/utils'
import { scoreColor } from '../lib/severity'

type Filter = 'all' | 'critical' | 'high' | 'medium' | 'low' | 'passed'
const TABS: Filter[] = ['all', 'critical', 'high', 'medium', 'low', 'passed']
const CATEGORY_ORDER: CheckCategory[] = ['https', 'headers', 'cookies', 'dns', 'privacy', 'trackers', 'exposure', 'web']

const categoryKey: Record<CheckCategory, string> = {
  https: 'scan.category.https', headers: 'scan.category.headers', cookies: 'scan.category.cookies',
  dns: 'scan.category.dns', privacy: 'scan.category.privacy', trackers: 'scan.category.trackers',
  exposure: 'scan.category.exposure', web: 'scan.category.web',
}

function Metric({ label, value, tone = 'text-white' }: { label: string; value: number | string; tone?: string }) {
  return (
    <div className="min-w-[8rem] rounded-2xl border border-surface-800 bg-surface-950/60 p-4">
      <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-500">{label}</p>
      <p className={cn('mt-1 text-2xl font-bold tabular-nums', tone)}>{value}</p>
    </div>
  )
}

export function ScanResults() {
  const { scanId } = useParams()
  const { user } = useAuth()
  const { t, lang } = useI18n()
  const [record, setRecord] = useState<ScanRecord | null>(null)
  const [checks, setChecks] = useState<CheckResult[] | null>(null)
  const [filter, setFilter] = useState<Filter>('all')
  const [expanded, setExpanded] = useState<string | null>(null)

  useEffect(() => {
    if (!user || !scanId) return
    let cancelled = false
    void (async () => {
      try {
        const scans = await listScans(user.id)
        const rec = scans.find((s) => s.id === scanId) ?? null
        if (cancelled) return
        setRecord(rec)
        if (rec && rec.status === 'completed') {
          const c = await getScanChecks(user.id, scanId)
          if (!cancelled) setChecks(c)
        }
      } catch {
        if (!cancelled) setRecord(null)
      }
    })()
    return () => { cancelled = true }
  }, [user, scanId])

  const visible = useMemo(() => {
    if (!checks) return []
    if (filter === 'all') return checks.filter((c) => c.status !== 'pass')
    if (filter === 'passed') return checks.filter((c) => c.status === 'pass')
    return checks.filter((c) => c.severity === filter && c.status !== 'pass')
  }, [checks, filter])

  const findings = useMemo(() => checks?.filter((c) => c.status !== 'pass' && c.severity !== 'info' && c.severity !== 'passed') ?? [], [checks])
  const passed = useMemo(() => checks?.filter((c) => c.status === 'pass') ?? [], [checks])
  const criticalHigh = findings.filter((c) => c.severity === 'critical' || c.severity === 'high').length
  const gain = useMemo(() => {
    if (!checks) return 0
    return Math.min(100 - (record?.securityScore ?? 0), checks.filter((c) => c.status !== 'pass').reduce((sum, c) => sum + Math.max(0, c.scoreImpact), 0))
  }, [checks, record])
  const priorityFixes = useMemo(() => {
    if (!checks) return []
    return [...checks]
      .filter((c) => c.status !== 'pass' && c.severity !== 'info' && c.severity !== 'passed')
      .sort((a, b) => (b.scoreImpact - a.scoreImpact) || (['critical','high','medium','low'].indexOf(a.severity) - ['critical','high','medium','low'].indexOf(b.severity)))
      .slice(0, 3)
  }, [checks])

  if (!record) return <p className="text-slate-400">{t('common.loading')}</p>

  if (record.status === 'failed') {
    return (
      <div className="cyber-glass p-8 text-center">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl border border-sev-critical/30 bg-sev-critical/10 text-2xl text-sev-critical">!</div>
        <p className="text-sev-critical">{t('scan.failed')}</p>
        {record.errorMessage && <p className="mt-2 text-sm text-slate-500">{t(record.errorMessage)}</p>}
        <Link to="/app/websites" className="mt-5 inline-block text-sm text-brand-400 hover:underline">{t('common.back')}</Link>
      </div>
    )
  }
  if (record.status === 'running' || checks === null) {
    return (
      <div className="cyber-glass overflow-hidden p-8">
        <div className="cyber-scanline mb-6" />
        <div className="flex items-center gap-3"><span className="cyber-dot animate-pulse" /><p className="font-semibold text-white">{t('scan.running')}</p></div>
        <p className="mt-2 text-sm text-slate-500">{t('scan.stepsNote')}</p>
      </div>
    )
  }

  const score = record.securityScore ?? 0
  const privacy = record.privacyScore ?? 0
  const scoreMessage = score >= 85 ? t('scan.score.excellent') : score >= 70 ? t('scan.score.good') : score >= 50 ? t('scan.score.attention') : t('scan.score.urgent')

  return (
    <div className="relative space-y-6">
      <section className="cyber-glass relative overflow-hidden p-5 sm:p-7">
        <div className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-brand-500/10 blur-3xl" />
        <div className="flex flex-wrap items-center justify-between gap-4">
          <Link to={record.websiteId ? `/app/websites/${record.websiteId}` : '/app/websites'} className="text-sm text-brand-400 hover:text-brand-300">← {t('common.back')}</Link>
          <Link to="/app/websites" className="rounded-xl border border-brand-500/20 bg-brand-500/5 px-4 py-2 text-sm font-semibold text-brand-300 hover:bg-brand-500/10">+ {t('scan.new')}</Link>
        </div>
        <div className="mt-6 grid gap-7 lg:grid-cols-[1fr_auto] lg:items-center">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.2em] text-brand-400"><span className="cyber-dot" /> {t('scan.results.title')}</div>
            <h1 className="mt-3 break-words text-3xl font-bold tracking-tight text-white sm:text-4xl">{record.target}</h1>
            <p className="mt-2 text-sm text-slate-500">{t('scan.date')}: {new Date(record.createdAt).toLocaleString(lang)}</p>
            <div className="mt-5 max-w-2xl rounded-2xl border border-surface-800 bg-surface-950/55 p-4">
              <p className={cn('font-semibold', scoreColor(score))}>{scoreMessage}</p>
              <p className="mt-1 text-sm leading-6 text-slate-400">{t('scan.score.note')}</p>
            </div>
          </div>
          <div className="flex items-center justify-center gap-5 sm:gap-8">
            <ScoreRing score={score} size={138} stroke={11} label={t('dash.securityScore')} />
            <ScoreRing score={privacy} size={112} stroke={9} label={t('dash.privacyScore')} />
          </div>
        </div>
      </section>

      {record.riskLevel && (
        <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-surface-800 bg-surface-900/50 p-4">
          <div className="flex items-center gap-3"><span className="text-sm text-slate-400">{t('common.riskLevel')}</span><SeverityBadge severity={record.riskLevel} /></div>
          <p className="text-xs text-slate-500">{t('scan.stepsNote')}</p>
        </div>
      )}

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Metric label={t('scan.findings')} value={findings.length} tone={criticalHigh ? 'text-sev-high' : 'text-sev-passed'} />
        <Metric label={t('scan.passedChecks')} value={passed.length} tone="text-sev-passed" />
        <Metric label={t('scan.metric.criticalHigh')} value={criticalHigh} tone={criticalHigh ? 'text-sev-critical' : 'text-sev-passed'} />
        <Metric label={t('scan.metric.recoverable')} value={`+${gain}`} tone="text-brand-300" />
      </div>

      {priorityFixes.length > 0 && (
        <section className="cyber-glass p-5 sm:p-6">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div><p className="cyber-kicker">{t('scan.priority.kicker')}</p><h2 className="mt-1 text-xl font-bold text-white">{t('dash.priorityFixes')}</h2><p className="mt-1 text-sm text-slate-500">{t('dash.priorityFixes.hint')}</p></div>
            <span className="rounded-full border border-brand-500/20 bg-brand-500/5 px-3 py-1 text-xs text-brand-300">{t('dash.estimatedGain', { n: gain })}</span>
          </div>
          <div className="mt-5 grid gap-3 lg:grid-cols-3">
            {priorityFixes.map((c, i) => (
              <button key={c.checkId} onClick={() => { setFilter(c.severity === 'info' ? 'all' : c.severity as Filter); setExpanded(c.checkId); window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' }) }} className="group text-start rounded-2xl border border-surface-800 bg-surface-950/55 p-4 transition hover:-translate-y-0.5 hover:border-brand-500/30">
                <div className="flex items-center justify-between gap-3"><span className="flex h-7 w-7 items-center justify-center rounded-lg bg-brand-500/10 text-xs font-bold text-brand-300">0{i + 1}</span><SeverityBadge severity={c.severity} /></div>
                <p className="mt-4 line-clamp-2 font-semibold text-slate-100">{c.title}</p>
                <p className="mt-2 text-xs text-slate-500">{t('scan.recover')}: +{c.scoreImpact}</p>
              </button>
            ))}
          </div>
        </section>
      )}

      <section>
        <div className="mb-3 flex flex-wrap items-center justify-between gap-3"><h2 className="text-xl font-bold text-white">{t('scan.findings')}</h2><span className="text-xs text-slate-500">{visible.length} / {checks.length}</span></div>
        <div className="flex flex-wrap gap-2 rounded-2xl border border-surface-800/80 bg-surface-900/45 p-2">
          {TABS.map((tab) => {
            const count = tab === 'all' ? findings.length : tab === 'passed' ? passed.length : findings.filter((c) => c.severity === tab).length
            return <button key={tab} onClick={() => setFilter(tab)} className={cn('rounded-full px-3.5 py-1.5 text-sm font-medium transition', filter === tab ? 'bg-brand-600 text-white shadow-lg shadow-brand-900/20' : 'bg-surface-800 text-slate-400 hover:bg-surface-700')}><span>{tab === 'all' ? t('scan.filter.all') : tab === 'passed' ? t('common.passed') : t(`common.${tab}`)}</span><span className="ms-1.5 text-[10px] opacity-60">{count}</span></button>
          })}
        </div>
      </section>

      <div className="space-y-3">
        {visible.length === 0 && <div className="card p-8 text-center text-sm text-slate-500">{t('scan.noFindings')}</div>}
        {visible.map((c) => {
          const isOpen = expanded === c.checkId
          return (
            <details key={c.checkId} open={isOpen} onToggle={(e) => setExpanded(e.currentTarget.open ? c.checkId : null)} className="cyber-glass overflow-hidden">
              <summary className="flex cursor-pointer list-none items-center gap-3 p-4 sm:p-5 [&::-webkit-details-marker]:hidden">
                <SeverityBadge severity={c.status === 'pass' ? 'passed' : c.severity} />
                <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-slate-100">{c.title}</p><p className="mt-1 text-[11px] uppercase tracking-wider text-slate-600">{t(categoryKey[c.category])}</p></div>
                {c.status !== 'pass' && <span className="hidden rounded-full border border-brand-500/15 bg-brand-500/5 px-2.5 py-1 text-[11px] text-brand-300 sm:inline">-{c.scoreImpact} {t('scan.points')}</span>}
                <span className="text-slate-600 transition group-open:rotate-180">⌄</span>
              </summary>
              <div className="border-t border-surface-800 p-4 sm:p-5">
                <div className="grid gap-3 sm:grid-cols-2">
                  <InfoBlock label={t('scan.field.evidence')} value={c.evidence} mono />
                  <InfoBlock label={t('scan.field.impact')} value={c.impact} />
                  <InfoBlock label={t('scan.field.description')} value={c.description} />
                  <InfoBlock label={t('scan.field.recommendation')} value={c.recommendation} />
                </div>
                <div className="mt-3 rounded-2xl border border-brand-500/15 bg-brand-500/5 p-4"><p className="text-xs font-semibold uppercase tracking-wider text-brand-300">{t('scan.field.remediation')}</p><p className="mt-2 whitespace-pre-wrap break-words font-mono text-xs leading-6 text-slate-300">{c.remediation}</p></div>
              </div>
            </details>
          )
        })}
      </div>

      {passed.length > 0 && filter !== 'passed' && (
        <section className="rounded-2xl border border-sev-passed/15 bg-sev-passed/5 p-5">
          <div className="flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-sev-passed/10 text-sev-passed">✓</span><div><h3 className="font-semibold text-white">{t('scan.passed.title')}</h3><p className="text-sm text-slate-500">{t('scan.passed.summary', { n: passed.length })}</p></div></div>
          <button onClick={() => setFilter('passed')} className="mt-4 text-sm font-semibold text-sev-passed hover:underline">{t('scan.passed.view')}</button>
        </section>
      )}
    </div>
  )
}

function InfoBlock({ label, value, mono = false }: { label: string; value: string; mono?: boolean }) {
  return <div className="rounded-2xl border border-surface-800 bg-surface-950/45 p-4"><p className="text-xs font-semibold uppercase tracking-wider text-slate-500">{label}</p><p className={cn('mt-2 whitespace-pre-wrap break-words text-sm leading-6 text-slate-300', mono && 'font-mono text-xs')}>{value || '—'}</p></div>
}
