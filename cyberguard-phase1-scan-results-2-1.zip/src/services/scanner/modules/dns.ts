import type { CheckResult, CheckCategory, ScanInput } from '../../../types'

type Check = Omit<CheckResult, 'scoreImpact'>

function check(partial: Check): Check { return partial }

export function analyzeDns(input: ScanInput): Omit<CheckResult, 'scoreImpact'>[] {
  const checks: Check[] = []
  const a = (input.dns?.a as string[] | undefined) ?? null

  if (a === null) {
    checks.push(check({
      checkId: 'dns.unavailable', module: 'dns', category: 'dns', severity: 'info', status: 'info',
      title: 'DNS records unavailable in this scan mode',
      evidence: 'DNS resolution data was not collected for this scan.',
      description: 'DNS-based checks ( SPF/DMARC for mail, multi-CDN exposure) were skipped.',
      impact: 'Informational only.',
      recommendation: 'Use a full scan (Edge Function) to include DNS checks.',
      remediation: 'N/A',
    }))
    return checks
  }

  if (a.length === 0) {
    checks.push(check({
      checkId: 'dns.a', module: 'dns', category: 'dns', severity: 'low', status: 'warn',
      title: 'No A record resolved',
      evidence: `DNS query for ${String(input.dns.hostname ?? 'the hostname')} returned no A records during the scan.`,
      description: 'The hostname did not resolve to an IPv4 address at scan time, yet the page was reachable. This may be normal (IPv6-only) or transient.',
      impact: 'Low: may indicate DNS misconfiguration or IPv6-only deployment.',
      recommendation: 'Verify DNS configuration and IPv6 reachability.',
      remediation: 'Check A and AAAA records at your DNS provider.',
    }))
  } else {
    checks.push(check({
      checkId: 'dns.a', module: 'dns', category: 'dns', severity: 'passed', status: 'pass',
      title: 'DNS resolves correctly',
      evidence: `A record(s): ${a.join(', ')}`,
      description: 'The hostname resolves to at least one IPv4 address.',
      impact: 'Confirms basic DNS health.',
      recommendation: 'No action required.', remediation: 'N/A',
    }))
  }

  return checks
}
