// إدارة حسابات المستخدمين — superadmin فقط
// actions: "info" (جلب البريد وبيانات الدخول) | "reset_password" (تعيين كلمة سر جديدة)
import { createClient } from "jsr:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: Record<string, unknown>, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const { action, user_id, new_password } = await req.json();
    if (!action || !user_id) return json({ error: "action و user_id مطلوبان" }, 400);

    // التحقق: المنفِّذ يجب أن يكون superadmin
    const userClient = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: me, error: meErr } = await userClient.auth.getUser();
    if (meErr || !me?.user) return json({ error: "غير مصرّح" }, 401);
    const { data: isAdmin } = await userClient.rpc("is_superadmin");
    if (!isAdmin) return json({ error: "صلاحيات غير كافية (superadmin فقط)" }, 403);

    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    if (action === "info") {
      const { data: u, error } = await admin.auth.admin.getUserById(user_id);
      if (error || !u?.user) return json({ error: "المستخدم غير موجود في نظام المصادقة" }, 404);
      return json({ success: true, email: u.user.email ?? null, created_at: u.user.created_at, last_sign_in_at: u.user.last_sign_in_at ?? null });
    }

    if (action === "reset_password") {
      if (!new_password || new_password.length < 8) return json({ error: "كلمة السر يجب أن تكون 8 أحرف على الأقل" }, 400);
      const { error } = await admin.auth.admin.updateUserById(user_id, { password: new_password });
      if (error) return json({ error: `فشل تحديث كلمة السر: ${error.message}` }, 400);
      return json({ success: true });
    }

    return json({ error: "action غير معروف (info | reset_password)" }, 400);
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : String(e) }, 500);
  }
});
