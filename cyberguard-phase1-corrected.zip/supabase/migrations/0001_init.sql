-- CyberGuard Phase 1 — initial schema with Row Level Security
-- All tables use UUID primary keys. Users can only access their own data.

create extension if not exists "pgcrypto";

-- ---------- helpers ----------
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

-- ---------- profiles ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text,
  preferred_language text not null default 'en' check (preferred_language in ('en','fr','ar')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', ''));
  insert into public.notification_preferences (user_id) values (new.id)
  on conflict do nothing;
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- websites ----------
create table public.websites (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  url text not null,
  normalized_url text not null,
  name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, normalized_url)
);

-- ---------- scans ----------
create table public.scans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  website_id uuid references public.websites(id) on delete set null,
  scan_type text not null default 'website' check (scan_type in ('website','application','file')),
  target text not null,
  status text not null default 'pending' check (status in ('pending','running','completed','failed')),
  security_score int check (security_score between 0 and 100),
  privacy_score int check (privacy_score between 0 and 100),
  risk_level text check (risk_level in ('critical','high','medium','low')),
  findings_count int not null default 0,
  passed_count int not null default 0,
  error_message text,
  created_at timestamptz not null default now(),
  completed_at timestamptz
);

-- ---------- scan_results (deterministic checks, one row per check) ----------
create table public.scan_results (
  id uuid primary key default gen_random_uuid(),
  scan_id uuid not null references public.scans(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  check_id text not null,
  module text not null,
  category text not null,
  severity text not null check (severity in ('critical','high','medium','low','passed','info')),
  status text not null check (status in ('fail','warn','pass','info')),
  title text not null,
  evidence text,
  description text,
  impact text,
  recommendation text,
  remediation text,
  score_impact numeric not null default 0,
  created_at timestamptz not null default now(),
  unique (scan_id, check_id)
);

-- ---------- security_history (score timeline per target) ----------
create table public.security_history (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  target text not null,
  scan_id uuid references public.scans(id) on delete set null,
  security_score int not null check (security_score between 0 and 100),
  privacy_score int check (privacy_score between 0 and 100),
  findings_count int not null default 0,
  recorded_at timestamptz not null default now()
);

-- ---------- monitoring (architecture prepared for Phase 2+) ----------
create table public.monitoring_targets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  website_id uuid not null references public.websites(id) on delete cascade,
  enabled boolean not null default false,
  interval_hours int not null default 24,
  last_checked_at timestamptz,
  created_at timestamptz not null default now(),
  unique (user_id, website_id)
);

-- ---------- alerts ----------
create table public.alerts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  alert_type text not null check (alert_type in (
    'critical_security_issue','security_score_decreased','ssl_expiration_warning',
    'new_tracker_detected','configuration_changed','issue_fixed')),
  title text not null,
  body text,
  read boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---------- applications (Phase 2+, schema prepared) ----------
create table public.applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  file_name text not null,
  package_name text,
  version_name text,
  created_at timestamptz not null default now()
);

create table public.application_scans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  application_id uuid not null references public.applications(id) on delete cascade,
  scan_id uuid references public.scans(id) on delete set null,
  security_score int check (security_score between 0 and 100),
  results jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now()
);

-- ---------- files (Phase 2+, schema prepared) ----------
create table public.files (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  file_name text not null,
  file_size bigint,
  mime_type text,
  created_at timestamptz not null default now()
);

create table public.file_scans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  file_id uuid not null references public.files(id) on delete cascade,
  scan_id uuid references public.scans(id) on delete set null,
  security_score int check (security_score between 0 and 100),
  results jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now()
);

-- ---------- reports ----------
create table public.reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  scan_id uuid references public.scans(id) on delete set null,
  title text not null,
  format text not null default 'html' check (format in ('html','pdf')),
  content jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- ---------- subscriptions ----------
create table public.subscription_plans (
  id uuid primary key default gen_random_uuid(),
  code text not null unique check (code in ('free','pro','business')),
  name text not null,
  price_monthly numeric(10,2) not null default 0,
  features jsonb not null default '{}'::jsonb
);

create table public.user_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  plan_id uuid not null references public.subscription_plans(id),
  status text not null default 'active' check (status in ('active','canceled','expired')),
  current_period_end timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id)
);

-- ---------- notification preferences ----------
create table public.notification_preferences (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  email_critical boolean not null default true,
  email_score_change boolean not null default true,
  email_ssl_expiration boolean not null default true,
  email_new_tracker boolean not null default false,
  email_digest boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------- updated_at triggers ----------
create trigger trg_profiles_updated before update on public.profiles for each row execute function public.set_updated_at();
create trigger trg_websites_updated before update on public.websites for each row execute function public.set_updated_at();
create trigger trg_subscriptions_updated before update on public.user_subscriptions for each row execute function public.set_updated_at();
create trigger trg_notifpref_updated before update on public.notification_preferences for each row execute function public.set_updated_at();

-- ---------- default plans ----------
insert into public.subscription_plans (code, name, price_monthly, features) values
('free', 'Free', 0, '{"websites": 1, "history_days": 30, "monitoring": false, "reports": false, "app_scanning": false, "file_scanning": false, "ai_advisor": false}'),
('pro', 'Pro', 9.99, '{"websites": 5, "history_days": 365, "monitoring": true, "reports": true, "app_scanning": true, "file_scanning": true, "ai_advisor": true}'),
('business', 'Business', 29.99, '{"websites": 25, "history_days": 730, "monitoring": true, "reports": true, "app_scanning": true, "file_scanning": true, "ai_advisor": true, "team": true, "api": false}');

-- ---------- indexes ----------
create index idx_websites_user on public.websites(user_id);
create index idx_scans_user on public.scans(user_id, created_at desc);
create index idx_scan_results_scan on public.scan_results(scan_id);
create index idx_history_user_target on public.security_history(user_id, target, recorded_at desc);
create index idx_alerts_user on public.alerts(user_id, created_at desc);

-- ---------- Row Level Security ----------
alter table public.profiles enable row level security;
alter table public.websites enable row level security;
alter table public.scans enable row level security;
alter table public.scan_results enable row level security;
alter table public.security_history enable row level security;
alter table public.monitoring_targets enable row level security;
alter table public.alerts enable row level security;
alter table public.applications enable row level security;
alter table public.application_scans enable row level security;
alter table public.files enable row level security;
alter table public.file_scans enable row level security;
alter table public.reports enable row level security;
alter table public.user_subscriptions enable row level security;
alter table public.notification_preferences enable row level security;
-- subscription_plans is public read-only reference data
alter table public.subscription_plans enable row level security;

create policy "profiles_select_own" on public.profiles for select using (auth.uid() = id);
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

create policy "websites_select_own" on public.websites for select using (auth.uid() = user_id);
create policy "websites_insert_own" on public.websites for insert with check (auth.uid() = user_id);
create policy "websites_update_own" on public.websites for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "websites_delete_own" on public.websites for delete using (auth.uid() = user_id);

create policy "scans_select_own" on public.scans for select using (auth.uid() = user_id);
create policy "scans_insert_own" on public.scans for insert with check (auth.uid() = user_id);
create policy "scans_update_own" on public.scans for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "scans_delete_own" on public.scans for delete using (auth.uid() = user_id);

create policy "scan_results_select_own" on public.scan_results for select using (auth.uid() = user_id);
create policy "scan_results_insert_own" on public.scan_results for insert with check (auth.uid() = user_id and exists (select 1 from public.scans s where s.id = scan_id and s.user_id = auth.uid()));
create policy "scan_results_delete_own" on public.scan_results for delete using (auth.uid() = user_id);

create policy "history_select_own" on public.security_history for select using (auth.uid() = user_id);
create policy "history_insert_own" on public.security_history for insert with check (auth.uid() = user_id and (scan_id is null or exists (select 1 from public.scans s where s.id = scan_id and s.user_id = auth.uid())));
create policy "history_delete_own" on public.security_history for delete using (auth.uid() = user_id);

create policy "monitoring_select_own" on public.monitoring_targets for select using (auth.uid() = user_id);
create policy "monitoring_insert_own" on public.monitoring_targets for insert with check (auth.uid() = user_id and exists (select 1 from public.websites w where w.id = website_id and w.user_id = auth.uid()));
create policy "monitoring_update_own" on public.monitoring_targets for update using (auth.uid() = user_id) with check (auth.uid() = user_id and exists (select 1 from public.websites w where w.id = website_id and w.user_id = auth.uid()));
create policy "monitoring_delete_own" on public.monitoring_targets for delete using (auth.uid() = user_id);

create policy "alerts_select_own" on public.alerts for select using (auth.uid() = user_id);
create policy "alerts_update_own" on public.alerts for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "alerts_delete_own" on public.alerts for delete using (auth.uid() = user_id);

create policy "applications_select_own" on public.applications for select using (auth.uid() = user_id);
create policy "applications_insert_own" on public.applications for insert with check (auth.uid() = user_id);
create policy "applications_delete_own" on public.applications for delete using (auth.uid() = user_id);

create policy "app_scans_select_own" on public.application_scans for select using (auth.uid() = user_id);
create policy "app_scans_insert_own" on public.application_scans for insert with check (auth.uid() = user_id and exists (select 1 from public.applications a where a.id = application_id and a.user_id = auth.uid()) and (scan_id is null or exists (select 1 from public.scans s where s.id = scan_id and s.user_id = auth.uid())));

create policy "files_select_own" on public.files for select using (auth.uid() = user_id);
create policy "files_insert_own" on public.files for insert with check (auth.uid() = user_id);
create policy "files_delete_own" on public.files for delete using (auth.uid() = user_id);

create policy "file_scans_select_own" on public.file_scans for select using (auth.uid() = user_id);
create policy "file_scans_insert_own" on public.file_scans for insert with check (auth.uid() = user_id and exists (select 1 from public.files f where f.id = file_id and f.user_id = auth.uid()) and (scan_id is null or exists (select 1 from public.scans s where s.id = scan_id and s.user_id = auth.uid())));

create policy "reports_select_own" on public.reports for select using (auth.uid() = user_id);
create policy "reports_insert_own" on public.reports for insert with check (auth.uid() = user_id and (scan_id is null or exists (select 1 from public.scans s where s.id = scan_id and s.user_id = auth.uid())));
create policy "reports_delete_own" on public.reports for delete using (auth.uid() = user_id);

create policy "subscriptions_select_own" on public.user_subscriptions for select using (auth.uid() = user_id);
create policy "plans_select_all" on public.subscription_plans for select using (true);

create policy "notifpref_select_own" on public.notification_preferences for select using (auth.uid() = user_id);
create policy "notifpref_update_own" on public.notification_preferences for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ---------- private storage bucket for future uploads (never public) ----------
insert into storage.buckets (id, name, public)
values ('uploads', 'uploads', false)
on conflict (id) do nothing;

create policy "uploads_select_own" on storage.objects for select
  using (bucket_id = 'uploads' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "uploads_insert_own" on storage.objects for insert
  with check (bucket_id = 'uploads' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "uploads_delete_own" on storage.objects for delete
  using (bucket_id = 'uploads' and auth.uid()::text = (storage.foldername(name))[1]);
