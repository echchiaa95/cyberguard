-- CyberGuard Phase 1 — RLS integrity hardening (0002)
-- Strengthens INSERT/UPDATE authorization so a user can never attach child
-- records (scan_results, history, monitoring, app/file scans, reports) to
-- another user's parent records. Non-destructive: no table changes, no data
-- touched. Replaces INSERT/UPDATE policies with stricter versions; SELECT and
-- DELETE ownership policies from 0001 are kept unchanged.

-- ============================================================================
-- 1. notification_preferences — the app uses upsert, so INSERT is required
-- ============================================================================
drop policy if exists "notifpref_insert_own" on public.notification_preferences;
create policy "notifpref_insert_own"
  on public.notification_preferences for insert
  with check (auth.uid() = user_id);
-- existing notifpref_select_own / notifpref_update_own kept as-is.

-- ============================================================================
-- 2. scan_results — scan_id must reference a scan owned by the same user
-- ============================================================================
drop policy if exists "scan_results_insert_own" on public.scan_results;
create policy "scan_results_insert_own"
  on public.scan_results for insert
  with check (
    auth.uid() = user_id
    and exists (
      select 1 from public.scans s
      where s.id = scan_id and s.user_id = auth.uid()
    )
  );
-- scan_results.scan_id is NOT NULL, so a plain EXISTS is sufficient.

-- ============================================================================
-- 2b. scans — website_id must reference an owned website (or be NULL)
-- ============================================================================
drop policy if exists "scans_insert_own" on public.scans;
create policy "scans_insert_own"
  on public.scans for insert
  with check (
    auth.uid() = user_id
    and (website_id is null or exists (
      select 1 from public.websites w
      where w.id = website_id and w.user_id = auth.uid()
    ))
  );

drop policy if exists "scans_update_own" on public.scans;
create policy "scans_update_own"
  on public.scans for update
  using (auth.uid() = user_id)
  with check (
    auth.uid() = user_id
    and (website_id is null or exists (
      select 1 from public.websites w
      where w.id = website_id and w.user_id = auth.uid()
    ))
  );

-- ============================================================================
-- 3. security_history — optional scan_id must reference an owned scan
-- ============================================================================
drop policy if exists "history_insert_own" on public.security_history;
create policy "history_insert_own"
  on public.security_history for insert
  with check (
    auth.uid() = user_id
    and (scan_id is null or exists (
      select 1 from public.scans s
      where s.id = scan_id and s.user_id = auth.uid()
    ))
  );

-- ============================================================================
-- 4. monitoring_targets — website_id must reference an owned website
--    (INSERT and UPDATE both re-checked)
-- ============================================================================
drop policy if exists "monitoring_insert_own" on public.monitoring_targets;
create policy "monitoring_insert_own"
  on public.monitoring_targets for insert
  with check (
    auth.uid() = user_id
    and exists (
      select 1 from public.websites w
      where w.id = website_id and w.user_id = auth.uid()
    )
  );

drop policy if exists "monitoring_update_own" on public.monitoring_targets;
create policy "monitoring_update_own"
  on public.monitoring_targets for update
  using (auth.uid() = user_id)
  with check (
    auth.uid() = user_id
    and exists (
      select 1 from public.websites w
      where w.id = website_id and w.user_id = auth.uid()
    )
  );

-- ============================================================================
-- 5. application_scans — application_id owned; optional scan_id owned
-- ============================================================================
drop policy if exists "app_scans_insert_own" on public.application_scans;
create policy "app_scans_insert_own"
  on public.application_scans for insert
  with check (
    auth.uid() = user_id
    and exists (
      select 1 from public.applications a
      where a.id = application_id and a.user_id = auth.uid()
    )
    and (scan_id is null or exists (
      select 1 from public.scans s
      where s.id = scan_id and s.user_id = auth.uid()
    ))
  );

-- ============================================================================
-- 6. file_scans — file_id owned; optional scan_id owned
-- ============================================================================
drop policy if exists "file_scans_insert_own" on public.file_scans;
create policy "file_scans_insert_own"
  on public.file_scans for insert
  with check (
    auth.uid() = user_id
    and exists (
      select 1 from public.files f
      where f.id = file_id and f.user_id = auth.uid()
    )
    and (scan_id is null or exists (
      select 1 from public.scans s
      where s.id = scan_id and s.user_id = auth.uid()
    ))
  );

-- ============================================================================
-- 7. reports — optional scan_id must reference an owned scan
-- ============================================================================
drop policy if exists "reports_insert_own" on public.reports;
create policy "reports_insert_own"
  on public.reports for insert
  with check (
    auth.uid() = user_id
    and (scan_id is null or exists (
      select 1 from public.scans s
      where s.id = scan_id and s.user_id = auth.uid()
    ))
  );

-- ============================================================================
-- 8. Security review — foreign-key/ownership audit of user-owned data
-- ----------------------------------------------------------------------------
-- Checked every relationship; cross-user risks are now closed by the policies
-- above. Deliberately unchanged:
--   * subscription_plans : public read-only reference data (select for all) —
--     no INSERT/UPDATE/DELETE policies, intentionally.
--   * user_subscriptions : system-managed (no INSERT policy) — correct.
--   * alerts             : system-managed (SELECT/UPDATE/DELETE own only, no
--     INSERT) — correct.
--   * profiles           : system-managed via handle_new_user() trigger
--     (SELECT/UPDATE own only, no INSERT) — correct.
--   * scans.website_id   : hardened — INSERT and UPDATE both require
--     website_id IS NULL or ownership of the referenced website (policies
--     "scans_insert_own" / "scans_update_own" replaced in section 2b). The
--     cross-user relationship is no longer possible at all.
-- No USING (true) policy was added for any user-owned table. RLS stays enabled
-- everywhere; nothing was disabled or broadened.
-- ============================================================================
