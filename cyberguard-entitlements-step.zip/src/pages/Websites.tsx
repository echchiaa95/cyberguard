import { FormEvent, useEffect, useMemo, useState, type ReactNode } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import { useI18n } from '../lib/i18n'
import { EmptyState } from '../components/EmptyState'
import { ScoreRing } from '../components/ScoreRing'
import { SeverityBadge } from '../components/SeverityBadge'
import { cn, normalizeUrl } from '../lib/utils'
import { addWebsite, createScanRecord, deleteWebsite, failScanRecord, getScanChecks, listHistory, listScans, listWebsites, saveScanResult } from '../services/db'
import { getMyEntitlements, websiteLimit } from '../services/entitlements'
import { runWebsiteScan, type ScanProgressStep } from '../services/scanner'
import type { CheckResult, HistoryPoint, ScanRecord, Website } from '../types'

const STEPS: ScanProgressStep[] = ['fetch', 'headers', 'cookies', 'privacy', 'scoring']

export function Websites() {
  const { user } = useAuth()
  const { t } = useI18n()
  const [sites, setSites] = useState<Website[]>([])
  const [error, setError] = useState<string | null>(null)
  const [siteLimit, setSiteLimit] = useState(1)

  const load = async () => {
    if (!user) return
    const [items, plan] = await Promise.all([listWebsites(user.id), getMyEntitlements()])
    setSites(items)
    setSiteLimit(websiteLimit(plan))
  }
  useEffect(() => { void load() }, [user])

  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setError(null)
    const form = e.currentTarget
    const raw = String(new FormData(form).get('url') ?? '')
    const normalized = normalizeUrl(raw)
    if (!normalized) { setError(t('sites.invalidUrl')); return }
    if (!user) { setError('You must be signed in to add a website.'); return }
    if (sites.length >= siteLimit) {
      setError(`Your current plan allows ${siteLimit} website${siteLimit === 1 ? '' : 's'}. Upgrade to add another website.`)
      return
    }
    try {
      await addWebsite(user.id, raw.trim(), normalized)
      form.reset()
      await load()
    } catch (e) {
      const err = e as { message?: string; code?: string; details?: string; hint?: string }
      const parts = [err.message, err.code ? `(code ${err.code})` : undefined, err.details, err.hint].filter(Boolean)
      setError(parts.length ? parts.join(' — ') : 'Unable to add website.')
    }
  }

  return (
    <div className="relative space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div><div className="cyber-kicker">Attack surface</div><h1 className="mt-3 text-3xl font-black tracking-tight text-white">{t('sites.title')}</h1><p className="mt-2 text-sm text-slate-500">{t('sites.subtitle')}</p></div>
        <div className="hidden rounded-xl border border-brand-500/10 bg-brand-500/5 px-3 py-2 font-mono text-[10px] text-brand-400 sm:block">● SCANNER ONLINE</div>
      </div>
      <form onSubmit={submit} className="cyber-glass cyber-glow flex flex-col gap-3 p-4 sm:flex-row">
        <input name="url" className="input flex-1" placeholder={t('sites.urlPlaceholder')} />
        <button className="btn-primary">{t('sites.add')}</button>
      </form>
      {error && <p role="alert" className="text-sm text-sev-critical">{error}</p>}
      {sites.length === 0 ? <EmptyState title={t('common.noData')} hint={t('sites.urlPlaceholder')} /> : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {sites.map((w) => <WebsiteCard key={w.id} site={w} onDelete={async () => { if (window.confirm(t('sites.deleteConfirm'))) { await deleteWebsite(user!.id, w.id); await load() } }} />)}
        </div>
      )}
    </div>
  )
}

function WebsiteCard({ site, onDelete }: { site: Website; onDelete: () => void }) {
  const { t, lang } = useI18n()
  const { user } = useAuth()
  const [last, setLast] = useState<ScanRecord | null>(null)
  const [count, setCount] = useState(0)
  useEffect(() => {
    if (!user) return
    void listScans(user.id, site.id).then((s) => { setLast(s.find((x) => x.status === 'completed') ?? null); setCount(s.filter((x) => x.status === 'completed').length) })
  }, [user, site.id])

  return (
    <div className="cyber-feature flex flex-col p-5">
      <Link to={`/app/websites/${site.id}`} className="truncate font-medium text-brand-400 hover:underline" title={site.url}>{site.name || site.url}</Link>
      <p className="mt-1 truncate font-mono text-[10px] text-slate-700" title={site.url}>{site.url}</p>
      <p className="mt-2 text-xs text-slate-500">{t('sites.lastScan')}: {last ? new Date(last.createdAt).toLocaleDateString(lang) : t('sites.never')} · {t('sites.scans', { n: count })}</p>
      <div className="mt-3 flex items-center gap-2">{last?.securityScore !== undefined && <b className="text-slate-100">{last.securityScore}</b>}{last?.riskLevel && <SeverityBadge severity={last.riskLevel} />}</div>
      <div className="mt-4 flex gap-2"><Link to={`/app/websites/${site.id}`} className="btn-secondary flex-1 !py-1.5 text-xs">{t('sites.viewDetails')}</Link><button onClick={onDelete} className="btn-secondary !py-1.5 text-xs text-sev-critical">{t('common.delete')}</button></div>
    </div>
  )
}

export function WebsiteDetail() {
  const { id } = useParams()
  const { user } = useAuth()
  const { t, lang } = useI18n()
  const nav = useNavigate()
  const [site, setSite] = useState<Website | null>(null)
  const [scans, setScans] = useState<ScanRecord[]>([])
  const [history, setHistory] = useState<HistoryPoint[]>([])
  const [latestChecks, setLatestChecks] = useState<CheckResult[]>([])
  const [previousChecks, setPreviousChecks] = useState<CheckResult[]>([])
  const [running, setRunning] = useState(false)
  const [step, setStep] = useState<ScanProgressStep>('fetch')
  const [error, setError] = useState<string | null>(null)

  const load = async () => {
    if (!user || !id) return
    const sites = await listWebsites(user.id)
    const current = sites.find((w) => w.id === id) ?? null
    setSite(current)
    if (!current) return
    const [scanRows, historyRows] = await Promise.all([listScans(user.id, id), listHistory(user.id, current.normalizedUrl)])
    const completed = scanRows.filter((s) => s.status === 'completed')
    setScans(scanRows)
    setHistory(historyRows)
    setLatestChecks(completed[0] ? await getScanChecks(user.id, completed[0].id) : [])
    setPreviousChecks(completed[1] ? await getScanChecks(user.id, completed[1].id) : [])
  }

  useEffect(() => { void load() }, [user, id])

  const completed = useMemo(() => scans.filter((s) => s.status === 'completed'), [scans])
  const latest = completed[0] ?? null
  const previous = completed[1] ?? null
  const scoreDelta = latest?.securityScore !== undefined && previous?.securityScore !== undefined ? latest.securityScore - previous.securityScore : null
  const privacyDelta = latest?.privacyScore !== undefined && previous?.privacyScore !== undefined ? latest.privacyScore - previous.privacyScore : null
  const findingsDelta = latest && previous ? latest.findingsCount - previous.findingsCount : null

  const activeFindings = useMemo(() => latestChecks.filter((c) => c.status !== 'pass' && c.severity !== 'info' && c.severity !== 'passed'), [latestChecks])
  const criticalHigh = activeFindings.filter((c) => c.severity === 'critical' || c.severity === 'high').length
  const fixedCount = useMemo(() => {
    if (!latestChecks.length || !previousChecks.length) return 0
    const prev = new Map(previousChecks.map((c) => [c.checkId, c]))
    return latestChecks.filter((c) => c.status === 'pass' && prev.get(c.checkId)?.status !== 'pass').length
  }, [latestChecks, previousChecks])
  const newIssues = useMemo(() => {
    if (!latestChecks.length || !previousChecks.length) return 0
    const prev = new Map(previousChecks.map((c) => [c.checkId, c]))
    return activeFindings.filter((c) => prev.get(c.checkId)?.status === 'pass').length
  }, [activeFindings, previousChecks, latestChecks])
  const trend = history.slice(-6)

  const startScan = async () => {
    if (!user || !site) return
    setRunning(true); setError(null); setStep('fetch')
    let scanId: string | null = null
    try {
      scanId = await createScanRecord(user.id, site.id, site.normalizedUrl)
      const output = await runWebsiteScan(site.normalizedUrl, setStep)
      await saveScanResult(user.id, scanId, output)
      nav(`/app/scans/${scanId}`)
    } catch (e) {
      const err = e as { messageKey?: string; message?: string; code?: string; details?: string; hint?: string }
      const key = err.messageKey ?? 'error.scanUnavailable'
      if (scanId) await failScanRecord(user.id, scanId, key)
      const details = [err.message, err.code ? `(code ${err.code})` : undefined, err.details, err.hint].filter(Boolean).join(' — ')
      setError(details || t(key));
      await load()
    } finally { setRunning(false) }
  }

  if (!site) return <p className="text-slate-400">{t('common.loading')}</p>

  const score = latest?.securityScore ?? 0
  const privacy = latest?.privacyScore ?? 0
  const risk = latest?.riskLevel
  const scoreTone = score >= 85 ? 'text-sev-passed' : score >= 70 ? 'text-brand-300' : score >= 50 ? 'text-sev-high' : 'text-sev-critical'
  const displayName = site.name || site.url

  return (
    <div className="relative space-y-6">
      <section className="cyber-glass relative overflow-hidden p-5 sm:p-7">
        <div className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-brand-500/10 blur-3xl" />
        <div className="relative flex flex-wrap items-center justify-between gap-4">
          <Link to="/app/websites" className="text-sm text-brand-400 hover:text-brand-300">← {t('common.back')}</Link>
          <button type="button" onClick={startScan} disabled={running} className="rounded-xl border border-brand-500/20 bg-brand-500/5 px-4 py-2 text-sm font-semibold text-brand-300 transition hover:bg-brand-500/10 disabled:cursor-wait disabled:opacity-60">+ {running ? t('scan.running') : t('scan.new')}</button>
        </div>
        <div className="relative mt-7 grid gap-7 lg:grid-cols-[1fr_auto] lg:items-center">
          <div className="min-w-0"><div className="cyber-kicker">{t('sites.detail.kicker')}</div><h1 className="mt-3 break-words text-3xl font-black tracking-tight text-white sm:text-4xl" title={site.url}>{displayName}</h1><p className="mt-2 max-w-full truncate font-mono text-xs text-slate-600" title={site.url}>{site.normalizedUrl}</p><div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-slate-500"><span>{t('sites.created')}: {new Date(site.createdAt).toLocaleDateString(lang)}</span>{latest && <span>· {t('sites.lastScan')}: {new Date(latest.createdAt).toLocaleString(lang)}</span>}</div></div>
          <div className="flex items-center justify-center gap-4 sm:gap-7"><ScoreRing score={score} size={132} stroke={10} label={t('dash.securityScore')} /><ScoreRing score={privacy} size={104} stroke={8} label={t('dash.privacyScore')} /></div>
        </div>
      </section>

      {running && <div className="cyber-glass border-brand-500/20 p-4"><div className="flex items-center gap-3"><span className="cyber-dot animate-pulse" /><p className="text-sm font-semibold text-white">{t('scan.running')}</p></div><p className="mt-1 text-xs text-slate-500">{t(`scan.step.${step}`)}</p></div>}
      {error && <div role="alert" className="rounded-xl border border-sev-critical/20 bg-sev-critical/5 p-3 text-sm text-sev-critical">{error}</div>}

      {latest ? (
        <>
          <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Metric label={t('sites.currentScore')} value={score} tone={scoreTone} />
            <Metric label={t('sites.risk')} value={risk ? <SeverityBadge severity={risk} /> : '—'} />
            <Metric label={t('sites.openFindings')} value={latest.findingsCount} tone={latest.findingsCount ? 'text-sev-high' : 'text-sev-passed'} />
            <Metric label={t('sites.scansCompleted')} value={completed.length} />
          </section>

          <section className="cyber-glass p-5 sm:p-6">
            <div className="flex flex-wrap items-end justify-between gap-3"><div><p className="cyber-kicker">{t('sites.posture.kicker')}</p><h2 className="mt-2 text-xl font-bold text-white">{t('sites.posture.title')}</h2></div>{scoreDelta !== null && <DeltaPill delta={scoreDelta} improved={scoreDelta > 0} label={scoreDelta > 0 ? t('hist.improvedBy', { n: scoreDelta }) : scoreDelta < 0 ? t('hist.declinedBy', { n: Math.abs(scoreDelta) }) : t('hist.noChange')} />}</div>
            <div className="mt-5 grid gap-3 sm:grid-cols-3"><Metric label={t('sites.securityChange')} value={scoreDelta === null ? '—' : `${scoreDelta > 0 ? '+' : ''}${scoreDelta}`} tone={scoreDelta === null ? 'text-slate-500' : scoreDelta >= 0 ? 'text-sev-passed' : 'text-sev-critical'} /><Metric label={t('sites.privacyChange')} value={privacyDelta === null ? '—' : `${privacyDelta > 0 ? '+' : ''}${privacyDelta}`} tone={privacyDelta === null ? 'text-slate-500' : privacyDelta >= 0 ? 'text-sev-passed' : 'text-sev-critical'} /><Metric label={t('sites.findingsChange')} value={findingsDelta === null ? '—' : `${findingsDelta > 0 ? '+' : ''}${findingsDelta}`} tone={findingsDelta === null ? 'text-slate-500' : findingsDelta <= 0 ? 'text-sev-passed' : 'text-sev-critical'} /></div>
            {trend.length > 1 && <MiniTrend points={trend.map((h) => h.securityScore)} />}
          </section>

          <section className="grid gap-4 sm:grid-cols-3">
            <MetricCard label={t('sites.openFindings')} value={activeFindings.length} hint={criticalHigh ? `${criticalHigh} ${t('sites.criticalHighOpen')}` : t('sites.noHighRisk')} tone={criticalHigh ? 'text-sev-high' : 'text-sev-passed'} />
            <MetricCard label={t('sites.fixedSincePrevious')} value={fixedCount} hint={previous ? t('sites.comparedWithPrevious') : t('sites.needTwoScans')} tone="text-sev-passed" />
            <MetricCard label={t('sites.newSincePrevious')} value={newIssues} hint={previous ? t('sites.comparedWithPrevious') : t('sites.needTwoScans')} tone={newIssues ? 'text-sev-critical' : 'text-sev-passed'} />
          </section>

          <section className="cyber-feature p-5 sm:p-6">
            <div className="flex flex-wrap items-center justify-between gap-3"><div><p className="cyber-kicker">{t('sites.latest.kicker')}</p><h2 className="mt-2 text-xl font-bold text-white">{t('sites.latest.title')}</h2><p className="mt-1 text-sm text-slate-500">{t('sites.latest.hint')}</p></div><Link to={`/app/scans/${latest.id}`} className="btn-secondary !py-2 text-xs">{t('sites.openResults')} →</Link></div>
            <div className="mt-5 space-y-2">{activeFindings.slice(0, 5).map((c) => <Link key={c.checkId} to={`/app/scans/${latest.id}#finding-${c.checkId}`} className="flex items-center justify-between gap-3 rounded-xl border border-surface-800 bg-surface-950/45 p-3 transition hover:border-brand-500/20"><span className="min-w-0 truncate text-sm font-medium text-slate-200">{c.title}</span><SeverityBadge severity={c.severity} /></Link>)}{activeFindings.length === 0 && <div className="rounded-xl border border-brand-500/15 bg-brand-500/5 p-4 text-sm text-brand-300">{t('sites.noFindings')}</div>}{activeFindings.length > 5 && <Link to={`/app/scans/${latest.id}`} className="block pt-2 text-center text-xs font-semibold text-brand-400">{t('sites.viewAllFindings', { n: activeFindings.length })} →</Link>}</div>
          </section>
        </>
      ) : (
        <section className="cyber-glass p-6 text-center"><div className="cyber-kicker">{t('sites.ready.kicker')}</div><h2 className="mt-3 text-2xl font-bold text-white">{t('sites.ready.title')}</h2><p className="mx-auto mt-2 max-w-xl text-sm leading-6 text-slate-500">{t('sites.ready.hint')}</p><button onClick={startScan} disabled={running} className="btn-primary mt-5">{t('scan.new')}</button></section>
      )}

      <section className="cyber-glass overflow-hidden p-5 sm:p-6">
        <div className="flex items-center justify-between gap-3"><div><p className="cyber-kicker">{t('sites.history.kicker')}</p><h2 className="mt-2 text-xl font-bold text-white">{t('sites.history.title')}</h2></div>{history.length > 1 && <Link to="/app/history" className="text-xs font-semibold text-brand-400">{t('sites.history.full')} →</Link>}</div>
        <div className="mt-5 space-y-2">{completed.slice(0, 6).map((s, i) => { const prev = completed[i + 1]; const d = s.securityScore !== undefined && prev?.securityScore !== undefined ? s.securityScore - prev.securityScore : null; return <div key={s.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-surface-800 bg-surface-950/45 p-3"><div><p className="text-xs text-slate-500">{new Date(s.createdAt).toLocaleString(lang)}</p><p className="mt-1 text-xs text-slate-700">{s.findingsCount} {t('sites.findingsShort')}</p></div><div className="flex items-center gap-3"><b className="text-white">{s.securityScore ?? '—'}</b>{d !== null && <span className={cn('text-xs font-semibold', d >= 0 ? 'text-sev-passed' : 'text-sev-critical')}>{d >= 0 ? '+' : ''}{d}</span>}<Link to={`/app/scans/${s.id}`} className="text-xs font-semibold text-brand-400">{t('common.view')}</Link></div></div> })}{completed.length === 0 && <p className="text-sm text-slate-500">{t('common.noData')}</p>}</div>
      </section>

      <p className="text-center text-[11px] leading-5 text-slate-700">{t('sites.disclaimer')}</p>
    </div>
  )
}

function Metric({ label, value, tone = 'text-white' }: { label: string; value: ReactNode; tone?: string }) {
  return <div className="rounded-2xl border border-surface-800 bg-surface-950/45 p-4"><p className="text-[10px] uppercase tracking-[0.18em] text-slate-600">{label}</p><div className={cn('mt-2 text-xl font-black tabular-nums', tone)}>{value}</div></div>
}

function MetricCard({ label, value, hint, tone }: { label: string; value: number; hint: string; tone: string }) {
  return <div className="rounded-2xl border border-surface-800 bg-surface-950/45 p-4"><p className="text-[10px] uppercase tracking-[0.18em] text-slate-600">{label}</p><p className={cn('mt-2 text-3xl font-black tabular-nums', tone)}>{value}</p><p className="mt-1 text-xs text-slate-600">{hint}</p></div>
}

function DeltaPill({ delta, improved, label }: { delta: number; improved: boolean; label: string }) {
  return <span className={cn('rounded-full border px-3 py-1.5 text-xs font-semibold', improved ? 'border-brand-500/20 bg-brand-500/5 text-brand-300' : delta < 0 ? 'border-sev-critical/20 bg-sev-critical/5 text-sev-critical' : 'border-surface-800 bg-surface-900 text-slate-500')}>{label}</span>
}

function MiniTrend({ points }: { points: number[] }) {
  const width = 600, height = 120, pad = 10
  const min = Math.max(0, Math.min(...points) - 10), max = Math.min(100, Math.max(...points) + 10)
  const x = (i: number) => pad + (i / Math.max(1, points.length - 1)) * (width - pad * 2)
  const y = (v: number) => height - pad - ((v - min) / Math.max(1, max - min)) * (height - pad * 2)
  const path = points.map((v, i) => `${i ? 'L' : 'M'}${x(i)},${y(v)}`).join(' ')
  return <div className="mt-6 overflow-hidden rounded-2xl border border-surface-800 bg-surface-950/40 p-3"><svg viewBox={`0 0 ${width} ${height}`} className="h-28 w-full" role="img" aria-label="Security score trend"><line x1="10" x2="590" y1="110" y2="110" stroke="rgba(148,163,184,.10)" /><path d={path} fill="none" stroke="#10b981" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />{points.map((v, i) => <circle key={`${i}-${v}`} cx={x(i)} cy={y(v)} r="4" fill="#07111d" stroke="#10b981" strokeWidth="2"><title>{v}</title></circle>)}</svg></div>
}
