import { FormEvent, useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import { useI18n } from '../lib/i18n'
import { Logo } from '../components/Logo'

function Shell({ children, title, subtitle }: { children: React.ReactNode; title: string; subtitle: string }) {
  const { isDemo } = useAuth()
  return (
    <div className="flex min-h-screen items-center justify-center bg-surface-950 p-4">
      <div className="w-full max-w-md">
        <div className="mb-6 flex items-center justify-center gap-2">
          <Logo size={32} />
          <span className="text-lg font-bold text-white">CyberGuard</span>
          {isDemo && <span className="badge border-sev-medium/40 bg-sev-medium/10 text-sev-medium">Demo</span>}
        </div>
        <div className="card p-6">
          <h1 className="text-xl font-bold text-white">{title}</h1>
          <p className="mt-1 text-sm text-slate-400">{subtitle}</p>
          <div className="mt-6">{children}</div>
        </div>
      </div>
    </div>
  )
}

export function Login() {
  const { t } = useI18n()
  const { signIn, isConfigured, isDemo } = useAuth()
  const nav = useNavigate()
  const [err, setErr] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setBusy(true)
    setErr(null)
    const fd = new FormData(e.currentTarget)
    const { error } = await signIn(String(fd.get('email')), String(fd.get('password')))
    setBusy(false)
    if (error) setErr(t(error))
    else nav('/app')
  }

  return (
    <Shell title={t('auth.login.title')} subtitle={t('auth.login.subtitle')}>
      {!isConfigured && !isDemo && <p className="mb-4 text-sm text-sev-high">{t('auth.error.config')}</p>}
      <form onSubmit={submit} className="space-y-4">
        <div>
          <label className="label" htmlFor="login-email">{t('auth.email')}</label>
          <input id="login-email" name="email" type="email" required className="input" autoComplete="email" />
        </div>
        <div>
          <label className="label" htmlFor="login-password">{t('auth.password')}</label>
          <input id="login-password" name="password" type="password" required minLength={6} className="input" autoComplete="current-password" />
        </div>
        {err && <p role="alert" className="text-sm text-sev-critical">{err}</p>}
        <button className="btn-primary w-full" disabled={busy}>{t('auth.login.button')}</button>
      </form>
      <div className="mt-4 flex justify-between text-sm">
        <Link to="/forgot-password" className="text-brand-400 hover:underline">{t('auth.forgot.title')}</Link>
        <Link to="/signup" className="text-brand-400 hover:underline">{t('auth.login.noAccount')}</Link>
      </div>
    </Shell>
  )
}

export function Signup() {
  const { t } = useI18n()
  const { signUp, isConfigured, isDemo } = useAuth()
  const nav = useNavigate()
  const [err, setErr] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setBusy(true)
    setErr(null)
    const fd = new FormData(e.currentTarget)
    const { error } = await signUp(String(fd.get('email')), String(fd.get('password')), String(fd.get('fullName') ?? ''))
    setBusy(false)
    if (error) setErr(t(error))
    else nav('/app')
  }

  return (
    <Shell title={t('auth.signup.title')} subtitle={t('auth.signup.subtitle')}>
      {!isConfigured && !isDemo && <p className="mb-4 text-sm text-sev-high">{t('auth.error.config')}</p>}
      <form onSubmit={submit} className="space-y-4">
        <div>
          <label className="label" htmlFor="su-name">{t('auth.fullName')}</label>
          <input id="su-name" name="fullName" className="input" autoComplete="name" />
        </div>
        <div>
          <label className="label" htmlFor="su-email">{t('auth.email')}</label>
          <input id="su-email" name="email" type="email" required className="input" autoComplete="email" />
        </div>
        <div>
          <label className="label" htmlFor="su-password">{t('auth.password')}</label>
          <input id="su-password" name="password" type="password" required minLength={8} className="input" autoComplete="new-password" />
        </div>
        {err && <p role="alert" className="text-sm text-sev-critical">{err}</p>}
        <button className="btn-primary w-full" disabled={busy}>{t('auth.signup.button')}</button>
      </form>
      <p className="mt-4 text-sm">
        <Link to="/login" className="text-brand-400 hover:underline">{t('auth.signup.haveAccount')}</Link>
      </p>
    </Shell>
  )
}

export function ForgotPassword() {
  const { t } = useI18n()
  const { sendResetLink } = useAuth()
  const [sent, setSent] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const fd = new FormData(e.currentTarget)
    const { error } = await sendResetLink(String(fd.get('email')))
    if (error) setErr(t(error))
    else setSent(true)
  }

  return (
    <Shell title={t('auth.forgot.title')} subtitle={t('auth.forgot.subtitle')}>
      {sent ? (
        <p className="text-sm text-sev-passed">{t('auth.forgot.sent')}</p>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          <div>
            <label className="label" htmlFor="fp-email">{t('auth.email')}</label>
            <input id="fp-email" name="email" type="email" required className="input" autoComplete="email" />
          </div>
          {err && <p role="alert" className="text-sm text-sev-critical">{err}</p>}
          <button className="btn-primary w-full">{t('auth.forgot.button')}</button>
        </form>
      )}
      <p className="mt-4 text-sm">
        <Link to="/login" className="text-brand-400 hover:underline">{t('common.back')}</Link>
      </p>
    </Shell>
  )
}

export function ResetPassword() {
  const { t } = useI18n()
  const { updatePassword } = useAuth()
  const nav = useNavigate()
  const [err, setErr] = useState<string | null>(null)
  const [done, setDone] = useState(false)

  // Proper navigation after a successful update — never side effects during render.
  useEffect(() => {
    if (!done) return
    const timer = setTimeout(() => nav('/login'), 1500)
    return () => clearTimeout(timer)
  }, [done, nav])

  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const fd = new FormData(e.currentTarget)
    const { error } = await updatePassword(String(fd.get('password')))
    if (error) setErr(t(error))
    else setDone(true)
  }

  return (
    <Shell title={t('auth.reset.title')} subtitle="">
      {done ? (
        <p className="text-sm text-sev-passed">
          {t('settings.saved')} — <Link to="/login" className="underline">{t('auth.login.button')}</Link>
        </p>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          <div>
            <label className="label" htmlFor="rp-password">{t('auth.password')}</label>
            <input
              id="rp-password"
              name="password"
              type="password"
              required
              minLength={8}
              className="input"
              autoComplete="new-password"
            />
          </div>
          {err && <p role="alert" className="text-sm text-sev-critical">{err}</p>}
          <button className="btn-primary w-full">{t('auth.reset.button')}</button>
        </form>
      )}
    </Shell>
  )
}
