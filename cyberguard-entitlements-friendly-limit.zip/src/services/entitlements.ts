import { supabase } from '../lib/supabase'

export type PlanCode = 'free' | 'pro' | 'business'

export interface PlanEntitlements {
  code: PlanCode
  name: string
  priceMonthly: number
  features: Record<string, unknown>
}

const FREE_FEATURES: Record<string, unknown> = {
  websites: 1,
  history_days: 7,
  reports: false,
  ai_advisor: false,
  monitoring: false,
  rescan: true,
  traffic_gb: 0,
  shield: false,
  waf: false,
  rate_limiting: false,
  bot_protection: false,
  basic_ddos: false,
  ssl_monitoring: false,
  dns_monitoring: false,
  certificate: false,
  app_scanning: false,
  file_scanning: false,
}

export const FREE_ENTITLEMENTS: PlanEntitlements = {
  code: 'free',
  name: 'Free',
  priceMonthly: 0,
  features: FREE_FEATURES,
}

export async function getMyEntitlements(): Promise<PlanEntitlements> {
  if (!supabase) return FREE_ENTITLEMENTS

  const { data: subscription, error: subscriptionError } = await supabase
    .from('user_subscriptions')
    .select('status,current_period_end,subscription_plans(code,name,price_monthly,features)')
    .eq('status', 'active')
    .maybeSingle()

  if (subscriptionError || !subscription?.subscription_plans) return FREE_ENTITLEMENTS

  const periodEnd = subscription.current_period_end ? new Date(subscription.current_period_end).getTime() : null
  if (periodEnd !== null && periodEnd <= Date.now()) return FREE_ENTITLEMENTS

  const plan = subscription.subscription_plans as unknown as {
    code: PlanCode
    name: string
    price_monthly: number
    features: Record<string, unknown>
  }

  if (!['free', 'pro', 'business'].includes(plan.code)) return FREE_ENTITLEMENTS

  return {
    code: plan.code,
    name: plan.name,
    priceMonthly: Number(plan.price_monthly) || 0,
    features: plan.features ?? {},
  }
}

export function featureEnabled(plan: PlanEntitlements, key: string): boolean {
  return plan.features[key] === true
}

export function websiteLimit(plan: PlanEntitlements): number {
  const value = Number(plan.features.websites)
  return Number.isFinite(value) && value > 0 ? value : 1
}
