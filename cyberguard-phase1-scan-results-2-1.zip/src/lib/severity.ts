import type { Severity, RiskLevel } from '../types'

export const SEVERITY_ORDER: Severity[] = ['critical', 'high', 'medium', 'low', 'info', 'passed']

export const severityColor: Record<Severity, string> = {
  critical: 'text-sev-critical bg-sev-critical/10 border-sev-critical/30',
  high: 'text-sev-high bg-sev-high/10 border-sev-high/30',
  medium: 'text-sev-medium bg-sev-medium/10 border-sev-medium/30',
  low: 'text-sev-low bg-sev-low/10 border-sev-low/30',
  passed: 'text-sev-passed bg-sev-passed/10 border-sev-passed/30',
  info: 'text-slate-500 dark:text-slate-400 bg-surface-200 dark:bg-surface-800 border-surface-300 dark:border-surface-700',
}

export const scoreColor = (score: number): string => {
  if (score >= 85) return 'text-sev-passed'
  if (score >= 70) return 'text-sev-medium'
  if (score >= 50) return 'text-sev-high'
  return 'text-sev-critical'
}

export const riskFromScore = (score: number): RiskLevel => {
  if (score < 40) return 'critical'
  if (score < 60) return 'high'
  if (score < 85) return 'medium'
  return 'low'
}
