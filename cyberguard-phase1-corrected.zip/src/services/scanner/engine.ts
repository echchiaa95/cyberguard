import type { CheckResult, RiskLevel, ScanOutput, ScanSummary, Severity } from '../../types'

/**
 * Deterministic, explainable scoring engine.
 *
 * Every check declares a severity and status. The engine derives:
 *  - score impact (points lost while the check is not passed)
 *  - Security Score (0-100): 100 minus impacts of non-privacy checks
 *  - Privacy Score (0-100): 100 minus impacts of privacy/trackers checks
 *  - Risk level: highest open severity
 *  - Priority fixes: open findings sorted by recoverable points (no randomness).
 */

const BASE_IMPACT: Record<string, number> = {
  critical: 25,
  high: 12,
  medium: 6,
  low: 3,
  info: 1,
  passed: 0,
}

export function impactFor(check: Pick<CheckResult, 'severity' | 'status'>): number {
  // Informational/pass states must never reduce a score.
  if (check.status === 'pass' || check.status === 'info' || check.severity === 'info' || check.severity === 'passed') return 0
  const base = BASE_IMPACT[check.severity] ?? 0
  return check.status === 'warn' ? Math.ceil(base / 2) : base
}

const PRIVACY_CATEGORIES = new Set(['privacy', 'trackers'])

export function aggregateChecks(checks: Omit<CheckResult, 'scoreImpact'>[], target: string, scannedAt: string, isDemo: boolean, scanId?: string): ScanOutput {
  const withImpact = checks.map((c) => ({ ...c, scoreImpact: impactFor(c) }))

  const summary: ScanSummary = { critical: 0, high: 0, medium: 0, low: 0, passed: 0, info: 0 }
  for (const c of withImpact) {
    if (c.status === 'pass') summary.passed += 1
    else if (c.severity === 'info') summary.info += 1
    else summary[c.severity as 'critical' | 'high' | 'medium' | 'low'] += 1
  }

  let securityDeduction = 0
  let privacyDeduction = 0
  for (const c of withImpact) {
    if (PRIVACY_CATEGORIES.has(c.category)) privacyDeduction += c.scoreImpact
    else securityDeduction += c.scoreImpact
  }

  const clamp = (n: number) => Math.max(0, Math.min(100, Math.round(n)))
  const securityScore = clamp(100 - securityDeduction)
  const privacyScore = clamp(100 - privacyDeduction)

  let riskLevel: RiskLevel = 'low'
  if (withImpact.some((c) => c.status !== 'pass' && c.severity === 'critical')) riskLevel = 'critical'
  else if (withImpact.some((c) => c.status !== 'pass' && c.severity === 'high')) riskLevel = 'high'
  else if (withImpact.some((c) => c.status !== 'pass' && (c.severity === 'medium' || c.severity === 'low'))) riskLevel = 'medium'

  // Priority fixes: recoverable points, sorted descending. Fully derived from the engine.
  const priorityFixes = withImpact
    .filter((c) => c.status !== 'pass' && c.scoreImpact > 0 && c.severity !== 'info')
    .sort((a, b) => b.scoreImpact - a.scoreImpact)
    .slice(0, 5)
    .map((c) => ({ checkId: c.checkId, title: c.title, severity: c.severity as Severity, estimatedImprovement: c.scoreImpact }))

  return {
    scanId, target, scannedAt, isDemo,
    securityScore, privacyScore, riskLevel, summary,
    checks: withImpact.sort((a, b) => b.scoreImpact - a.scoreImpact),
    priorityFixes,
  }
}
