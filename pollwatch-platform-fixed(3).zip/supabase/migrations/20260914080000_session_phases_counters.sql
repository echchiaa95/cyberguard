-- ============================================================================
-- Migration إضافي (غير هدّام): مراحل التصويت + عدادات الذكور/الإناث
-- + RPCs ذرّية + views بـ security_invoker=on (تفرض RLS كما لو استعلام مباشر).
-- لا يحذف أي بيانات ولا يغيّر الجداول الموجودة — يضيف أعمدة وكائنات فقط.
-- ============================================================================

-- 1) أعمدة الجلسات (إضافية بقيم افتراضية — آمنة على الصفوف القائمة)
alter table public.count_sessions
  add column if not exists phase text not null default 'voting'
    check (phase in ('voting', 'counting', 'done')),
  add column if not exists male_count int not null default 0 check (male_count >= 0),
  add column if not exists female_count int not null default 0 check (female_count >= 0),
  add column if not exists voting_started_at timestamptz,
  add column if not exists voting_ended_at timestamptz,
  add column if not exists counting_started_at timestamptz,
  add column if not exists counting_ended_at timestamptz;

-- 2) عدادات ذرّية بتحقق ملكية الجلسة داخل الدالة (definer + فحص يدوي)
create or replace function public.increment_counter(p_session uuid, p_which text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  s public.count_sessions%rowtype;
begin
  select * into s from public.count_sessions where id = p_session for update;
  if not found then
    raise exception 'session_not_found';
  end if;
  -- definer يتجاوز RLS → نفرض ملكية الجلسة للمراقب الحالي يدوياً
  if s.observer_id is distinct from public.my_observer_id() then
    raise exception 'forbidden';
  end if;
  if s.phase <> 'voting' then
    raise exception 'not_in_voting_phase';
  end if;
  if p_which = 'male' then
    update public.count_sessions set male_count = male_count + 1 where id = p_session;
  elsif p_which = 'female' then
    update public.count_sessions set female_count = female_count + 1 where id = p_session;
  else
    raise exception 'invalid_counter';
  end if;
end;
$$;

grant execute on function public.increment_counter(uuid, text) to authenticated;

-- 3) تثبيت إحداثيات المكتب (geography لا يُبنى من العميل مباشرة)
create or replace function public.set_station_location(
  p_station uuid, p_lat double precision, p_lng double precision
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  st public.polling_stations%rowtype;
begin
  select * into st from public.polling_stations where id = p_station;
  if not found then
    raise exception 'station_not_found';
  end if;
  -- صلاحية: superadmin أو party_admin لنفس الحزب
  if not public.is_superadmin() then
    if public.my_role_key() <> 'party_admin' or st.party_id is distinct from public.my_party_id() then
      raise exception 'forbidden';
    end if;
  end if;
  update public.polling_stations
  set location = st_geogfromtext('POINT(' || p_lng || ' ' || p_lat || ')')
  where id = p_station;
end;
$$;

grant execute on function public.set_station_location(uuid, double precision, double precision) to authenticated;

-- 4) view المكاتب بإحداثيات مقروءة — security_invoker=on ⇒ تسري عليه سياسات polling_stations
create or replace view public.stations_view
with (security_invoker = on) as
select
  id, party_id, station_number, name_ar, name_fr, city, region, status,
  election_year_id, created_at, updated_at,
  case when location is not null then st_y(location::geometry) end as lat,
  case when location is not null then st_x(location::geometry) end as lng
from public.polling_stations;

-- 5) view آخر موقع لكل مراقب — تسري عليه سياسات observer_locations
create or replace view public.observer_locations_latest
with (security_invoker = on) as
select distinct on (observer_id)
  id, party_id, observer_id, session_id, recorded_at, expires_at,
  st_y(location::geometry) as lat,
  st_x(location::geometry) as lng
from public.observer_locations
order by observer_id, recorded_at desc;

-- 6) إدراج موقع مراقب — definer مع فحص الموافقة والملكية يدوياً (RLS لا تنطبق على definer)
create or replace function public.insert_observer_location(
  p_observer uuid, p_session uuid, p_party uuid,
  p_lat double precision, p_lng double precision, p_expires timestamptz
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  -- المراقب الحالي فقط
  if p_observer is distinct from public.my_observer_id() then
    raise exception 'forbidden';
  end if;
  -- موافقة GPS سارية (نفس شرط سياسة RLS)
  if not exists (
    select 1 from public.consent_records c
    where c.subject_id = p_observer and c.consent_type = 'location_tracking'
      and c.granted = true and c.revoked_at is null
  ) then
    raise exception 'consent_required';
  end if;
  insert into public.observer_locations (party_id, observer_id, session_id, location, expires_at)
  values (p_party, p_observer, p_session, st_geogfromtext('POINT(' || p_lng || ' ' || p_lat || ')'), p_expires);
end;
$$;

grant execute on function public.insert_observer_location(uuid, uuid, uuid, double precision, double precision, timestamptz) to authenticated;
