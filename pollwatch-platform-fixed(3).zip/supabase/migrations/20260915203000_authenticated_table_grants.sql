-- Pollwatch: required table privileges for the authenticated web client.
-- RLS remains the security boundary; these grants do not bypass RLS.

GRANT USAGE ON SCHEMA public TO authenticated;

-- Read-only reference data
GRANT SELECT ON TABLE
  public.election_years,
  public.election_types,
  public.roles,
  public.permissions,
  public.parties,
  public.party_domains,
  public.party_members
TO authenticated;

-- Tables accessed directly by the web application.
-- RLS policies restrict which rows each authenticated role may access.
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE
  public.parties,
  public.party_domains,
  public.party_members,
  public.observers,
  public.assistants,
  public.polling_stations,
  public.observer_assignments,
  public.observer_locations,
  public.count_sessions,
  public.vote_entries,
  public.support_metrics,
  public.official_results,
  public.reports,
  public.audit_logs,
  public.consent_records
TO authenticated;

-- Views used by the dashboard.
GRANT SELECT ON TABLE public.stations_view TO authenticated;

-- The application calls these RPCs from the browser.
GRANT EXECUTE ON FUNCTION public.my_role_key() TO authenticated;
GRANT EXECUTE ON FUNCTION public.my_member_id() TO authenticated;
GRANT EXECUTE ON FUNCTION public.my_party_id() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_superadmin() TO authenticated;
GRANT EXECUTE ON FUNCTION public.set_station_location(uuid, double precision, double precision) TO authenticated;
