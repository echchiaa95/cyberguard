import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import { useI18n } from '../lib/i18n'
import type { HistoryPoint } from '../types'
import { listHistory } from '../services/db'
import { scoreColor } from '../lib/severity'
import { EmptyState } from '../components/EmptyState'
import { cn } from '../lib/utils'

function StatCard({ label, value, hint, tone = 'text-white' }: { label: string; value: string | number; hint?: string; tone?: string }) {
  return (
    <div className="cyber-feature p-4 sm:p-5">
      <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-slate-500">{label}</p>
      <p className={cn('mt-2 text-3xl font-black tabular-nums', tone)}>{value}</p>
      {hint && <p className="mt-1 text-xs text-slate-600">{hint}</p>}
    </div>
  )
}

export function History() {
  const { user } = useAuth()
  const { t, lang } = useI18n()
  const [points, setPoints] = useState<HistoryPoint[]>([])
  const [target, setTarget] = useState('all')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!user) return
    let cancelled = false
    setLoading(true)
    setError(null)
    void listHistory(user.id)
      .then((data) => { if (!cancelled) setPoints(data) })
      .catch(() => { if (!cancelled) setError(t('hist.loadError')) })
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [user, t])

  const targets = useMemo(() => Array.from(new Set(points.map((p) => p.target))), [points])
  const filtered = useMemo(() => {
    const rows = target === 'all' ? points : points.filter((p) => p.target === target)
    return [...rows].sort((a, b) => a.recordedAt.localeCompare(b.recordedAt))
  }, [points, target])

  const latest = filtered.length ? filtered[filtered.length - 1] : null
  const previous = filtered.length > 1 ? filtered[filtered.length - 2] : null
  const scoreDelta = latest && previous ? latest.securityScore - previous.securityScore : null
  const privacyDelta = latest && previous && latest.privacyScore !== undefined && previous.privacyScore !== undefined
    ? latest.privacyScore - previous.privacyScore
    : null
  const findingsDelta = latest && previous ? latest.findingsCount - previous.findingsCount : null

  if (loading) return <div className="cyber-glass p-8 text-center text-sm text-slate-500">{t('common.loading')}</div>

  if (error) {
    return (
      <div className="cyber-glass p-8 text-center">
        <p className="text-sev-critical">{error}</p>
        <button type="button" className="btn-secondary mt-4" onClick={() => window.location.reload()}>{t('hist.retry')}</button>
      </div>
    )
  }

  if (points.length === 0) {
    return (
      <div className="relative space-y-6">
        <Header />
        <EmptyState title={t('common.noData')} hint={t('hist.emptyHint')} />
      </div>
    )
  }

  const chart = buildChart(filtered.map((p) => p.securityScore))

  return (
    <div className="relative space-y-6">
      <Header />

      <section className="cyber-glass relative overflow-hidden p-5 sm:p-7">
        <div className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-brand-500/10 blur-3xl" />
        <div className="relative flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div className="min-w-0">
            <div className="cyber-kicker">Security timeline</div>
            <h1 className="mt-3 text-3xl font-black tracking-tight text-white sm:text-4xl">{t('hist.title')}</h1>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">{t('hist.subtitle')}</p>
          </div>
          <label className="block sm:min-w-[18rem]">
            <span className="mb-2 block text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-600">{t('hist.target')}</span>
            <select value={target} onChange={(e) => setTarget(e.target.value)} className="input w-full">
              <option value="all">{t('hist.allWebsites')}</option>
              {targets.map((item) => <option key={item} value={item}>{item}</option>)}
            </select>
          </label>
        </div>
      </section>

      {latest && (
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <StatCard label={t('hist.stat.scans')} value={filtered.length} hint={t('hist.stat.assessments')} />
          <StatCard label={t('hist.stat.currentScore')} value={latest.securityScore} hint={latest.target} tone={scoreColor(latest.securityScore)} />
          <StatCard label={t('hist.stat.change')} value={scoreDelta === null ? '—' : `${scoreDelta >= 0 ? '+' : ''}${scoreDelta}`} hint={previous ? t('hist.vsPrevious') : t('hist.firstScan')} tone={scoreDelta === null || scoreDelta === 0 ? 'text-slate-400' : scoreDelta > 0 ? 'text-sev-passed' : 'text-sev-critical'} />
          <StatCard label={t('hist.stat.findings')} value={latest.findingsCount} hint={findingsDelta === null ? t('hist.currentAssessment') : `${findingsDelta > 0 ? '+' : ''}${findingsDelta} ${t('hist.sincePrevious')}`} tone={latest.findingsCount === 0 ? 'text-sev-passed' : 'text-sev-high'} />
        </div>
      )}

      {filtered.length > 1 && (
        <section className="cyber-glass overflow-hidden p-5 sm:p-6">
          <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="cyber-kicker">Trend</p>
              <h2 className="mt-2 text-xl font-bold text-white">{t('hist.trendTitle')}</h2>
              <p className="mt-1 text-sm text-slate-500">{t('hist.trendHint')}</p>
            </div>
            {latest && previous && (
              <div className={cn('rounded-full border px-3 py-1.5 text-xs font-semibold', scoreDelta !== null && scoreDelta >= 0 ? 'border-brand-500/20 bg-brand-500/5 text-brand-300' : 'border-sev-critical/20 bg-sev-critical/5 text-sev-critical')}>
                {scoreDelta === 0 ? t('hist.noChange') : scoreDelta! > 0 ? t('hist.improvedBy', { n: scoreDelta }) : t('hist.declinedBy', { n: Math.abs(scoreDelta!) })}
              </div>
            )}
          </div>
          <div className="overflow-x-auto">
            <svg viewBox="0 0 720 230" className="h-56 min-w-[34rem] w-full" role="img" aria-label={t('hist.chartLabel')}>
              {[25, 50, 75].map((v) => <line key={v} x1="28" x2="700" y1={220 - v * 1.9} y2={220 - v * 1.9} stroke="rgba(148,163,184,.10)" />)}
              <line x1="28" x2="700" y1="30" y2="30" stroke="rgba(148,163,184,.10)" />
              <path d={chart.area} fill="rgba(16,185,129,.08)" />
              <path d={chart.path} fill="none" stroke="#10b981" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
              {chart.points.map((p, i) => (
                <g key={`${filtered[i].scanId ?? i}`}>
                  <circle cx={p.x} cy={p.y} r="6" fill="#07111d" stroke="#10b981" strokeWidth="2" />
                  <title>{`${filtered[i].securityScore} — ${new Date(filtered[i].recordedAt).toLocaleDateString(lang)}`}</title>
                </g>
              ))}
              <text x="4" y="35" fill="#64748b" fontSize="11">100</text>
              <text x="12" y="222" fill="#64748b" fontSize="11">0</text>
            </svg>
          </div>
        </section>
      )}

      {latest && previous && (
        <section className="cyber-feature p-5 sm:p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="cyber-kicker">Comparison</p>
              <h2 className="mt-2 text-xl font-bold text-white">{t('hist.compareTitle')}</h2>
            </div>
            {latest.scanId && <Link to={`/app/scans/${latest.scanId}`} className="text-sm font-semibold text-brand-400 hover:text-brand-300">{t('hist.viewLatest')} →</Link>}
          </div>
          <div className="mt-5 grid gap-3 sm:grid-cols-3">
            <CompareCard label={t('hist.col.score')} current={latest.securityScore} previous={previous.securityScore} delta={scoreDelta!} />
            <CompareCard label={t('hist.col.privacy')} current={latest.privacyScore ?? '—'} previous={previous.privacyScore ?? '—'} delta={privacyDelta} />
            <CompareCard label={t('hist.col.findings')} current={latest.findingsCount} previous={previous.findingsCount} delta={findingsDelta} invertDelta />
          </div>
          <p className="mt-4 text-xs text-slate-600">{new Date(previous.recordedAt).toLocaleString(lang)} → {new Date(latest.recordedAt).toLocaleString(lang)}</p>
        </section>
      )}

      <section className="cyber-glass overflow-hidden p-5 sm:p-6">
        <div className="flex items-end justify-between gap-3">
          <div>
            <p className="cyber-kicker">Assessment log</p>
            <h2 className="mt-2 text-xl font-bold text-white">{t('hist.scanLog')}</h2>
          </div>
          <span className="text-xs text-slate-600">{filtered.length} {t('hist.records')}</span>
        </div>

        <div className="mt-5 hidden overflow-x-auto md:block">
          <table className="w-full min-w-[44rem] text-sm">
            <thead>
              <tr className="border-b border-surface-800 text-[10px] uppercase tracking-[0.18em] text-slate-600">
                <th className="pb-3 text-start font-semibold">{t('hist.col.date')}</th>
                <th className="pb-3 text-start font-semibold">{t('hist.col.score')}</th>
                <th className="pb-3 text-start font-semibold">{t('hist.col.privacy')}</th>
                <th className="pb-3 text-start font-semibold">{t('hist.col.findings')}</th>
                <th className="pb-3 text-start font-semibold">{t('hist.col.change')}</th>
                <th className="pb-3 text-end" />
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-800/70">
              {[...filtered].reverse().map((p, reverseIndex) => {
                const i = filtered.length - 1 - reverseIndex
                const prev = i > 0 ? filtered[i - 1] : null
                const delta = prev ? p.securityScore - prev.securityScore : null
                return (
                  <tr key={p.scanId ?? `${p.recordedAt}-${i}`} className="group">
                    <td className="py-4 text-slate-400">{new Date(p.recordedAt).toLocaleString(lang)}</td>
                    <td className={cn('py-4 font-bold tabular-nums', scoreColor(p.securityScore))}>{p.securityScore}</td>
                    <td className="py-4 text-slate-400">{p.privacyScore ?? '—'}</td>
                    <td className="py-4 text-slate-400">{p.findingsCount}</td>
                    <td className={cn('py-4 font-semibold', delta === null ? 'text-slate-600' : delta >= 0 ? 'text-sev-passed' : 'text-sev-critical')}>
                      {delta === null ? '—' : `${delta >= 0 ? '+' : ''}${delta}`}
                    </td>
                    <td className="py-4 text-end">{p.scanId && <Link to={`/app/scans/${p.scanId}`} className="text-brand-400 opacity-80 transition group-hover:opacity-100 hover:underline">{t('common.view')}</Link>}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        <div className="mt-5 space-y-3 md:hidden">
          {[...filtered].reverse().map((p, reverseIndex) => {
            const i = filtered.length - 1 - reverseIndex
            const prev = i > 0 ? filtered[i - 1] : null
            const delta = prev ? p.securityScore - prev.securityScore : null
            return (
              <div key={p.scanId ?? `${p.recordedAt}-${i}`} className="rounded-2xl border border-surface-800 bg-surface-950/50 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-xs text-slate-500">{new Date(p.recordedAt).toLocaleString(lang)}</p>
                    <p className="mt-1 truncate font-mono text-[10px] text-slate-700" title={p.target}>{p.target}</p>
                  </div>
                  {p.scanId && <Link to={`/app/scans/${p.scanId}`} className="shrink-0 text-xs font-semibold text-brand-400">{t('common.view')}</Link>}
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2">
                  <MiniMetric label={t('hist.col.score')} value={p.securityScore} tone={scoreColor(p.securityScore)} />
                  <MiniMetric label={t('hist.col.privacy')} value={p.privacyScore ?? '—'} />
                  <MiniMetric label={t('hist.col.findings')} value={p.findingsCount} />
                </div>
                <div className={cn('mt-3 text-xs font-semibold', delta === null ? 'text-slate-600' : delta >= 0 ? 'text-sev-passed' : 'text-sev-critical')}>
                  {delta === null ? t('hist.firstScan') : delta === 0 ? t('hist.noChange') : delta > 0 ? t('hist.improvedBy', { n: delta }) : t('hist.declinedBy', { n: Math.abs(delta) })}
                </div>
              </div>
            )
          })}
        </div>
      </section>

      <p className="text-center text-[11px] leading-5 text-slate-700">{t('hist.disclaimer')}</p>
    </div>
  )
}

function Header() {
  const { t } = useI18n()
  return (
    <div className="flex flex-wrap items-end justify-between gap-3">
      <div>
        <div className="cyber-kicker">Security intelligence</div>
        <p className="mt-2 text-sm text-slate-600">{t('hist.pageHint')}</p>
      </div>
      <Link to="/app/websites" className="btn-secondary">+ {t('scan.new')}</Link>
    </div>
  )
}

function MiniMetric({ label, value, tone = 'text-slate-200' }: { label: string; value: string | number; tone?: string }) {
  return <div className="rounded-xl border border-surface-800 bg-surface-900/60 p-2.5"><p className="text-[9px] uppercase tracking-[0.12em] text-slate-600">{label}</p><p className={cn('mt-1 font-bold tabular-nums', tone)}>{value}</p></div>
}

function CompareCard({ label, current, previous, delta, invertDelta = false }: { label: string; current: string | number; previous: string | number; delta: number | null; invertDelta?: boolean }) {
  const positive = delta !== null && (invertDelta ? delta < 0 : delta > 0)
  const negative = delta !== null && (invertDelta ? delta > 0 : delta < 0)
  return (
    <div className="rounded-2xl border border-surface-800 bg-surface-950/50 p-4">
      <p className="text-[10px] uppercase tracking-[0.18em] text-slate-600">{label}</p>
      <div className="mt-2 flex items-end gap-3"><strong className="text-2xl text-white">{current}</strong><span className="text-xs text-slate-600">vs {previous}</span></div>
      <p className={cn('mt-2 text-xs font-semibold', positive ? 'text-sev-passed' : negative ? 'text-sev-critical' : 'text-slate-500')}>
        {delta === null ? '—' : `${delta > 0 ? '+' : ''}${delta}`}
      </p>
    </div>
  )
}

function buildChart(scores: number[]) {
  const width = 672, top = 30, bottom = 220
  const x = (i: number) => scores.length <= 1 ? width / 2 + 28 : 28 + (i / (scores.length - 1)) * width
  const y = (score: number) => bottom - (Math.max(0, Math.min(100, score)) / 100) * (bottom - top)
  const points = scores.map((score, i) => ({ x: x(i), y: y(score) }))
  const path = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x},${p.y}`).join(' ')
  const area = points.length ? `${path} L ${points[points.length - 1].x},${bottom} L ${points[0].x},${bottom} Z` : ''
  return { points, path, area }
}
