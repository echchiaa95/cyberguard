import { DEMO_HISTORY, DEMO_SCAN_RECORDS, DEMO_WEBSITES } from '../lib/demoData'
import { isDemoMode, supabase } from '../lib/supabase'
import type { CheckResult, HistoryPoint, ScanOutput, ScanRecord, Website } from '../types'

/**
 * Persistence layer. Uses Supabase when configured (RLS enforced server-side);
 * otherwise a localStorage demo store so Phase 1 flows remain testable.
 * Authorization is always enforced by the database (RLS policies) — never client-side only.
 */

interface DemoDb {
  websites: Website[]
  scans: ScanRecord[]
  checks: Record<string, CheckResult[]>
  history: HistoryPoint[]
}

function loadDemoDb(): DemoDb {
  try {
    const raw = localStorage.getItem('cg_demo_db')
    if (raw) return JSON.parse(raw)
  } catch { /* ignore */ }
  return {
    websites: [...DEMO_WEBSITES],
    scans: [...DEMO_SCAN_RECORDS],
    checks: {},
    history: [...DEMO_HISTORY],
  }
}

function saveDemoDb(db: DemoDb) {
  localStorage.setItem('cg_demo_db', JSON.stringify(db))
}

const uid = () =>
  (crypto as Crypto).randomUUID ? crypto.randomUUID() : `demo-${Date.now()}-${Math.floor(performance.now())}`

export async function listWebsites(userId: string): Promise<Website[]> {
  if (supabase) {
    const { data, error } = await supabase.from('websites').select('*').eq('user_id', userId).order('created_at', { ascending: false })
    if (error) throw error
    return (data ?? []).map((r) => ({ id: r.id, url: r.url, normalizedUrl: r.normalized_url, name: r.name ?? undefined, createdAt: r.created_at }))
  }
  const db = loadDemoDb()
  return db.websites.sort((a, b) => b.createdAt.localeCompare(a.createdAt))
}

export async function addWebsite(userId: string, url: string, normalizedUrl: string, name?: string): Promise<Website> {
  if (supabase) {
    const { data, error } = await supabase.from('websites').insert({ user_id: userId, url, normalized_url: normalizedUrl, name }).select().single()
    if (error) throw error
    return { id: data.id, url: data.url, normalizedUrl: data.normalized_url, name: data.name ?? undefined, createdAt: data.created_at }
  }
  const db = loadDemoDb()
  const existing = db.websites.find((w) => w.normalizedUrl === normalizedUrl)
  if (existing) return existing
  const w: Website = { id: uid(), url, normalizedUrl, name, createdAt: new Date().toISOString() }
  db.websites.push(w)
  saveDemoDb(db)
  return w
}

export async function deleteWebsite(userId: string, websiteId: string): Promise<void> {
  if (supabase) {
    const { error } = await supabase.from('websites').delete().eq('id', websiteId).eq('user_id', userId)
    if (error) throw error
    return
  }
  const db = loadDemoDb()
  db.websites = db.websites.filter((w) => w.id !== websiteId)
  db.scans = db.scans.filter((s) => s.websiteId !== websiteId)
  saveDemoDb(db)
}

export async function createScanRecord(userId: string, websiteId: string | undefined, target: string): Promise<string> {
  if (supabase) {
    const { data, error } = await supabase.from('scans').insert({ user_id: userId, website_id: websiteId ?? null, target, status: 'running' }).select().single()
    if (error) throw error
    return data.id as string
  }
  const db = loadDemoDb()
  const id = uid()
  db.scans.push({ id, websiteId, target, status: 'running', findingsCount: 0, passedCount: 0, createdAt: new Date().toISOString() })
  saveDemoDb(db)
  return id
}

export async function saveScanResult(userId: string, scanId: string, output: ScanOutput): Promise<void> {
  if (supabase) {
    const findings = output.checks.filter((c) => c.status !== 'pass' && c.severity !== 'info' && c.severity !== 'passed').length
    const passed = output.checks.filter((c) => c.status === 'pass').length
    const { error } = await supabase.from('scans').update({
      status: 'completed',
      security_score: output.securityScore,
      privacy_score: output.privacyScore,
      risk_level: output.riskLevel,
      findings_count: findings,
      passed_count: passed,
      completed_at: new Date().toISOString(),
    }).eq('id', scanId).eq('user_id', userId)
    if (error) throw error
    const rows = output.checks.map((c) => ({
      scan_id: scanId, user_id: userId, check_id: c.checkId, module: c.module, category: c.category,
      severity: c.severity, status: c.status, title: c.title, evidence: c.evidence, description: c.description,
      impact: c.impact, recommendation: c.recommendation, remediation: c.remediation, score_impact: c.scoreImpact,
    }))
    const { error: rErr } = await supabase.from('scan_results').upsert(rows, { onConflict: 'scan_id,check_id' })
    if (rErr) throw rErr
    const { error: hErr } = await supabase.from('security_history').insert({
      user_id: userId, target: output.target, scan_id: scanId,
      security_score: output.securityScore, privacy_score: output.privacyScore, findings_count: findings,
    })
    if (hErr) throw hErr
    return
  }
  const db = loadDemoDb()
  const rec = db.scans.find((s) => s.id === scanId)
  if (rec) {
    rec.status = 'completed'
    rec.securityScore = output.securityScore
    rec.privacyScore = output.privacyScore
    rec.riskLevel = output.riskLevel
    rec.findingsCount = output.checks.filter((c) => c.status !== 'pass' && c.severity !== 'info' && c.severity !== 'passed').length
    rec.passedCount = output.checks.filter((c) => c.status === 'pass').length
    rec.completedAt = new Date().toISOString()
  }
  db.checks[scanId] = output.checks
  db.history.push({ scanId, target: output.target, securityScore: output.securityScore, privacyScore: output.privacyScore, findingsCount: rec?.findingsCount ?? 0, recordedAt: new Date().toISOString() })
  saveDemoDb(db)
}

export async function failScanRecord(userId: string, scanId: string, messageKey: string): Promise<void> {
  if (supabase) {
    await supabase.from('scans').update({ status: 'failed', error_message: messageKey }).eq('id', scanId).eq('user_id', userId)
    return
  }
  const db = loadDemoDb()
  const rec = db.scans.find((s) => s.id === scanId)
  if (rec) { rec.status = 'failed'; rec.errorMessage = messageKey }
  saveDemoDb(db)
}

export async function listScans(userId: string, websiteId?: string): Promise<ScanRecord[]> {
  if (supabase) {
    let q = supabase.from('scans').select('*').eq('user_id', userId).order('created_at', { ascending: false }).limit(50)
    if (websiteId) q = q.eq('website_id', websiteId)
    const { data, error } = await q
    if (error) throw error
    return (data ?? []).map((r) => ({
      id: r.id, websiteId: r.website_id ?? undefined, target: r.target, status: r.status,
      securityScore: r.security_score ?? undefined, privacyScore: r.privacy_score ?? undefined,
      riskLevel: r.risk_level ?? undefined, findingsCount: r.findings_count, passedCount: r.passed_count,
      errorMessage: r.error_message ?? undefined, createdAt: r.created_at, completedAt: r.completed_at ?? undefined,
    }))
  }
  const db = loadDemoDb()
  let scans = db.scans
  if (websiteId) scans = scans.filter((s) => s.websiteId === websiteId)
  return [...scans].sort((a, b) => b.createdAt.localeCompare(a.createdAt))
}

export async function getScanChecks(userId: string, scanId: string): Promise<CheckResult[]> {
  if (supabase) {
    const { data, error } = await supabase.from('scan_results').select('*').eq('scan_id', scanId).eq('user_id', userId)
    if (error) throw error
    return (data ?? []).map((r) => ({
      checkId: r.check_id, module: r.module, category: r.category, severity: r.severity, status: r.status,
      title: r.title, evidence: r.evidence ?? '', description: r.description ?? '', impact: r.impact ?? '',
      recommendation: r.recommendation ?? '', remediation: r.remediation ?? '', scoreImpact: Number(r.score_impact),
    }))
  }
  const db = loadDemoDb()
  return db.checks[scanId] ?? []
}

export async function listHistory(userId: string, target?: string): Promise<HistoryPoint[]> {
  if (supabase) {
    let q = supabase.from('security_history').select('*').eq('user_id', userId).order('recorded_at', { ascending: true }).limit(100)
    if (target) q = q.eq('target', target)
    const { data, error } = await q
    if (error) throw error
    return (data ?? []).map((r) => ({
      scanId: r.scan_id ?? undefined, target: r.target, securityScore: r.security_score,
      privacyScore: r.privacy_score ?? undefined, findingsCount: r.findings_count, recordedAt: r.recorded_at,
    }))
  }
  const db = loadDemoDb()
  let h = db.history
  if (target) h = h.filter((p) => p.target === target)
  return [...h].sort((a, b) => a.recordedAt.localeCompare(b.recordedAt))
}

export async function resetDemoData(): Promise<void> {
  localStorage.removeItem('cg_demo_db')
  localStorage.removeItem('cg_demo_session')
  window.location.reload()
}
