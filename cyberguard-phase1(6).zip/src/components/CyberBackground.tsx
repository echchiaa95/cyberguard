// CyberGuard cinematic atmosphere — VISUAL LAYER ONLY.
// Pure CSS/SVG, no dependencies, no logic. Sits behind all UI (fixed, z-0,
// pointer-events-none, aria-hidden). Respects prefers-reduced-motion.
// Visual target: futuristic security operations center + cinematic digital
// infrastructure — NOT a giant globe, NOT matrix rain.

export type AtmoVariant = 'default' | 'hero' | 'auth' | 'soc' | 'radar'

const CODE_FRAGMENTS = [
  'SECURITY_ENGINE', 'THREAT_INTELLIGENCE', 'NETWORK_SCAN',
  'ENCRYPTED_CONNECTION', 'TLS_HANDSHAKE', 'HSTS', 'CSP',
  'X_FRAME_OPTIONS', 'COOKIE_ANALYSIS', 'TRACKER_DETECTION',
  'PRIVACY_ENGINE', 'SCAN_STATUS', 'RISK_ANALYSIS',
]

const HUD_LABELS = [
  'SYSTEM ONLINE', 'ENCRYPTED', 'THREAT LEVEL: LOW',
  'TLS VERIFIED', 'PRIVACY ENGINE ACTIVE',
]

/** Thin glowing network mesh with traveling pulses — the "alive" layer. */
function Mesh({ className = 'cb-mesh' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 1440 900" preserveAspectRatio="xMidYMid slice" fill="none" aria-hidden="true">
      <g stroke="#10b981" strokeOpacity="0.10" strokeWidth="0.6">
        <path id="cb-mpath-1" d="M-40 720 L260 580 L560 660 L900 480 L1230 560 L1500 430" />
        <path d="M260 580 L330 310 L680 230 L1020 310 L1230 560" />
        <path d="M680 230 L900 480" />
        <path d="M330 310 L120 420 L-40 380" strokeOpacity="0.07" />
        <path d="M1020 310 L1250 220 L1500 260" strokeOpacity="0.07" />
      </g>
      <g fill="#10b981">
        <circle cx="260" cy="580" r="2.4" className="cb-node" />
        <circle cx="560" cy="660" r="2" className="cb-node cb-node-d1" />
        <circle cx="900" cy="480" r="2.6" className="cb-node cb-node-d2" />
        <circle cx="330" cy="310" r="2" className="cb-node cb-node-d3" />
        <circle cx="680" cy="230" r="2.4" className="cb-node cb-node-d1" />
        <circle cx="1020" cy="310" r="2" className="cb-node cb-node-d2" />
        <circle cx="1230" cy="560" r="2.2" className="cb-node cb-node-d3" />
      </g>
      <g fill="#22d3ee" fillOpacity="0.55">
        <circle cx="900" cy="480" r="1.4" className="cb-node" />
        <circle cx="1250" cy="220" r="1.8" className="cb-node cb-node-d2" />
        <circle cx="120" cy="420" r="1.6" className="cb-node cb-node-d1" />
        <circle cx="260" cy="580" r="1.2" />
        <circle cx="680" cy="230" r="1.2" className="cb-node cb-node-d3" />
      </g>
      {/* data packets traveling along the mesh */}
      <circle r="2.2" fill="#a7f3d0" className="cb-pulse-dot" style={{ offsetPath: "path('M-40 720 L260 580 L560 660 L900 480 L1230 560 L1500 430')" }} />
      <circle r="1.8" fill="#67e8f9" className="cb-pulse-dot cb-pd-2" style={{ offsetPath: "path('M330 310 L680 230 L1020 310 L1230 560')", animationDelay: '4s' }} />
      <circle r="1.6" fill="#6ee7b7" className="cb-pulse-dot cb-pd-3" style={{ offsetPath: "path('M900 480 L680 230')", animationDelay: '8s', animationDuration: '9s' }} />
    </svg>
  )
}

/** Faint threat-map radar for scan results — subtle, score rings stay primary. */
function Radar() {
  return (
    <svg className="cb-radar" viewBox="0 0 600 600" fill="none" aria-hidden="true">
      <g stroke="#10b981" strokeOpacity="0.09">
        <circle cx="300" cy="300" r="90" /><circle cx="300" cy="300" r="160" />
        <circle cx="300" cy="300" r="230" /><circle cx="300" cy="300" r="292" strokeDasharray="3 10" />
      </g>
      <g stroke="#10b981" strokeOpacity="0.06">
        <path d="M300 8 V592 M8 300 H592" />
      </g>
      <g fill="#34d399" fillOpacity="0.4">
        <circle cx="380" cy="210" r="2" /><circle cx="230" cy="330" r="2" />
        <circle cx="330" cy="420" r="1.6" fill="#22d3ee" />
      </g>
    </svg>
  )
}

export function CyberBackground({ variant = 'default' }: { variant?: AtmoVariant }) {
  const isAuth = variant === 'auth'
  return (
    <div className={`cb-root cb-${variant}`} aria-hidden="true">
      {/* BACKGROUND — deep atmospheric gradient */}
      <div className="cb-atmosphere" />

      {/* soft volumetric light beams */}
      {!isAuth && (
        <div className="cb-vol-light">
          <span className="cb-beam cb-beam-1" />
          <span className="cb-beam cb-beam-2" />
        </div>
      )}

      {/* MIDGROUND — faint digital grid */}
      <div className="cb-grid" />

      {/* CINEMATIC DEPTH — perspective floor + horizon (operations-center feel) */}
      {!isAuth && <div className="cb-floor" />}
      {!isAuth && <div className="cb-horizon" />}

      {/* MIDGROUND — glowing network infrastructure */}
      {!isAuth && <Mesh />}

      {variant === 'radar' && <Radar />}

      {/* MIDGROUND — faint flowing data streams */}
      <div className="cb-streams">
        <span className="cb-stream cb-stream-y cb-s1" />
        <span className="cb-stream cb-stream-y cb-s2" />
        <span className="cb-stream cb-stream-y cb-s3" />
        <span className="cb-stream cb-stream-x cb-s4" />
        <span className="cb-stream cb-stream-x cb-s5" />
      </div>

      {/* FOREGROUND — distant HUD code fragments */}
      <div className="cb-code">
        {CODE_FRAGMENTS.map((c, i) => (
          <span key={c} className={`cb-frag cb-frag-${i % 4}`} style={{
            top: `${8 + (i * 61) % 82}%`,
            insetInlineStart: `${4 + (i * 137) % 86}%`,
          }}>{c}</span>
        ))}
        <span className="cb-frag cb-code-block cb-frag-1" style={{ top: '58%', insetInlineEnd: '6%' }}>
          {`if (security) {\n  analyze();\n  detect();\n  protect();\n}`}
        </span>
        <span className="cb-frag cb-code-block cb-frag-3" style={{ top: '18%', insetInlineStart: '5%' }}>
          {`const guardian = {\n  mode: "passive",\n  privacy: true,\n  evidence: true\n};`}
        </span>
      </div>

      {/* FOREGROUND — HUD frame */}
      <div className="cb-hud">
        <span className="cb-bracket cb-b-tl" /><span className="cb-bracket cb-b-tr" />
        <span className="cb-bracket cb-b-bl" /><span className="cb-bracket cb-b-br" />
        {HUD_LABELS.map((l, i) => (
          <span key={l} className={`cb-hud-label cb-hud-${i}`}>[ {l} ]</span>
        ))}
        <span className="cb-hud-coord cb-coord-1">38.8951°N · 77.0364°W</span>
        <span className="cb-hud-coord cb-coord-2">NODE: EU-WEST · LAT 12MS</span>
        <span className="cb-hud-line cb-hl-1" /><span className="cb-hud-line cb-hl-2" />
      </div>

      {/* FOREGROUND — digital dust particles */}
      <div className="cb-particles">
        {Array.from({ length: 14 }, (_, i) => (
          <span key={i} className={`cb-particle cb-p-${i % 6}`} style={{
            top: `${(i * 83) % 95}%`,
            insetInlineStart: `${(i * 47) % 95}%`,
            animationDelay: `${(i * 0.9).toFixed(1)}s`,
          }} />
        ))}
      </div>

      {/* section-variant soft glows */}
      <div className="cb-glow" />

      {/* cinematic vignette */}
      <div className="cb-vignette" />
    </div>
  )
}
