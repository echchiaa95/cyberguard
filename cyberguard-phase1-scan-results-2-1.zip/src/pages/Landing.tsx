import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useI18n } from '../lib/i18n'
import { Logo } from '../components/Logo'

const FEATURES = [
  'securityScore', 'privacyScore', 'webScanner', 'appScanner',
  'fileScanner', 'monitoring', 'reports', 'advisor',
] as const

const CODE_LEFT = `if (security) {\n  scan(target);\n  analyze(headers);\n  protect(privacy);\n}\n\nconst threats = [];\nawait detect(trackers);\nreturn riskScore;\n\n> SCAN\n> ANALYZE\n> DETECT\n> PROTECT`

const CODE_RIGHT = `010101  SECURITY  0101\n[+] HTTPS\n[+] TLS\n[!] CSP\n[+] COOKIES\n\nconst guardian = {\n  mode: 'passive',\n  evidence: true,\n  privacy: true\n};\n\n// CYBERGUARD\n// STAY AHEAD` 

export function Landing() {
  const { t } = useI18n()
  const [faq, setFaq] = useState<number | null>(null)

  return (
    <div className="cyber-page min-h-screen overflow-hidden bg-surface-950 text-slate-200">
      <div className="cyber-grid" />
      <div className="cyber-code cyber-code-left">{CODE_LEFT}</div>
      <div className="cyber-code cyber-code-right">{CODE_RIGHT}</div>
      <div className="cyber-orb -right-40 top-24" />
      <div className="cyber-scanline inset-x-0 top-20" />

      <header className="sticky top-0 z-30 border-b border-surface-800/70 bg-surface-950/75 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
          <Link to="/" className="flex items-center gap-3">
            <Logo size={34} />
            <div>
              <div className="font-bold tracking-tight text-white">CyberGuard</div>
              <div className="text-[9px] uppercase tracking-[0.22em] text-brand-400">Scan today. Stay secure.</div>
            </div>
          </Link>
          <nav className="hidden items-center gap-7 md:flex">
            <a href="#features" className="text-sm text-slate-400 transition hover:text-brand-300">Features</a>
            <a href="#trust" className="text-sm text-slate-400 transition hover:text-brand-300">Why CyberGuard</a>
            <Link to="/login" className="text-sm text-slate-400 transition hover:text-white">Login</Link>
            <Link to="/signup" className="btn-primary">Start Scanning <span>→</span></Link>
          </nav>
          <Link to="/signup" className="btn-primary md:hidden">Scan <span>→</span></Link>
        </div>
      </header>

      <main>
        <section className="relative mx-auto max-w-7xl px-5 pb-16 pt-16 lg:px-8 lg:pb-24 lg:pt-24">
          <div className="grid items-center gap-12 lg:grid-cols-[1.02fr_.98fr]">
            <div className="relative z-10">
              <div className="cyber-kicker"><span className="cyber-dot" /> Protect · Analyze · Stay Ahead</div>
              <h1 className="cyber-title mt-6 text-5xl font-black leading-[.98] tracking-[-.04em] text-white sm:text-6xl lg:text-7xl">
                {t('landing.hero.title')}
                <span className="cyber-title-accent block">CyberGuard</span>
              </h1>
              <p className="mt-6 max-w-2xl text-base leading-7 text-slate-400 sm:text-lg">
                {t('landing.hero.subtitle')}
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link to="/signup" className="btn-primary !px-6 !py-3.5">{t('landing.cta.scan')} <span>→</span></Link>
                <a href="#features" className="btn-secondary !px-6 !py-3.5">Explore Security Tools</a>
              </div>
              <div className="mt-7 flex flex-wrap gap-x-6 gap-y-2 text-xs text-slate-500">
                {['Fast & Accurate', 'Non-Intrusive', 'Privacy Focused', 'Professional Reports'].map((item) => (
                  <span key={item} className="flex items-center gap-2"><span className="text-brand-400">✓</span>{item}</span>
                ))}
              </div>
            </div>

            <div className="relative mx-auto w-full max-w-xl lg:ml-auto">
              <div className="cyber-glass cyber-glow relative overflow-hidden p-5 sm:p-7">
                <div className="absolute -right-16 -top-16 h-40 w-40 rounded-full bg-brand-500/10 blur-3xl" />
                <div className="flex items-center justify-between border-b border-surface-800 pb-4">
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-[.2em] text-brand-400">Live Security Engine</p>
                    <p className="mt-1 text-sm font-semibold text-white">Website intelligence</p>
                  </div>
                  <span className="badge border-brand-500/30 bg-brand-500/10 text-brand-300"><span className="cyber-dot" /> ACTIVE</span>
                </div>
                <div className="relative my-6 flex min-h-[270px] items-center justify-center overflow-hidden rounded-2xl border border-brand-500/10 bg-[#061019]">
                  <div className="absolute inset-0 opacity-40" style={{ backgroundImage: 'radial-gradient(circle, rgba(52,211,153,.55) 1px, transparent 1px)', backgroundSize: '13px 13px' }} />
                  <div className="absolute h-56 w-56 rounded-full border border-brand-400/30 shadow-[0_0_55px_rgba(16,185,129,.12)]" />
                  <div className="absolute h-40 w-40 rounded-full border border-cyan-400/20" />
                  <div className="absolute h-24 w-24 rounded-full border border-brand-400/20 bg-brand-400/5" />
                  <div className="absolute h-px w-full bg-gradient-to-r from-transparent via-brand-400/60 to-transparent" />
                  <div className="relative text-center">
                    <div className="text-4xl font-black text-brand-300">CG</div>
                    <div className="mt-1 text-[9px] uppercase tracking-[.35em] text-slate-500">Threat intelligence</div>
                  </div>
                  <div className="absolute bottom-4 left-4 right-4 rounded-xl border border-surface-700 bg-surface-950/80 p-4 backdrop-blur-md">
                    <div className="mb-3 flex items-center justify-between text-[10px] uppercase tracking-[.16em] text-slate-500"><span>Scan in progress</span><span className="text-brand-400">84%</span></div>
                    {['Fetching site information', 'Analyzing security headers', 'Checking cookie configuration', 'Detecting trackers and third parties', 'Computing scores'].map((step, i) => (
                      <div key={step} className="flex items-center gap-2 py-1 text-xs text-slate-300">
                        <span className={i < 4 ? 'text-brand-400' : 'text-slate-600'}>{i < 4 ? '✓' : '○'}</span>{step}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="rounded-xl border border-surface-800 bg-surface-950/50 p-3"><div className="text-xl font-bold text-brand-300">85</div><div className="text-[9px] uppercase tracking-wider text-slate-500">Security</div></div>
                  <div className="rounded-xl border border-surface-800 bg-surface-950/50 p-3"><div className="text-xl font-bold text-cyan-300">92</div><div className="text-[9px] uppercase tracking-wider text-slate-500">Privacy</div></div>
                  <div className="rounded-xl border border-surface-800 bg-surface-950/50 p-3"><div className="text-xl font-bold text-brand-300">LOW</div><div className="text-[9px] uppercase tracking-wider text-slate-500">Risk</div></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="features" className="relative mx-auto max-w-7xl px-5 py-12 lg:px-8 lg:py-16">
          <div className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div><div className="cyber-kicker">Security modules</div><h2 className="mt-3 text-3xl font-bold text-white">One command center. Multiple layers of defense.</h2></div>
            <p className="max-w-md text-sm leading-6 text-slate-500">{t('landing.trust.desc')}</p>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {FEATURES.map((f, i) => (
              <div key={f} className="cyber-feature group">
                <div className="mb-5 flex h-10 w-10 items-center justify-center rounded-xl border border-brand-500/20 bg-brand-500/5 font-mono text-sm text-brand-300 transition group-hover:shadow-[0_0_24px_rgba(52,211,153,.14)]">0{i + 1}</div>
                <h3 className="font-semibold text-slate-100">{t(`landing.feature.${f}.title`)}</h3>
                <p className="mt-2 text-sm leading-6 text-slate-500">{t(`landing.feature.${f}.desc`)}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="trust" className="mx-auto max-w-7xl px-5 py-16 lg:px-8">
          <div className="cyber-glass relative overflow-hidden p-8 sm:p-12">
            <div className="absolute right-0 top-0 h-64 w-64 rounded-full bg-cyan-400/5 blur-3xl" />
            <div className="relative grid gap-10 lg:grid-cols-[1fr_.9fr] lg:items-center">
              <div>
                <div className="cyber-kicker">More than a scanner</div>
                <h2 className="mt-5 text-4xl font-black tracking-tight text-white sm:text-5xl">Make the web <span className="cyber-title-accent">a safer place.</span></h2>
                <p className="mt-5 max-w-2xl leading-7 text-slate-400">CyberGuard turns passive security signals into clear findings, evidence, severity, impact and actionable recommendations.</p>
                <div className="mt-7 flex flex-wrap gap-3"><Link to="/signup" className="btn-primary">Start Scanning Now →</Link><Link to="/login" className="btn-secondary">Open Dashboard</Link></div>
              </div>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-2">
                {['Detection', 'Evidence', 'Privacy', 'Verification'].map((item, i) => <div key={item} className="rounded-2xl border border-surface-800 bg-surface-950/55 p-5"><div className="font-mono text-xs text-brand-400">0{i + 1}</div><div className="mt-3 font-semibold text-white">{item}</div><div className="mt-1 text-xs text-slate-500">Built into the workflow</div></div>)}
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-3xl px-5 py-12 lg:px-8">
          <h2 className="text-center text-2xl font-bold text-white">{t('landing.trust.title')}</h2>
          <div className="mt-8 space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="cyber-glass overflow-hidden">
                <button className="flex w-full items-center justify-between p-4 text-start font-medium text-slate-200" onClick={() => setFaq(faq === i ? null : i)}>
                  {t(`landing.faq.q${i}`)}<span className="text-brand-400">{faq === i ? '−' : '+'}</span>
                </button>
                {faq === i && <p className="border-t border-surface-800 px-4 pb-5 pt-4 text-sm leading-6 text-slate-500">{t(`landing.faq.a${i}`)}</p>}
              </div>
            ))}
          </div>
        </section>
      </main>

      <footer className="mt-10 border-t border-surface-800/80 bg-black/20 py-10 text-center text-sm text-slate-500">
        <div className="mx-auto flex max-w-7xl flex-col items-center gap-2 px-5"><div className="flex items-center gap-2 text-slate-300"><Logo size={22} /><span className="font-semibold">CyberGuard</span></div><p>© {new Date().getFullYear()} CyberGuard — {t('landing.footer.rights')}</p><p className="max-w-2xl text-xs">{t('landing.footer.disclaimer')}</p></div>
      </footer>
    </div>
  )
}
