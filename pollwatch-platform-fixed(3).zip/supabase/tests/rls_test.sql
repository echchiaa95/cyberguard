-- ============================================================================
-- اختبارات pgTAP على سياسات RLS — تشغيل: supabase test db
-- تفترض pgtap مثبت: create extension if not exists pgtap;
-- ============================================================================
begin;
select plan(12);

-- ---------------------------------------------------------------------------
-- إعداد: حزبان، مراقب لكل حزب، موافقة/لا موافقة على الموقع
-- (المستخدمون الوهميون في auth.users عبر service role في بيئة الاختبار)
-- ---------------------------------------------------------------------------
do $$
declare
  u_admin uuid := gen_random_uuid();
  u_obs_a uuid := gen_random_uuid();
  u_obs_b uuid := gen_random_uuid();
  p_a uuid; p_b uuid; o_a uuid; o_b uuid; st_a uuid;
begin
  insert into auth.users (id, email) values
    (u_admin, 'admin@test.ma'), (u_obs_a, 'obs-a@test.ma'), (u_obs_b, 'obs-b@test.ma')
    on conflict do nothing;

  insert into public.parties (name_ar, slug) values ('حزب أ', 'party-a'), ('حزب ب', 'party-b')
    returning id into p_a;
  select id into p_b from public.parties where slug = 'party-b';

  insert into public.party_members (party_id, user_id, role_id, full_name)
    select null, u_admin, id, 'SA' from public.roles where key = 'superadmin';
  insert into public.party_members (party_id, user_id, role_id, full_name)
    select p_a, u_obs_a, id, 'OBS-A' from public.roles where key = 'observer';
  insert into public.party_members (party_id, user_id, role_id, full_name)
    select p_b, u_obs_b, id, 'OBS-B' from public.roles where key = 'observer';

  insert into public.observers (party_id, full_name) values (p_a, 'مراقب أ') returning id into o_a;
  insert into public.observers (party_id, full_name) values (p_b, 'مراقب ب') returning id into o_b;
  update public.observers set user_id = u_obs_a where id = o_a;
  update public.observers set user_id = u_obs_b where id = o_b;

  insert into public.polling_stations (party_id, station_number, name_ar)
    values (p_a, 'T-001', 'مكتب أ') returning id into st_a;

  -- موافقة GPS لمراقب أ فقط
  insert into public.consent_records (party_id, user_id, subject_type, subject_id, consent_type, granted, consent_text_version)
    values (p_a, u_obs_a, 'observer', o_a, 'location_tracking', true, 'v1');

  -- حقن في JWT الوهمي
  perform set_config('request.jwt.claims', json_build_object(
    'sub', u_obs_a::text, 'party_id', p_a::text)::text, true);
end $$;

-- ---------------------------------------------------------------------------
-- اختبارات العزل بين المستأجرين
-- ---------------------------------------------------------------------------

-- 1) مراقب الحزب أ يرى مكتب حزبه
select ok(
  exists(select 1 from public.polling_stations where station_number = 'T-001'),
  'observer-a can see own party station'
);

-- 2) مراقب الحزب أ لا يرى مراقبي الحزب ب
select is(
  (select count(*) from public.observers where full_name = 'مراقب ب'),
  0::bigint,
  'observer-a cannot see party-b observers (tenant isolation)'
);

-- 3) مراقب الحزب أ لا يستطيع إنشاء مكتب لحزب آخر (with check)
select is(
  (insert into public.polling_stations (party_id, station_number, name_ar)
   select id, 'HACK-001', 'اختراق' from public.parties where slug = 'party-b'
   returning 1),
  null,
  'observer-a cannot insert station into party-b'
);

-- 4) لا إدخال موقع بدون جلسة مفتوحة (سياسة consent/join)
do $$ declare o_a uuid; st_a uuid; begin
  select id into o_a from public.observers where full_name = 'مراقب أ';
  select id into st_a from public.polling_stations where station_number = 'T-001';
  insert into public.count_sessions (party_id, observer_id, polling_station_id)
    values ((select party_id from public.observers where id = o_a), o_a, st_a);
end $$;

-- 5) المراقب يستطيع إدخال موقعه (لديه موافقة + جلسة)
select ok(
  (with s as (select id from public.count_sessions limit 1)
   insert into public.observer_locations (party_id, observer_id, session_id, location, expires_at)
   select (select party_id from public.observers where full_name = 'مراقب أ'),
          (select id from public.observers where full_name = 'مراقب أ'),
          (select id from s), st_geogfromtext('POINT(-7 33.5)'), now() + interval '1 hour'
   returning true),
  'observer with consent+session can insert location'
);

-- 6) idempotency: نفس client_id مرتين ← الثانية ترفض (unique)
select is(
  (with s as (select id from public.count_sessions limit 1)
   insert into public.vote_entries (party_id, session_id, candidate_code, client_id)
   select (select party_id from public.observers where full_name = 'مراقب أ'),
          (select id from s), 'c1', '11111111-1111-1111-1111-111111111111'
   on conflict (session_id, client_id) do nothing
   returning 1),
  1::integer,
  'vote entry inserts once (idempotent client_id)'
);

-- 7) التراجع ينقص الإجمالي عبر trigger
insert into public.vote_entries (party_id, session_id, candidate_code, action, client_id)
select (select party_id from public.observers where full_name = 'مراقب أ'),
       (select id from public.count_sessions limit 1), 'c1', 'revert', gen_random_uuid();
select is(
  (select totals ->> 'c1' from public.count_sessions limit 1),
  '0',
  'revert action decrements totals via trigger'
);

-- 8) المراقب لا يستطيع تعديل audit_logs (append-only)
select throws_ok(
  $$ update public.audit_logs set action = 'tampered' $$,
  'append-only table: UPDATE not allowed',
  'audit_logs blocks UPDATE'
);

-- 9) المراقب لا يستطيع حذف موافقات
select throws_ok(
  $$ delete from public.consent_records $$,
  'append-only table: DELETE not allowed',
  'consent_records blocks DELETE'
);

-- 10) المراقب لا يستطيع ربط دومين (حصري Superadmin) — RLS يرفض بالاستثناء
select throws_like(
  $$ insert into public.party_domains (party_id, domain, verification_token)
     select id, 'evil.ma', 'x' from public.parties where slug = 'party-a' $$,
  '%row-level security%',
  'observer cannot insert party_domains (superadmin only)'
);

-- 11) رفع صلاحية مستخدم إلى superadmin مستحيل من داخل حزب (no privesc)
select is(
  (update public.party_members set role_id = (select id from public.roles where key = 'superadmin')
   where full_name = 'OBS-A' returning 1),
  null,
  'privilege escalation to superadmin blocked'
);

-- 12) دالة is_superadmin تعيد false للمراقب
select is(public.is_superadmin(), false, 'observer is not superadmin');

select * from finish();
rollback;
