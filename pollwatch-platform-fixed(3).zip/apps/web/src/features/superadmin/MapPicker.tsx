import { useEffect, useRef, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import * as api from "../../lib/api";
import { addDarkTiles } from "../../shared/mapTiles";
import { Btn } from "../../shared/ui";

// ============================================================================
// منتقي الموقع على خريطة داكنة:
// - نقر لتحديد الموقع + Marker قابل للسحب
// - بحث عن منطقة/عنوان عبر Nominatim (مجاني، لا مفتاح)
// - زر "استخدام موقعي الحالي" مع معالجة رفض الصلاحية
// - عرض جميع المكاتب المرئية على الخريطة مع نافذة معلومات
// ============================================================================

export const isValidLat = (v: number | null | undefined): v is number =>
  v != null && Number.isFinite(v) && v >= -90 && v <= 90;
export const isValidLng = (v: number | null | undefined): v is number =>
  v != null && Number.isFinite(v) && v >= -180 && v <= 180;

const DEFAULT_CENTER: [number, number] = [33.8, -7.2];

export default function MapPicker({ lat, lng, onPick, stations, partyName, assignCounts }: {
  lat: number | null; lng: number | null;
  onPick: (lat: number, lng: number) => void;
  stations: api.StationRow[];
  partyName: (id: string) => string;
  assignCounts: Record<string, number>;
}) {
  const [mapEl, setMapEl] = useState<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  const layerRef = useRef<L.LayerGroup | null>(null);
  const [q, setQ] = useState("");
  const [results, setResults] = useState<{ display_name: string; lat: string; lon: string }[]>([]);
  const [geoMsg, setGeoMsg] = useState<string | null>(null);
  const [searching, setSearching] = useState(false);
  const [tileFallback, setTileFallback] = useState(false);

  // إنشاء الخريطة مرة واحدة — مع تهيئة مزدوجة للهاتف وبديل تلقائي للبلاطات
  useEffect(() => {
    if (!mapEl || mapRef.current) return;
    const hasInitial = isValidLat(lat) && isValidLng(lng);
    const map = L.map(mapEl, { zoomControl: true })
      .setView(hasInitial ? [lat, lng] : DEFAULT_CENTER, hasInitial ? 13 : 8);
    addDarkTiles(map, () => setTileFallback(true));
    layerRef.current = L.layerGroup().addTo(map);
    map.on("click", (e: L.LeafletMouseEvent) => {
      onPick(+e.latlng.lat.toFixed(6), +e.latlng.lng.toFixed(6));
    });
    mapRef.current = map;
    // invalidateSize مرتان: بعد أول رسم وبعد اكتمال تخطيط الجوال البطيء
    const t1 = setTimeout(() => map.invalidateSize(), 100);
    const t2 = setTimeout(() => map.invalidateSize(), 500);
    const onResize = () => map.invalidateSize();
    window.addEventListener("resize", onResize);
    return () => {
      clearTimeout(t1); clearTimeout(t2);
      window.removeEventListener("resize", onResize);
      map.remove(); mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mapEl]);

  // Marker المحدد — قابل للسحب، ويُحدّث الإحداثيات عند السحب
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    markerRef.current?.remove();
    markerRef.current = null;
    if (isValidLat(lat) && isValidLng(lng)) {
      markerRef.current = L.marker([lat, lng], { draggable: true, autoPan: true })
        .on("dragend", () => {
          const p = markerRef.current!.getLatLng();
          onPick(+p.lat.toFixed(6), +p.lng.toFixed(6));
        })
        .addTo(map);
      map.setView([lat, lng], Math.max(map.getZoom(), 13));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lat, lng]);

  // عرض جميع المكاتب التي يحق للمستخدم رؤيتها (محمي بـ RLS أصلاً)
  useEffect(() => {
    const layer = layerRef.current;
    if (!layer) return;
    layer.clearLayers();
    stations.forEach((s) => {
      if (!isValidLat(s.lat) || !isValidLng(s.lng)) return; // تجاوز بلا إحداثيات دون توقف
      const isSelected = s.lat === lat && s.lng === lng;
      L.circleMarker([s.lat, s.lng], {
        radius: isSelected ? 11 : 7,
        color: isSelected ? "#14b8a6" : "#94a3b8",
        weight: 2,
        fillColor: "#0f766e",
        fillOpacity: isSelected ? 0.95 : 0.55,
      })
        .bindPopup(
          `<b>${s.name_ar}</b><br>` +
          `${s.station_number} — ${s.city ?? ""} ${s.region ?? ""}<br>` +
          `الحزب: ${partyName(s.party_id)}<br>` +
          `الحالة: ${s.status}<br>` +
          `المراقبون: ${assignCounts[s.id] ?? 0}`
        )
        .addTo(layer);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stations, partyName, assignCounts, lat, lng]);

  const search = async () => {
    if (!q.trim()) return;
    setSearching(true); setGeoMsg(null);
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&limit=5&q=${encodeURIComponent(q)}`,
        { headers: { Accept: "application/json" } }
      );
      const data = await res.json();
      setResults(data);
      if (!data.length) setGeoMsg("لا توجد نتائج مطابقة — جرّب صيغة أخرى");
    } catch {
      setGeoMsg("فشل البحث — تحقق من الاتصال بالإنترنت");
    } finally { setSearching(false); }
  };

  const useMyLocation = () => {
    setGeoMsg(null);
    if (!("geolocation" in navigator)) return setGeoMsg("المتصفح لا يدعم تحديد الموقع الجغرافي");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const la = +pos.coords.latitude.toFixed(6);
        const ln = +pos.coords.longitude.toFixed(6);
        onPick(la, ln);
        mapRef.current?.setView([la, ln], 15);
      },
      (err) => setGeoMsg(
        err.code === err.PERMISSION_DENIED
          ? "تم رفض صلاحية الموقع — فعّلها من إعدادات المتصفح ثم أعد المحاولة"
          : "تعذّر تحديد موقعك الحالي — حدّد الموقع يدوياً بالنقر على الخريطة"
      )
    );
  };

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-2">
        <input dir="ltr" className="min-w-0 flex-1 rounded-xl border border-slate-700 bg-slate-800/80 px-3 py-2 text-sm text-slate-100 placeholder-slate-500 outline-none transition focus:border-teal-500 focus:ring-2 focus:ring-teal-500/30"
          placeholder="ابحث عن منطقة أو عنوان…" value={q}
          onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && search()} />
        <Btn variant="ghost" disabled={searching} onClick={search}>{searching ? "…" : "بحث"}</Btn>
        <Btn variant="ghost" onClick={useMyLocation}>📍 استخدام موقعي الحالي</Btn>
      </div>

      {results.length > 0 && (
        <div className="max-h-32 overflow-y-auto rounded-xl border border-slate-700 bg-slate-900">
          {results.map((r, i) => (
            <button key={i} dir="ltr"
              className="block w-full truncate px-3 py-1.5 text-start text-xs text-slate-300 transition hover:bg-slate-800"
              onClick={() => {
                onPick(+r.lat, +r.lon);
                mapRef.current?.setView([+r.lat, +r.lon], 14);
                setResults([]);
              }}>
              {r.display_name}
            </button>
          ))}
        </div>
      )}

      {geoMsg && <p className="text-xs text-amber-400">⚠ {geoMsg}</p>}
      {tileFallback && (
        <p className="text-xs text-slate-500">تعذّر تحميل خادم البلاطات الأساسي — تم التبديل تلقائياً إلى خادم بديل.</p>
      )}

      {/* الخريطة لا تغطي الأزرار: تأتي بعد عناصر التحكم وبرتبة z-0 */}
      <div ref={setMapEl} className="relative z-0 h-72 w-full overflow-hidden rounded-xl border border-slate-700 sm:h-80"
        style={{ touchAction: "auto", pointerEvents: "auto" }} />

      <div className="flex items-center justify-between rounded-xl bg-slate-800/60 px-3 py-2 text-xs text-slate-300" dir="ltr">
        <span>Latitude: <b className="tabular-nums">{isValidLat(lat) ? lat : "—"}</b></span>
        <span>Longitude: <b className="tabular-nums">{isValidLng(lng) ? lng : "—"}</b></span>
      </div>
    </div>
  );
}
