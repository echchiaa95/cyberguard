alter table public.count_sessions
  add column if not exists totals jsonb not null default '{}'::jsonb;
select pg_notify('pgrst', 'reload schema');
