import type { CheckResult, CheckCategory, ScanInput } from '../../../types'

type Check = Omit<CheckResult, 'scoreImpact'>

function check(partial: Check): Check { return partial }

import { baseDomain, hostOf } from '../../../lib/utils'

const KNOWN_TRACKERS: { pattern: RegExp; name: string }[] = [
  { pattern: /google-analytics\.com|googletagmanager\.com/, name: 'Google Analytics' },
  { pattern: /doubleclick\.net|googlesyndication\.com/, name: 'Google Ads / DoubleClick' },
  { pattern: /facebook\.net|facebook\.com\/tr/, name: 'Facebook Pixel' },
  { pattern: /hotjar\.com/, name: 'Hotjar' },
  { pattern: /segment\.com\/analytics|cdn\.segment\.com/, name: 'Segment' },
  { pattern: /mixpanel\.com/, name: 'Mixpanel' },
  { pattern: /scorecardresearch\.com/, name: 'Scorecard Research' },
  { pattern: /criteo\.com/, name: 'Criteo' },
  { pattern: /bing\.com\/bat|bat\.bing\.com/, name: 'Microsoft Clarity / Bing' },
]

export function analyzeTrackers(input: ScanInput): Omit<CheckResult, 'scoreImpact'>[] {
  const checks: Check[] = []
  const targetBase = baseDomain(hostOf(input.finalUrl))
  const allUrls = [
    ...input.resources.scripts,
    ...input.resources.iframes,
    ...input.resources.images,
    ...input.resources.pixels,
  ].map((u) => { try { return new URL(u, input.finalUrl).toString() } catch { return u } })

  const detected = new Map<string, string[]>()
  for (const u of allUrls) {
    for (const t of KNOWN_TRACKERS) {
      if (t.pattern.test(u)) {
        detected.set(t.name, [...(detected.get(t.name) ?? []), u])
      }
    }
  }

  if (detected.size === 0) {
    checks.push(check({
      checkId: 'trackers.known', module: 'trackers', category: 'trackers', severity: 'passed', status: 'pass',
      title: 'No known analytics or advertising trackers detected',
      evidence: 'Page resources were compared against a list of common analytics/advertising trackers; no match was found.',
      description: 'No tracker from the known-tracker list was observed on the analyzed page.',
      impact: 'Lower tracking exposure for visitors.',
      recommendation: 'Re-check after layout changes; trackers are often added via tag managers.',
      remediation: 'N/A',
    }))
  } else {
    const names = [...detected.keys()]
    checks.push(check({
      checkId: 'trackers.known', module: 'trackers', category: 'trackers', severity: 'medium', status: 'fail',
      title: 'Tracking detected: known third-party tracker(s)',
      evidence: names.map((n) => `${n}: ${detected.get(n)![0]}`).join(' | '),
      description: `The following analytics/advertising providers were observed: ${names.join(', ')}. This is observed evidence of loading their code; what data they collect is governed by their configuration and your consent setup.`,
      impact: 'Medium: visitor behavior may be shared with third parties; regulatory exposure (GDPR/CCPA) if consent is not handled correctly.',
      recommendation: 'Review each tracker, ensure it is disclosed in the privacy policy, and gate non-essential tracking behind a consent banner.',
      remediation: 'Load trackers only after consent; consider Consent Mode or removing unused tags.',
    }))
  }

  if (input.resources.pixels.length > 0) {
    checks.push(check({
      checkId: 'trackers.pixels', module: 'trackers', category: 'trackers', severity: 'medium', status: 'warn',
      title: 'Tracking detected: tracking pixel(s)',
      evidence: `Pixel-like resources: ${input.resources.pixels.slice(0, 10).join(', ')}`,
      description: 'Small invisible requests (pixels/beacons) were observed; they are typically used to report page views or conversions to third parties.',
      impact: 'Medium: contributes to cross-site tracking and may transmit visitor metadata.',
      recommendation: 'Verify each pixel is intentional and disclosed.',
      remediation: 'Remove unused pixels; fire them only after consent.',
    }))
  }

  const crossSiteCookies = (input.cookies ?? []).filter((c) => /samesite\s*=\s*none/i.test(c))
  if (crossSiteCookies.length > 0) {
    checks.push(check({
      checkId: 'trackers.crosssite-cookies', module: 'trackers', category: 'trackers', severity: 'low', status: 'warn',
      title: 'Third-party data sharing indicator: cross-site cookies',
      evidence: `SameSite=None cookie(s): ${crossSiteCookies.map((c) => c.split('=')[0]).join(', ')}`,
      description: 'Cookies set for cross-site contexts can be read in third-party contexts. This is an indicator to verify, not proof of data sharing.',
      impact: 'Low: enables third-party embedding scenarios; verify intended use.',
      recommendation: 'Confirm which third parties need these cookies and document them.',
      remediation: 'Minimize SameSite=None cookies and scope them narrowly.',
    }))
  }

  return checks
}
