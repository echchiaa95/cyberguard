# CyberGuard

**Know Your Security. Protect What Matters.**

CyberGuard is a security and privacy analysis platform for websites (Phase 1), with prepared
architecture for applications (Android APK), files/archives, continuous monitoring, reports,
and an AI Security Advisor (later phases).

CyberGuard never claims a website is "100% secure" and never invents findings. Every finding
follows: Detection → Evidence → Severity → Impact → Explanation → Recommendation → Fix.

## Tech stack

- React 18 + Vite + TypeScript
- Tailwind CSS (dark-first, light mode included)
- PWA (manifest + offline app shell; scanning requires network — never claimed to work offline)
- Supabase (PostgreSQL, Auth, Storage, Edge Functions, RLS)
- GitHub Pages hosting for the frontend

## Project structure

```
src/
  components/       reusable UI (Layout, ScoreRing, SeverityBadge, ProtectedRoute, ...)
  lib/              supabase client, i18n (en/fr/ar + RTL), demo data, utils
  pages/            landing, auth, dashboard, websites, scan results, history, ...
  services/
    scanner/        modular deterministic scanner engine (Phase 1)
      modules/      https, tls, headers, cookies, dns, privacy, trackers, exposure
      engine.ts     scoring engine (deterministic, explainable)
      index.ts      scanner service (orchestration, persistence, demo mode)
supabase/
  migrations/       SQL schema + RLS + storage bucket
  functions/        scan-website Edge Function (passive, non-destructive)
```

## Getting started

1. Create a Supabase project.
2. Run the migration: `supabase db push` (or paste `supabase/migrations/0001_init.sql`
   into the Supabase SQL editor).
3. Deploy the scanner Edge Function:
   `supabase functions deploy scan-website`
4. Copy `.env.example` to `.env` and fill in your project URL and **anon** key.
   Never use the service-role key in the frontend.
5. `npm install && npm run dev`

## Demo mode

If the Edge Function is not deployed yet, set `VITE_DEMO_MODE=true` to run the full
scan flow with clearly-labeled sample data. Demo data is **not** a real scan and is
always labeled as such in the UI.

## Build & deploy (GitHub Pages)

```
npm run build
```

Deploy the `dist/` folder to GitHub Pages (e.g. `npm i -D gh-pages`, `npx gh-pages -d dist`,
plus a GitHub Actions workflow if desired). Configure the Supabase Auth redirect URLs to
include your Pages domain.

## Security notes

- Row Level Security on every user table; users access only their own data.
- Private `uploads` storage bucket; files are never publicly accessible.
- No secrets in the frontend; `.env` is git-ignored.
- The Edge Function blocks private/loopback targets (SSRF protection) and performs only
  passive, read-only analysis.

## Phase status

**Phase 1 (this build):** landing page, auth, dashboard shell, i18n (en/fr/ar), website
management, scan flow, modular scanner engine, security + privacy scores, results with
evidence-based findings, history. Prepared (schema/UI, not functional): applications,
files, monitoring, alerts, reports, subscriptions, AI advisor.

Active/intrusive testing, monitoring execution, APK/archive scanning, PDF reports and the
AI advisor are intentionally **not** implemented yet.
