-- CyberGuard plan entitlements and server-side website limit enforcement.
-- No payment logic is included here. Missing/invalid subscriptions fall back to Free.

create or replace function public.cg_current_plan_code(p_user_id uuid)
returns text
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    (
      select sp.code
      from public.user_subscriptions us
      join public.subscription_plans sp on sp.id = us.plan_id
      where us.user_id = p_user_id
        and us.status = 'active'
        and (us.current_period_end is null or us.current_period_end > now())
      limit 1
    ),
    'free'
  );
$$;

create or replace function public.cg_website_count(p_user_id uuid)
returns integer
language sql
stable
security definer
set search_path = public
as $$
  select count(*)::integer from public.websites where user_id = p_user_id;
$$;

create or replace function public.cg_website_limit(p_user_id uuid)
returns integer
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    (
      select greatest(1, coalesce((sp.features->>'websites')::integer, 1))
      from public.user_subscriptions us
      join public.subscription_plans sp on sp.id = us.plan_id
      where us.user_id = p_user_id
        and us.status = 'active'
        and (us.current_period_end is null or us.current_period_end > now())
      limit 1
    ),
    1
  );
$$;

revoke all on function public.cg_current_plan_code(uuid) from public;
grant execute on function public.cg_current_plan_code(uuid) to authenticated;
revoke all on function public.cg_website_limit(uuid) from public;
grant execute on function public.cg_website_limit(uuid) to authenticated;
revoke all on function public.cg_website_count(uuid) from public;
grant execute on function public.cg_website_count(uuid) to authenticated;

-- Replace the insert policy with the first server-side entitlement check.
drop policy if exists "websites_insert_own" on public.websites;
create policy "websites_insert_own"
on public.websites
for insert
to authenticated
with check (
  auth.uid() = user_id
  and public.cg_website_count(auth.uid()) < public.cg_website_limit(auth.uid())
);

-- Close the race where two concurrent inserts could otherwise pass the count check.
create or replace function public.cg_enforce_website_limit()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  limit_count integer;
  current_count integer;
begin
  perform pg_advisory_xact_lock(hashtextextended(coalesce(new.user_id::text, ''), 0));

  limit_count := public.cg_website_limit(new.user_id);
  current_count := public.cg_website_count(new.user_id);

  if current_count >= limit_count then
    raise exception 'CYBERGUARD_WEBSITE_LIMIT_REACHED'
      using errcode = 'P0001',
            detail = format('Website limit reached: %s', limit_count);
  end if;

  return new;
end;
$$;

revoke all on function public.cg_enforce_website_limit() from public;
grant execute on function public.cg_enforce_website_limit() to authenticated;

drop trigger if exists trg_websites_plan_limit on public.websites;
create trigger trg_websites_plan_limit
before insert on public.websites
for each row
execute function public.cg_enforce_website_limit();
