import React, { createContext, useCallback, useContext, useEffect, useState } from 'react'
import { isDemoMode, isSupabaseConfigured, supabase } from './supabase'
import type { Profile } from '../types'

interface AuthContextValue {
  user: { id: string; email: string } | null
  profile: Profile | null
  loading: boolean
  isDemo: boolean
  isConfigured: boolean
  signIn: (email: string, password: string) => Promise<{ error: string | null }>
  signUp: (email: string, password: string, fullName: string) => Promise<{ error: string | null }>
  signOut: () => Promise<void>
  sendResetLink: (email: string) => Promise<{ error: string | null }>
  updatePassword: (password: string) => Promise<{ error: string | null }>
  refreshProfile: () => Promise<void>
}

const AuthContext = createContext<AuthContextValue | null>(null)

const DEMO_USER = { id: '00000000-0000-4000-8000-000000000000', email: 'demo@cyberguard.local' }

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<{ id: string; email: string } | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const isDemo = isDemoMode
  const isConfigured = isSupabaseConfigured

  const loadProfile = useCallback(async (userId: string, email: string) => {
    if (!supabase) {
      setProfile({ id: userId, email, preferredLanguage: 'en' })
      return
    }
    const { data } = await supabase.from('profiles').select('*').eq('id', userId).single()
    if (data) {
      setProfile({
        id: data.id,
        email: data.email,
        fullName: data.full_name ?? undefined,
        preferredLanguage: data.preferred_language ?? 'en',
      })
    }
  }, [])

  useEffect(() => {
    if (!supabase) {
      // Demo mode: local-only session so the full flow can be verified without a backend.
      if (isDemoMode && localStorage.getItem('cg_demo_session') === '1') {
        setUser(DEMO_USER)
        void loadProfile(DEMO_USER.id, DEMO_USER.email)
      }
      setLoading(false)
      return
    }
    supabase.auth.getSession().then(({ data }) => {
      const u = data.session?.user
      if (u) {
        setUser({ id: u.id, email: u.email ?? '' })
        void loadProfile(u.id, u.email ?? '')
      }
      setLoading(false)
    })
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      const u = session?.user
      setUser(u ? { id: u.id, email: u.email ?? '' } : null)
      if (u) void loadProfile(u.id, u.email ?? '')
      else setProfile(null)
    })
    return () => sub.subscription.unsubscribe()
  }, [loadProfile])

  const signIn = useCallback(async (email: string, password: string) => {
    if (!supabase) {
      if (isDemoMode && email === DEMO_USER.email && password.length >= 6) {
        localStorage.setItem('cg_demo_session', '1')
        setUser(DEMO_USER)
        await loadProfile(DEMO_USER.id, DEMO_USER.email)
        return { error: null }
      }
      return { error: 'auth.error.config' }
    }
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    return { error: error ? (error.message.includes('Invalid') ? 'auth.error.invalid' : 'auth.error.generic') : null }
  }, [loadProfile])

  const signUp = useCallback(async (email: string, password: string, fullName: string) => {
    if (!supabase) {
      if (isDemoMode) {
        localStorage.setItem('cg_demo_session', '1')
        setUser(DEMO_USER)
        await loadProfile(DEMO_USER.id, DEMO_USER.email)
        return { error: null }
      }
      return { error: 'auth.error.config' }
    }
    const { error } = await supabase.auth.signUp({
      email, password,
      options: { data: { full_name: fullName }, emailRedirectTo: `${window.location.origin}/` },
    })
    return { error: error ? 'auth.error.generic' : null }
  }, [loadProfile])

  const signOut = useCallback(async () => {
    if (!supabase) {
      localStorage.removeItem('cg_demo_session')
      setUser(null)
      setProfile(null)
      return
    }
    await supabase.auth.signOut()
  }, [])

  const sendResetLink = useCallback(async (email: string) => {
    if (!supabase) return { error: 'auth.error.config' }
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    })
    return { error: error ? 'auth.error.generic' : null }
  }, [])

  const updatePassword = useCallback(async (password: string) => {
    if (!supabase) return { error: 'auth.error.config' }
    const { error } = await supabase.auth.updateUser({ password })
    return { error: error ? 'auth.error.generic' : null }
  }, [])

  const refreshProfile = useCallback(async () => {
    if (user) await loadProfile(user.id, user.email)
  }, [user, loadProfile])

  return (
    <AuthContext.Provider value={{
      user, profile, loading, isDemo, isConfigured,
      signIn, signUp, signOut, sendResetLink, updatePassword, refreshProfile,
    }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
