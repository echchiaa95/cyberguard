import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'

// GitHub Pages SPA fallback (see public/404.html): when a deep link lands as
// /?p=/app/websites, rewrite history so react-router sees the real route.
const redirect = new URLSearchParams(window.location.search).get('p')
if (redirect) {
  window.history.replaceState(null, '', redirect)
}

if ('serviceWorker' in navigator && import.meta.env.PROD) {
  navigator.serviceWorker.register('/sw.js').catch(() => {
    // Offline shell is a progressive enhancement; ignore registration failures.
  })
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
