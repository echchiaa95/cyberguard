import type { ScanInput, ScanRecord, Website, HistoryPoint } from '../types'

/**
 * Sample scan dataset used ONLY when VITE_DEMO_MODE is enabled and the real
 * scanner Edge Function is not deployed. Every UI surface labels it as demo data.
 */
export const DEMO_INPUT: ScanInput = {
  url: 'https://demo-shop.example',
  finalUrl: 'https://demo-shop.example/',
  status: 200,
  headers: {
    'server': 'nginx',
    'content-type': 'text/html; charset=utf-8',
    'x-content-type-options': 'nosniff',
    'set-cookie': 'session_id=demo123; Path=/; SameSite=Lax',
    'cache-control': 'no-cache',
  },
  cookies: ['session_id=demo123; Path=/; SameSite=Lax'],
  resources: {
    scripts: [
      'https://demo-shop.example/js/app.js',
      'https://www.google-analytics.com/analytics.js',
      'https://connect.facebook.net/en_US/fbevents.js',
    ],
    iframes: [],
    images: ['https://demo-shop.example/img/logo.png'],
    styles: ['https://demo-shop.example/css/main.css'],
    preconnects: ['https://fonts.gstatic.com'],
    pixels: ['https://www.facebook.com/tr?id=demo&ev=PageView'],
  },
  generator: 'WordPress 6.5',
  htmlLength: 48210,
  dns: { hostname: 'demo-shop.example', a: ['93.184.216.34'] },
  scannedAt: new Date().toISOString(),
}

export const DEMO_WEBSITES: Website[] = [
  { id: 'w-demo-1', url: 'https://demo-shop.example', normalizedUrl: 'https://demo-shop.example', createdAt: new Date(Date.now() - 7 * 864e5).toISOString() },
]

export const DEMO_SCAN_RECORDS: ScanRecord[] = [
  { id: 's-demo-1', websiteId: 'w-demo-1', target: 'https://demo-shop.example', status: 'completed', securityScore: 68, privacyScore: 54, riskLevel: 'high', findingsCount: 8, passedCount: 5, createdAt: new Date(Date.now() - 7 * 864e5).toISOString(), completedAt: new Date(Date.now() - 7 * 864e5).toISOString() },
]

export const DEMO_HISTORY: HistoryPoint[] = [
  { scanId: 's-demo-old-1', target: 'https://demo-shop.example', securityScore: 61, privacyScore: 48, findingsCount: 10, recordedAt: new Date(Date.now() - 6 * 864e5).toISOString() },
  { scanId: 's-demo-old-2', target: 'https://demo-shop.example', securityScore: 64, privacyScore: 50, findingsCount: 9, recordedAt: new Date(Date.now() - 4 * 864e5).toISOString() },
  ...DEMO_SCAN_RECORDS.map((s) => ({
    scanId: s.id, target: s.target, securityScore: s.securityScore!, privacyScore: s.privacyScore, findingsCount: s.findingsCount, recordedAt: s.createdAt,
  })),
]
