// أنواع البيانات — تطابق supabase/schema.sql
export type RoleKey = "superadmin" | "party_admin" | "observer" | "assistant";
export type PartyStatus = "active" | "suspended" | "pending";
export type StationStatus = "planned" | "open" | "counting" | "closed" | "report_received";
export type SessionStatus = "open" | "submitted" | "validated" | "returned";
export type ReportStatus = "draft" | "submitted" | "reviewed" | "flagged";
export type SourceType = "official" | "entered" | "estimate" | "under_review";

export interface Party {
  id: string;
  name_ar: string;
  name_fr?: string;
  slug: string;
  status: PartyStatus;
  colors: { primary: string; secondary: string };
  logo_path?: string;
}

export interface PartyDomain {
  id: string;
  party_id: string;
  domain: string;
  is_primary: boolean;
  wildcard: boolean;
  verified: boolean;
  ssl: "pending" | "issued" | "failed";
}

export interface Member {
  id: string;
  party_id: string | null;
  role: RoleKey;
  full_name: string;
  phone?: string;
  status: "active" | "suspended" | "pending";
}

export interface Observer {
  id: string;
  party_id: string;
  full_name: string;
  phone?: string;
  status: "active" | "inactive";
}

export interface Assistant {
  id: string;
  party_id: string;
  full_name: string;
  phone?: string;
  city?: string;
  region?: string;
  status: "active" | "inactive";
  admin_notes?: string;
}

export interface Station {
  id: string;
  party_id: string;
  station_number: string;
  name_ar: string;
  city?: string;
  region?: string;
  lat: number;
  lng: number;
  status: StationStatus;
}

export interface Assignment {
  observer_id: string;
  station_id: string;
}

export interface LocationPing {
  observer_id: string;
  lat: number;
  lng: number;
  recorded_at: string;
}

export interface CountSession {
  id: string;
  party_id: string;
  observer_id: string;
  station_id: string;
  started_at: string;
  ended_at?: string;
  status: SessionStatus;
  totals: Record<string, number>;
  candidate_names: Record<string, string>;
}

export interface VoteEntry {
  session_id: string;
  candidate_code: string;
  action: "add" | "revert";
  client_id: string;
  created_at: string;
}

export interface Report {
  id: string;
  party_id: string;
  author_name: string;
  station_id?: string;
  kind: "field_report" | "count_minutes" | "incident";
  body: string;
  status: ReportStatus;
  submitted_at: string;
}

export interface Session {
  role: RoleKey;
  partyId: string | null;
  memberName: string;
  observerId?: string;
}

// سجل سنة انتخابية للمقارنة التاريخية — كل رقم يحمل مصدره ونوع بياناته
export interface ElectionHistory {
  year: number;
  label_ar: string;
  participation_rate: number | null;   // رسمي
  coverage_rate: number;               // ميداني
  reports_received: number;
  reports_reviewed_rate: number;       // %
  avg_report_minutes: number;          // متوسط زمن استقبال التقرير
  support_votes_estimate: number | null; // تقديري — يُعرض منفصلاً دائماً
  stations_count: number;
  source: SourceType;                  // نوع البيانات الغالب
}
