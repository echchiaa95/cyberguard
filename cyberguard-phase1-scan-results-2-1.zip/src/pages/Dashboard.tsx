import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import { useI18n } from '../lib/i18n'
import { ScoreRing } from '../components/ScoreRing'
import { SeverityBadge } from '../components/SeverityBadge'
import { EmptyState } from '../components/EmptyState'
import { getScanChecks, listHistory, listScans } from '../services/db'
import type { CheckResult, HistoryPoint, ScanRecord } from '../types'

export function Dashboard() {
  const { user } = useAuth()
  const { t, lang } = useI18n()
  const [scans, setScans] = useState<ScanRecord[]>([])
  const [history, setHistory] = useState<HistoryPoint[]>([])
  const [fixes, setFixes] = useState<CheckResult[]>([])
  const [risk, setRisk] = useState<Record<string, number>>({})
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    if (!user) return
    let cancelled = false
    void (async () => {
      const [s, h] = await Promise.all([listScans(user.id), listHistory(user.id)])
      if (cancelled) return
      setScans(s)
      setHistory(h)
      const latest = s.find((x) => x.status === 'completed' && x.securityScore !== undefined)
      if (latest) {
        const checks = await getScanChecks(user.id, latest.id)
        if (cancelled) return
        const counts: Record<string, number> = { critical: 0, high: 0, medium: 0, low: 0 }
        for (const c of checks) {
          if (c.status !== 'pass' && c.severity in counts) counts[c.severity]++
        }
        setRisk(counts)
        setFixes(checks
          .filter((c) => c.status !== 'pass' && c.scoreImpact > 0 && c.severity !== 'info')
          .sort((a, b) => b.scoreImpact - a.scoreImpact)
          .slice(0, 5))
      }
      setLoaded(true)
    })()
    return () => { cancelled = true }
  }, [user])

  const latest = scans.find((s) => s.status === 'completed' && s.securityScore !== undefined)
  const lastTwo = history.slice(-2)
  const delta = lastTwo.length === 2 ? lastTwo[1].securityScore - lastTwo[0].securityScore : null

  if (loaded && !latest) {
    return (
      <div className="space-y-5">
        <div className="cyber-kicker">Security command center</div>
        <h1 className="mb-6 text-2xl font-bold text-white">{t('nav.dashboard')}</h1>
        <EmptyState title={t('dash.noScans')}
          action={<Link to="/app/websites" className="btn-primary">{t('sites.add')}</Link>} />
      </div>
    )
  }

  return (
    <div className="relative space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div><div className="cyber-kicker">Live posture</div><h1 className="mt-3 text-3xl font-black tracking-tight text-white">{t('dash.overview')}</h1><p className="mt-2 text-sm text-slate-500">Security, privacy and risk signals in one place.</p></div><div className="hidden rounded-xl border border-brand-500/10 bg-brand-500/5 px-3 py-2 font-mono text-[10px] text-brand-400 sm:block">● SYSTEM READY</div></div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="card flex flex-col items-center gap-2 p-6">
          <h2 className="self-start text-sm font-medium text-slate-400">{t('dash.securityScore')}</h2>
          <ScoreRing score={latest?.securityScore ?? 0} label="Security" />
        </div>
        <div className="card flex flex-col items-center gap-2 p-6">
          <h2 className="self-start text-sm font-medium text-slate-400">{t('dash.privacyScore')}</h2>
          <ScoreRing score={latest?.privacyScore ?? 0} label="Privacy" />
        </div>
        <div className="card p-6">
          <h2 className="text-sm font-medium text-slate-400">{t('dash.currentRisks')}</h2>
          <div className="mt-4 space-y-2">
            {(['critical', 'high', 'medium', 'low'] as const).map((s) => (
              <div key={s} className="flex items-center justify-between">
                <SeverityBadge severity={s} />
                <span className="font-bold tabular-nums text-slate-100">{risk[s] ?? 0}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="card p-6">
          <h2 className="text-sm font-medium text-slate-400">{t('dash.improvement')}</h2>
          {delta === null ? (
            <p className="mt-4 text-sm text-slate-500">{t('common.noData')}</p>
          ) : (
            <div className="mt-4 space-y-1 text-sm">
              <p className="text-slate-400">{t('dash.previous')}: <b className="text-slate-100">{lastTwo[0].securityScore}</b></p>
              <p className="text-slate-400">{t('dash.current')}: <b className="text-slate-100">{lastTwo[1].securityScore}</b></p>
              <p className={delta >= 0 ? 'text-sev-passed' : 'text-sev-critical'}>
                {delta >= 0 ? '▲' : '▼'} {t(delta >= 0 ? 'dash.improvedBy' : 'dash.declinedBy', { n: Math.abs(delta) })}
              </p>
            </div>
          )}
        </div>
      </div>

      {fixes.length > 0 && (
        <div className="card p-6">
          <h2 className="font-semibold text-slate-100">{t('dash.priorityFixes')}</h2>
          <p className="mt-1 text-sm text-slate-500">{t('dash.priorityFixes.hint')}</p>
          <ul className="mt-4 divide-y divide-surface-800">
            {fixes.map((f) => (
              <li key={f.checkId} className="flex flex-wrap items-center justify-between gap-3 py-3">
                <div className="flex min-w-0 items-center gap-3">
                  <SeverityBadge severity={f.severity} />
                  <span className="truncate text-sm text-slate-200">{f.title}</span>
                </div>
                <span className="badge border-sev-passed/30 bg-sev-passed/10 text-sev-passed">
                  {t('dash.estimatedGain', { n: f.scoreImpact })}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="card p-6">
        <h2 className="mb-4 font-semibold text-slate-100">{t('dash.recentScans')}</h2>
        {scans.length === 0 ? (
          <p className="text-sm text-slate-500">{t('common.noData')}</p>
        ) : (
          <ul className="divide-y divide-surface-800">
            {scans.slice(0, 5).map((s) => (
              <li key={s.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
                <div className="min-w-0">
                  <Link to={`/app/scans/${s.id}`} className="block truncate text-sm font-medium text-brand-400 hover:underline">{s.target}</Link>
                  <p className="text-xs text-slate-500">{new Date(s.createdAt).toLocaleDateString(lang)}</p>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  {s.securityScore !== undefined && <b className="text-slate-100">{s.securityScore}</b>}
                  {s.riskLevel && <SeverityBadge severity={s.riskLevel} />}
                  {s.status === 'failed' && <span className="text-sev-critical">{t('scan.failed')}</span>}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}
