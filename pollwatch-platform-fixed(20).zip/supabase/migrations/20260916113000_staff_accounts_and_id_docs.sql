-- حسابات المراقبين/المساعدين + وثائق الهوية في التخزين الخاص
alter table public.observers  add column if not exists user_id uuid references auth.users(id) on delete set null;
alter table public.assistants add column if not exists user_id uuid references auth.users(id) on delete set null;
alter table public.assistants add column if not exists national_id_path text;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('id-documents', 'id-documents', false, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

drop policy if exists id_docs_insert on storage.objects;
create policy id_docs_insert on storage.objects for insert to authenticated
with check (bucket_id = 'id-documents' and (
  public.is_superadmin()
  or (public.my_role_key() = 'party_admin' and public.my_party_id()::text = (storage.foldername(name))[1])
));
drop policy if exists id_docs_select on storage.objects;
create policy id_docs_select on storage.objects for select to authenticated
using (bucket_id = 'id-documents' and (
  public.is_superadmin()
  or (public.my_role_key() = 'party_admin' and public.my_party_id()::text = (storage.foldername(name))[1])
));
drop policy if exists id_docs_delete on storage.objects;
create policy id_docs_delete on storage.objects for delete to authenticated
using (bucket_id = 'id-documents' and (
  public.is_superadmin()
  or (public.my_role_key() = 'party_admin' and public.my_party_id()::text = (storage.foldername(name))[1])
));
