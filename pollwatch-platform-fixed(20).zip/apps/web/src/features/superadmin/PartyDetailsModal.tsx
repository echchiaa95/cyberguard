import { useMemo, useRef, useState } from "react";
import * as api from "../../lib/api";
import { Badge, Btn, Card, ErrorBox, Field, Modal, Skeleton, StatCard, compressImage, inputCls, statusTone, timeAgo, useLoad } from "../../shared/ui";

// تحقق صارم من صيغة الدومين (FQDN بسيط بلا بروتوكول)
const DOMAIN_RE = /^(?!-)[a-z0-9-]{1,63}(?<!-)(\.(?!-)[a-z0-9-]{1,63}(?<!-))+$/;

export default function PartyDetailsModal({ party, onClose, onChanged }: {
  party: api.PartyRow; onClose: () => void; onChanged: () => void;
}) {
  const [logo, setLogo] = useState<string | null>(party.logo_path);
  const [logoBusy, setLogoBusy] = useState(false);
  const logoFileRef = useRef<HTMLInputElement>(null);

  const changeLogo = async (file: File) => {
    setLogoBusy(true);
    try {
      const blob = await compressImage(file, 800, 0.85);
      const url = await api.uploadPartyLogo(party.id, blob);
      await api.setPartyLogo(party.id, url);
      setLogo(url);
      onChanged();
    } catch (e) { alert(e instanceof Error ? e.message : String(e)); }
    finally { setLogoBusy(false); }
  };

  const stats = useLoad(async () => {
    // كل الاستعلامات مفلترة بـ party_id — لا تسرب بين الأحزاب، وتفرض RLS الصلاحيات
    const [domains, assistants, observers, stations, reports, sessions] = await Promise.all([
      api.listDomainsByParty(party.id),
      api.listAssistants(party.id),
      api.listObservers(party.id),
      api.listStations(party.id),
      api.listReports(party.id),
      api.listPartySessions(party.id),
    ]);
    return { domains, assistants, observers, stations, reports, sessions };
  }, [party.id]);

  const d = useMemo(() => {
    const s = stats.data;
    if (!s) return null;
    const reports = s.reports;
    const completed = reports.filter((r) => r.status === "reviewed").length;
    const latestSession = [...s.sessions].sort((a, b) => b.started_at.localeCompare(a.started_at))[0];
    const lastVotes = latestSession
      ? Object.values(latestSession.totals ?? {}).reduce((m: number, n) => m + (typeof n === "number" ? n : 0), 0)
      : 0;
    const times = [
      party.updated_at,
      latestSession?.updated_at,
      latestSession?.started_at,
      reports[0]?.submitted_at,
      s.stations[s.stations.length - 1]?.created_at,
    ].filter((x): x is string => !!x);
    const lastActivity = times.length ? [...times].sort().pop()! : null;
    return {
      completedPct: reports.length ? Math.round((completed / reports.length) * 100) : 0,
      completed,
      lastVotes,
      lastActivity,
      lastReport: reports[0] ?? null,
    };
  }, [stats.data, party.updated_at]);

  const description = typeof party.profile?.description === "string" ? party.profile.description : null;

  return (
    <Modal open onClose={onClose} title={`تفاصيل الحزب: ${party.name_ar}`} wide>
      <div className="space-y-4">
        {stats.error && <ErrorBox message={stats.error} onRetry={stats.reload} />}

        <Card>
          <div className="flex flex-wrap items-start gap-4">
            <div className="relative shrink-0">
              {logo ? (
                <img src={logo} alt="" className="h-16 w-16 rounded-2xl border border-slate-700 object-cover shadow-lg shadow-black/30" />
              ) : (
                <div className="flex h-16 w-16 items-center justify-center rounded-2xl text-2xl font-bold text-white"
                  style={{ background: party.colors?.primary ?? "#0f766e" }}>
                  {party.name_ar.slice(0, 1)}
                </div>
              )}
              <button type="button" disabled={logoBusy} onClick={() => logoFileRef.current?.click()}
                title="تغيير شعار الحزب"
                className="absolute -bottom-1.5 -end-1.5 rounded-full bg-teal-600 p-1.5 text-xs text-white shadow transition hover:bg-teal-500 disabled:opacity-50">
                {logoBusy ? "…" : "📷"}
              </button>
              <input ref={logoFileRef} type="file" accept="image/*" className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) changeLogo(f); e.target.value = ""; }} />
            </div>
            <div className="min-w-0 flex-1 text-sm">
              <div className="flex flex-wrap items-center gap-2">
                <h4 className="text-base font-bold">{party.name_ar}</h4>
                {party.name_fr && <span className="text-sm text-slate-400">({party.name_fr})</span>}
                <Badge tone={statusTone(party.status)}>
                  {party.status === "active" ? "Active" : party.status === "suspended" ? "Suspended" : "Pending"}
                </Badge>
              </div>
              <p className="mt-1 text-slate-400">{description ?? "لا يوجد وصف لهذا الحزب"}</p>
              <p className="mt-1 text-xs text-slate-500">
                <span dir="ltr">{party.slug}</span>
                {" — "}تاريخ الإنشاء: {new Date(party.created_at).toLocaleDateString("ar")}
              </p>
            </div>
          </div>
        </Card>

        {stats.loading ? (
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-24" />)}
          </div>
        ) : stats.data && d ? (
          <>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              <StatCard label="المساعدون" value={stats.data.assistants.length} icon="🧑‍🤝‍🧑" tone="blue" />
              <StatCard label="المراقبون" value={stats.data.observers.length} icon="👁" tone="blue" />
              <StatCard label="مكاتب الاقتراع" value={stats.data.stations.length} icon="🗳" />
              <StatCard label="التقارير المرسلة" value={stats.data.reports.length} icon="📄" tone="violet" />
              <StatCard label="نسبة التقارير المكتملة" value={`${d.completedPct}%`}
                hint={`${d.completed} مراجَع من أصل ${stats.data.reports.length}`}
                tone={d.completedPct >= 50 ? "green" : "amber"} />
              <StatCard label="عدد الأصوات الأخيرة" value={d.lastVotes}
                hint={d.lastVotes > 0 ? "مجموع أحدث جلسة فرز" : "لا توجد جلسات فرز"} tone="green" />
              <StatCard label="آخر نشاط" value={d.lastActivity ? timeAgo(d.lastActivity, "ar") : "لا يوجد"} tone="amber" />
              <StatCard label="آخر تقرير" value={d.lastReport ? timeAgo(d.lastReport.submitted_at, "ar") : "لا يوجد"}
                hint={d.lastReport ? `النوع: ${d.lastReport.kind}` : ""} tone="violet" />
            </div>
            <DomainsCard partyId={party.id} domains={stats.data.domains} partyStatus={party.status}
              onChanged={() => { stats.reload(); onChanged(); }} />
          </>
        ) : null}
      </div>
    </Modal>
  );
}

// ---------------------------------------------------------------------------
// الدومينات + ربط دومين جديد
// ---------------------------------------------------------------------------
function DomainsCard({ partyId, domains, partyStatus, onChanged }: {
  partyId: string; domains: api.DomainRow[]; partyStatus: string; onChanged: () => void;
}) {
  const [open, setOpen] = useState(false);
  return (
    <Card>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <h4 className="font-bold">الدومينات ({domains.length})</h4>
        <Btn onClick={() => setOpen(true)}>🔗 ربط دومين الحزب</Btn>
      </div>
      {domains.length === 0 ? (
        <p className="text-sm text-slate-500">لا يوجد دومين مرتبط بهذا الحزب.</p>
      ) : (
        <div className="space-y-2">
          {domains.map((dm) => {
            const state = partyStatus === "suspended"
              ? { label: "Suspended", tone: "red" }
              : dm.verified_at
                ? { label: "Verified", tone: "green" }
                : dm.ssl_status === "failed"
                  ? { label: "Failed", tone: "red" }
                  : { label: "Pending", tone: "amber" };
            return (
              <div key={dm.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-slate-800/60 px-3 py-2 text-sm">
                <span dir="ltr" className="break-all">{dm.domain}</span>
                <div className="flex items-center gap-2">
                  <Badge tone={state.tone}>{state.label}</Badge>
                  {!dm.verified_at && (
                    <Btn variant="ghost" className="!px-3 !py-1 text-xs" onClick={async () => {
                      try {
                        const r = await api.verifyDomain(dm.id);
                        if (r && r.verified === false) alert(r.hint ?? "سجل TXT غير صحيح بعد");
                        onChanged();
                      } catch (e) { alert(e instanceof Error ? e.message : String(e)); }
                    }}>تحقق DNS</Btn>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
      <LinkDomainModal open={open} onClose={() => setOpen(false)} partyId={partyId} onLinked={onChanged} />
    </Card>
  );
}

function LinkDomainModal({ open, onClose, partyId, onLinked }: {
  open: boolean; onClose: () => void; partyId: string; onLinked: () => void;
}) {
  const [domain, setDomain] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const submit = async () => {
    const clean = domain.trim().toLowerCase();
    if (!clean) return setMsg({ ok: false, text: "الدومين فارغ — أدخل دوميناً صحيحاً" });
    if (!DOMAIN_RE.test(clean)) return setMsg({ ok: false, text: "صيغة الدومين غير صحيحة (مثال: parti.example.ma — بدون http/https)" });
    setBusy(true); setMsg(null);
    try {
      const row = await api.linkDomain(partyId, clean);
      let text = "تم ربط الدومين — حالته: Pending";
      try {
        const r = await api.verifyDomain(row.id);
        if (r && r.verified === true) text = "تم الربط والتحقق من الدومين بنجاح — حالته: Verified";
        else if (r && r.hint) text = `تم الربط (Pending). ${r.hint}`;
      } catch { /* التحقق اختياري بعد الربط */ }
      setMsg({ ok: true, text });
      onLinked(); // تحديث البيانات فوراً دون إعادة تحميل الصفحة
    } catch (e) {
      setMsg({ ok: false, text: e instanceof Error ? e.message : String(e) });
    } finally { setBusy(false); }
  };

  return (
    <Modal open={open} onClose={onClose} title="ربط دومين الحزب">
      <div className="space-y-3">
        <Field label="الدومين" hint="يُتحقق من الملكية عبر سجل TXT: _pollwatch.<domain>">
          <input dir="ltr" className={inputCls} value={domain}
            onChange={(e) => setDomain(e.target.value.replace(/^https?:\/\//, ""))}
            placeholder="parti.example.ma" onKeyDown={(e) => e.key === "Enter" && submit()} />
        </Field>
        {msg && <p className={`rounded-xl px-3 py-2 text-sm ${msg.ok ? "bg-green-950/60 text-green-300" : "bg-red-950/60 text-red-300"}`}>{msg.ok ? "✓ " : "⚠ "}{msg.text}</p>}
        <div className="flex justify-end gap-2">
          <Btn variant="ghost" onClick={onClose}>إغلاق</Btn>
          <Btn disabled={busy || !domain.trim()} onClick={submit}>{busy ? "جارٍ الربط…" : "ربط والتحقق"}</Btn>
        </div>
      </div>
    </Modal>
  );
}
