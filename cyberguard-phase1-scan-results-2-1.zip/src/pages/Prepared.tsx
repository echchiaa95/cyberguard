import { useI18n } from '../lib/i18n'

function PreparedPage({ titleKey, descKey }: { titleKey: string; descKey: string }) {
  const { t } = useI18n()
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">{t(titleKey)}</h1>
      <div className="card max-w-3xl p-8">
        <span className="badge border-sev-medium/40 bg-sev-medium/10 text-sev-medium">{t('prep.badge')}</span>
        <p className="mt-4 text-slate-300">{t(descKey)}</p>
      </div>
    </div>
  )
}

export const Applications = () => <PreparedPage titleKey="prep.applications.title" descKey="prep.applications.desc" />
export const Files = () => <PreparedPage titleKey="prep.files.title" descKey="prep.files.desc" />
export const Monitoring = () => <PreparedPage titleKey="prep.monitoring.title" descKey="prep.monitoring.desc" />
export const Reports = () => <PreparedPage titleKey="prep.reports.title" descKey="prep.reports.desc" />
export const Advisor = () => <PreparedPage titleKey="prep.advisor.title" descKey="prep.advisor.desc" />
