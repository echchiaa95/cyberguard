import { useEffect, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { useI18n } from "./lib/i18n";
import { supabase } from "./lib/supabase";
import { fetchObserverId, fetchUserRole } from "./lib/remote";
import type { Session } from "./lib/types";
import { Btn, Card } from "./shared/ui";
import SuperadminApp from "./features/superadmin/SuperadminApp";
import PartyApp from "./features/party/PartyApp";
import ObserverApp from "./features/observer/ObserverApp";

// ---------------------------------------------------------------------------
// شاشة تسجيل الدخول الوحيدة: Supabase Auth بالبريد وكلمة المرور.
// لا توجد حسابات تجريبية ولا أزرار دخول محلي.
// ---------------------------------------------------------------------------
function Login() {
  const { t } = useI18n();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const signIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    const { error: err } = await supabase.auth.signInWithPassword({ email, password });
    // عند النجاح: onAuthStateChange في App يبني الجلسة من الدور.
    // عند الفشل: نبقى هنا مع رسالة الخطأ.
    setBusy(false);
    if (err) setError(err.message);
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-brand-dark to-brand p-4">
      <Card className="w-full max-w-md">
        <div className="mb-6 text-center">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-brand text-2xl font-black text-white">P</div>
          <h1 className="text-xl font-bold">{t("app_title")}</h1>
        </div>

        <form onSubmit={signIn} className="space-y-3">
          <input
            type="email" required dir="ltr" placeholder="email@example.com" autoComplete="email"
            className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-brand dark:border-slate-700 dark:bg-slate-900"
            value={email} onChange={(e) => setEmail(e.target.value)}
          />
          <input
            type="password" required dir="ltr" placeholder="••••••••" autoComplete="current-password"
            className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-brand dark:border-slate-700 dark:bg-slate-900"
            value={password} onChange={(e) => setPassword(e.target.value)}
          />
          {error && <p className="text-xs text-red-600">{error}</p>}
          <Btn type="submit" disabled={busy} className="w-full">{busy ? "…" : t("login")}</Btn>
        </form>
      </Card>
    </div>
  );
}

// ---------------------------------------------------------------------------
// الجذر: استعادة الجلسة + تحميل الدور من party_members/roles + حماية الصفحات.
// لا جلسة → شاشة الدخول فقط. مصادق بلا دور نشط → ممنوع.
// ---------------------------------------------------------------------------
export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [forbidden, setForbidden] = useState(false);
  const { t, lang } = useI18n();

  // بناء جلسة التطبيق من مستخدم Supabase عبر الدور في party_members → roles
  const buildSession = async (user: User) => {
    try {
      const m = await fetchUserRole(user.id);
      if (!m) {
        // مصادَق عليه لكن بلا دور نشط في party_members → منع الدخول
        setForbidden(true);
        setSession(null);
        return;
      }
      const s: Session = { role: m.roleKey, partyId: m.partyId, memberName: m.fullName };
      if (m.roleKey === "observer") {
        s.observerId = (await fetchObserverId(user.id, m.partyId)) ?? undefined;
      }
      setForbidden(false);
      setSession(s);
    } catch {
      // فشل الشبكة/الاستعلام → معاملة كمنع مؤقت بأمان
      setForbidden(true);
      setSession(null);
    }
  };

  // استعادة الجلسة عند الإقلاع + الاستماع لتغيرات الحالة (دخول/خروج/انتهاء الرمز)
  useEffect(() => {
    let cancelled = false;
    supabase.auth.getSession().then(({ data }) => {
      if (cancelled) return;
      setAuthUser(data.session?.user ?? null);
      setAuthChecked(true);
      if (data.session?.user) buildSession(data.session.user);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => {
      setAuthUser(s?.user ?? null);
      setAuthChecked(true);
      if (s?.user) buildSession(s.user);
      else { setSession(null); setForbidden(false); }
    });
    return () => { cancelled = true; sub.subscription.unsubscribe(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const logout = (
    <Btn
      variant="ghost"
      onClick={async () => {
        setSession(null);
        await supabase.auth.signOut();
      }}
    >
      {t("logout")}
    </Btn>
  );

  // لم تُفحص الجلسة بعد (تفادي وميض شاشة الدخول)
  if (!authChecked) return <div className="flex min-h-screen items-center justify-center text-slate-400">…</div>;

  // لا جلسة → شاشة تسجيل الدخول فقط
  if (!authUser) return <Login />;

  // مصادَق عليه لكن بلا دور نشط → منع الدخول
  if (forbidden) {
    return (
      <div className="flex min-h-screen items-center justify-center p-4">
        <Card className="max-w-md text-center">
          <div className="mb-2 text-4xl">⛔</div>
          <h2 className="font-bold">{lang === "ar" ? "الدخول ممنوع" : "Accès refusé"}</h2>
          <p className="mt-2 text-sm text-slate-500">
            {lang === "ar"
              ? "هذا الحساب بلا دور نشط. تواصل مع المدير المركزي لمنحك صلاحية."
              : "Compte sans rôle actif. Contactez le superadmin."}
          </p>
          <div className="mt-4">{logout}</div>
        </Card>
      </div>
    );
  }

  // جلسة جارية — حماية الصفحات حسب الدور
  if (session?.role === "superadmin") return <SuperadminApp logout={logout} />;
  if (session?.role === "party_admin" && session.partyId) return <PartyApp partyId={session.partyId} logout={logout} />;
  if (session?.role === "observer" && session.observerId) return <ObserverApp session={session} logout={logout} />;

  // دور موجود لكن ناقص بياناته (مراقب بلا تعيين مثلاً) — إعادة التحقق لاحقاً
  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <Card className="max-w-md text-center">
        <p className="text-sm text-slate-500">
          {lang === "ar" ? "الدور غير مكتمل (تعيين مكتب ناقص)." : "Rôle incomplet (affectation manquante)."}
        </p>
        <div className="mt-4">{logout}</div>
      </Card>
    </div>
  );
}
