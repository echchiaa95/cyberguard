/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      fontFamily: { sans: ["'Segoe UI'", "Tahoma", "system-ui", "sans-serif"] },
      colors: {
        brand: { DEFAULT: "#0f766e", dark: "#115e59", light: "#14b8a6" },
      },
    },
  },
  plugins: [],
};
