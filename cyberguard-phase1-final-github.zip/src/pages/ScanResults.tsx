import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import { useI18n } from '../lib/i18n'
import { ScoreRing } from '../components/ScoreRing'
import { SeverityBadge } from '../components/SeverityBadge'
import { getScanChecks, listScans } from '../services/db'
import type { CheckResult, ScanRecord } from '../types'
import { cn } from '../lib/utils'

type Filter = 'all' | 'critical' | 'high' | 'medium' | 'low' | 'passed'

const TABS: Filter[] = ['all', 'critical', 'high', 'medium', 'low', 'passed']

export function ScanResults() {
  const { scanId } = useParams()
  const { user } = useAuth()
  const { t, lang } = useI18n()
  const [record, setRecord] = useState<ScanRecord | null>(null)
  const [checks, setChecks] = useState<CheckResult[] | null>(null)
  const [filter, setFilter] = useState<Filter>('all')

  useEffect(() => {
    if (!user || !scanId) return
    let cancelled = false
    void (async () => {
      const scans = await listScans(user.id)
      const rec = scans.find((s) => s.id === scanId) ?? null
      if (cancelled) return
      setRecord(rec)
      if (rec && rec.status === 'completed') {
        const c = await getScanChecks(user.id, scanId)
        if (!cancelled) setChecks(c)
      }
    })()
    return () => { cancelled = true }
  }, [user, scanId])

  if (!record) return <p className="text-slate-400">{t('common.loading')}</p>

  if (record.status === 'failed') {
    return (
      <div className="card p-8 text-center">
        <p className="text-sev-critical">{t('scan.failed')}</p>
        {record.errorMessage && <p className="mt-2 text-sm text-slate-500">{t(record.errorMessage)}</p>}
      </div>
    )
  }
  if (record.status === 'running' || checks === null) {
    return <div className="card p-8 text-center"><p className="text-slate-400">{t('scan.running')}</p></div>
  }

  const visible = filter === 'all'
    ? checks.filter((c) => c.status !== 'pass')
    : filter === 'passed'
      ? checks.filter((c) => c.status === 'pass')
      : checks.filter((c) => c.severity === filter && c.status !== 'pass')

  return (
    <div className="space-y-6">
      <div>
        <Link to={record.websiteId ? `/app/websites/${record.websiteId}` : '/app/websites'} className="text-sm text-brand-400">
          ← {t('common.back')}
        </Link>
        <h1 className="mt-2 text-2xl font-bold text-white">{t('scan.results.title')}</h1>
        <p className="mt-1 break-all text-sm text-slate-500">
          {t('scan.target')}: <b className="text-slate-300">{record.target}</b> · {t('scan.date')}: {new Date(record.createdAt).toLocaleString(lang)}
        </p>
      </div>

      <div className="flex flex-wrap items-center gap-6">
        <ScoreRing score={record.securityScore ?? 0} label={t('dash.securityScore')} />
        <ScoreRing score={record.privacyScore ?? 0} label={t('dash.privacyScore')} />
        <div>
          <p className="text-sm text-slate-400">{t('common.riskLevel')}</p>
          {record.riskLevel && <SeverityBadge severity={record.riskLevel} />}
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {TABS.map((tab) => (
          <button key={tab} onClick={() => setFilter(tab)}
            className={cn('rounded-full px-4 py-1.5 text-sm font-medium transition',
              filter === tab ? 'bg-brand-600 text-white' : 'bg-surface-800 text-slate-400 hover:bg-surface-700')}>
            {tab === 'all' ? t('scan.filter.all')
              : tab === 'passed' ? t('common.passed')
              : t(`common.${tab}`)}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {visible.length === 0 && <div className="card p-6 text-sm text-slate-500">{t('scan.noFindings')}</div>}
        {visible.map((c) => (
          <details key={c.checkId} className="card group">
            <summary className="flex cursor-pointer list-none items-center gap-3 p-4 [&::-webkit-details-marker]:hidden">
              <SeverityBadge severity={c.severity} />
              <span className="flex-1 text-sm font-medium text-slate-100">{c.title}</span>
              <span className={cn('badge', c.status === 'pass'
                ? 'border-sev-passed/30 bg-sev-passed/10 text-sev-passed'
                : c.status === 'warn'
                  ? 'border-sev-medium/30 bg-sev-medium/10 text-sev-medium'
                  : c.status === 'fail'
                    ? 'border-sev-high/30 bg-sev-high/10 text-sev-high'
                    : 'border-surface-600 bg-surface-800 text-slate-400')}>
                {t(`scan.status.${c.status}`)}
              </span>
            </summary>
            <div className="space-y-4 border-t border-surface-800 p-4 text-sm">
              {([
                ['scan.field.evidence', c.evidence],
                ['scan.field.description', c.description],
                ['scan.field.impact', c.impact],
                ['scan.field.recommendation', c.recommendation],
                ['scan.field.remediation', c.remediation],
              ] as const).map(([k, v]) => (
                <div key={k}>
                  <p className="mb-1 font-semibold text-slate-300">{t(k)}</p>
                  <p className="whitespace-pre-wrap break-words rounded-xl bg-surface-850 p-3 font-mono text-xs text-slate-400">{v}</p>
                </div>
              ))}
            </div>
          </details>
        ))}
      </div>
    </div>
  )
}
