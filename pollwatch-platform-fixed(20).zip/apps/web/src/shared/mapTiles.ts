import L from "leaflet";

// ============================================================================
// بلاطات الخريطة: OpenStreetMap مباشرة
// - مجاني بالكامل وبدون API Key (CartoDB أصبح يتطلب مفتاحاً ويعرض علامة مائية)
// - يعرض البنايات والتفاصيل الكاملة عند التكبير
// ============================================================================

const OSM = "https://tile.openstreetmap.org/{z}/{x}/{y}.png";

export function addMapTiles(map: L.Map): L.TileLayer {
  const osm = L.tileLayer(OSM, {
    attribution: "© OpenStreetMap contributors",
    maxZoom: 19,
  });
  osm.addTo(map);
  return osm;
}
