// ============================================================================
// Edge Function: request-erasure
// حق النسيان (Law 09-08): حذف/تنكيه بيانات شخصية لمراقب أو مساعد.
// POST { observer_id? , assistant_id? } — المطلوب هو صاحب البيانات أو party_admin.
// يحذف المواقع، يفرّغ الحقول الشخصية، ويبقي السجلات المجمّعة مجهولة الهوية.
// ============================================================================
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, content-type" };

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );
    const { data: userData } = await supabase.auth.getUser();
    const user = userData.user;
    if (!user) return json({ error: "unauthorized" }, 401);

    const { observer_id, assistant_id } = await req.json();
    if (!observer_id && !assistant_id) return json({ error: "target required" }, 400);

    // صلاحية: صاحب البيانات أو party_admin لنفس الحزب
    const { data: me } = await supabase
      .from("party_members")
      .select("party_id, role:roles(key)")
      .eq("user_id", user.id)
      .single();
    const role = (me?.role as unknown as { key: string } | null)?.key;

    if (observer_id) {
      const { data: target } = await supabase.from("observers").select("user_id, party_id").eq("id", observer_id).single();
      if (!target) return json({ error: "not_found" }, 404);
      const isOwner = target.user_id === user.id;
      const isAdmin = role === "party_admin" && target.party_id === me?.party_id;
      if (!isOwner && !isAdmin && role !== "superadmin") return json({ error: "forbidden" }, 403);

      await supabase.from("observer_locations").delete().eq("observer_id", observer_id);
      await supabase.from("observer_assignments").delete().eq("observer_id", observer_id);
      await supabase.from("observers").update({
        full_name: "[محذوف]", phone: null, national_id: null, user_id: null, status: "inactive",
      }).eq("id", observer_id);
      // الجلسات والإدخالات تبقى مجهولة (لا تحمل اسمًا) — مطابقة لسياسة الاحتفاظ
      await supabase.rpc("log_audit", {
        p_action: "observer.erasure", p_entity: "observers", p_entity_id: observer_id, p_metadata: {},
      });
      return json({ erased: "observer" });
    }

    const { data: target } = await supabase.from("assistants").select("party_id").eq("id", assistant_id!).single();
    if (!target) return json({ error: "not_found" }, 404);
    const isAdmin = role === "party_admin" && target.party_id === me?.party_id;
    if (!isAdmin && role !== "superadmin") return json({ error: "forbidden" }, 403);

    await supabase.from("assistants").delete().eq("id", assistant_id!);
    await supabase.rpc("log_audit", {
      p_action: "assistant.erasure", p_entity: "assistants", p_entity_id: assistant_id, p_metadata: {},
    });
    return json({ erased: "assistant" });
  } catch (e) {
    return json({ error: String(e) }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
}
