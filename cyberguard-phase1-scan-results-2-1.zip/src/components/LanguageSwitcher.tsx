import { useI18n } from '../lib/i18n'
import type { Language } from '../types'

const LANGS: { code: Language; label: string }[] = [
  { code: 'en', label: 'English' },
  { code: 'fr', label: 'Français' },
  { code: 'ar', label: 'العربية' },
]

export function LanguageSwitcher() {
  const { lang, setLang } = useI18n()
  return (
    <select
      value={lang}
      onChange={(e) => setLang(e.target.value as Language)}
      className="input !w-auto !py-1.5 text-xs"
      aria-label="Language"
    >
      {LANGS.map((l) => <option key={l.code} value={l.code}>{l.label}</option>)}
    </select>
  )
}
