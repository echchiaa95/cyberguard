import { useState } from 'react'
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import { useI18n } from '../lib/i18n'
import { Logo } from './Logo'
import { LanguageSwitcher } from './LanguageSwitcher'
import { CyberBackground, type AtmoVariant } from './CyberBackground'
import { cn } from '../lib/utils'

const NAV = [
  { to: '/app', key: 'nav.dashboard', end: true },
  { to: '/app/websites', key: 'nav.websites' },
  { to: '/app/applications', key: 'nav.applications' },
  { to: '/app/files', key: 'nav.files' },
  { to: '/app/reports', key: 'nav.reports' },
  { to: '/app/monitoring', key: 'nav.monitoring' },
  { to: '/app/history', key: 'nav.history' },
  { to: '/app/advisor', key: 'nav.advisor' },
  { to: '/app/pricing', key: 'nav.pricing' },
  { to: '/app/account', key: 'nav.account' },
  { to: '/app/settings', key: 'nav.settings' },
]

export function Layout() {
  const { t } = useI18n()
  const { user, isDemo, signOut } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [open, setOpen] = useState(false)

  // Atmosphere variant follows the section — visual only, no logic change.
  const variant: AtmoVariant = location.pathname.startsWith('/app/scans')
    ? 'radar'
    : location.pathname === '/app'
      ? 'soc'
      : 'default'

  const linkCls = ({ isActive }: { isActive: boolean }) =>
    cn('block rounded-xl px-4 py-2.5 text-sm font-medium transition',
      isActive ? 'bg-brand-600/15 text-brand-400' : 'text-slate-400 hover:bg-surface-800 hover:text-slate-200')

  const sidebar = (
    <nav className="flex h-full flex-col gap-1 overflow-y-auto p-4">
      <div className="mb-4 flex items-center gap-2 px-2">
        <Logo size={28} />
        <span className="font-bold text-slate-100">{t('app.name')}</span>
      </div>
      {NAV.map((n) => (
        <NavLink key={n.to} to={n.to} end={n.end} className={linkCls} onClick={() => setOpen(false)}>
          {t(n.key)}
        </NavLink>
      ))}
      <div className="mt-auto pt-4">
        <button
          className="btn-secondary w-full"
          onClick={async () => { await signOut(); navigate('/') }}
        >
          {t('nav.logout')}
        </button>
      </div>
    </nav>
  )

  return (
    <div className="relative flex min-h-screen">
      <CyberBackground variant={variant} />
      <aside className="fixed inset-y-0 z-20 hidden w-64 border-e border-surface-800 bg-surface-900/60 backdrop-blur lg:block">
        {sidebar}
      </aside>
      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/60" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 w-64 bg-surface-900">{sidebar}</aside>
        </div>
      )}
      <div className="relative z-10 flex min-w-0 flex-1 flex-col lg:ms-64">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-surface-800 bg-surface-950/70 px-4 py-3 backdrop-blur lg:px-8">
          <button className="btn-secondary !px-3 lg:hidden" onClick={() => setOpen(true)} aria-label="Menu">☰</button>
          <div className="min-w-0 flex-1">
            {isDemo && (
              <span className="badge border-sev-medium/40 bg-sev-medium/10 text-sev-medium">
                {t('app.demoBadge')}
              </span>
            )}
          </div>
          <LanguageSwitcher />
          <span className="hidden max-w-[12rem] truncate text-xs text-slate-500 sm:block">{user?.email}</span>
        </header>
        <main className="mx-auto w-full max-w-6xl flex-1 p-4 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
