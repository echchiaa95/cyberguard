// CyberGuard passive website scanner (Supabase Edge Function, Deno runtime).
// Performs only non-destructive, unauthenticated, read-only analysis:
// HTTP(S) headers, cookies, redirect behavior, basic HTML resource inventory,
// and DNS records via DNS-over-HTTPS. No exploit attempts, no intrusive testing.
//
// Deploy: supabase functions deploy scan-website
// Requires: VITE_SUPABASE_URL + anon key (JWT verified per config.toml)

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type',
}

interface ScanRequest { url: string }

function normalizeUrl(input: string): URL | null {
  try {
    const withScheme = /^https?:\/\//i.test(input) ? input : `https://${input}`
    const url = new URL(withScheme)
    if (url.protocol !== 'https:' && url.protocol !== 'http:') return null
    if (!url.hostname.includes('.')) return null
    return url
  } catch {
    return null
  }
}

// Block requests to private/loopback/link-local ranges (SSRF protection)
function isPrivateHost(hostname: string): boolean {
  const h = hostname.toLowerCase().replace(/^\[|\]$/g, '')
  const isV6 = h.includes(':')
  if (h === 'localhost' || h.endsWith('.local') || h === '0.0.0.0' || h === '::' || h === '::1') return true
  if (isV6 && (h.startsWith('fe80:') || h.startsWith('fc') || h.startsWith('fd'))) return true
  const m = h.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/)
  if (!m) return false
  const [a, b] = [Number(m[1]), Number(m[2])]
  return a === 10 || a === 127 || (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) || (a === 169 && b === 254) || a === 0
}

async function fetchWithTimeout(url: string, init: RequestInit, ms = 15000): Promise<Response> {
  const controller = new AbortController()
  const t = setTimeout(() => controller.abort(), ms)
  try {
    return await fetch(url, { ...init, signal: controller.signal })
  } finally {
    clearTimeout(t)
  }
}

const MAX_REDIRECTS = 3
const BODY_LIMIT = 512 * 1024 // never buffer unbounded HTML into memory

/**
 * Fetches the target following redirects MANUALLY: every hop is re-validated
 * against isPrivateHost so a public URL cannot redirect to internal infrastructure.
 */
async function fetchTarget(start: URL): Promise<{ res: Response; finalUrl: string }> {
  let current = start
  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    if (isPrivateHost(current.hostname)) throw new Error('blocked target')
    const res = await fetchWithTimeout(current.toString(), {
      method: 'GET',
      redirect: 'manual',
      headers: { 'user-agent': 'CyberGuardPassiveScanner/0.1 (+https://cyberguard.example)' },
    })
    if (res.status >= 300 && res.status < 400) {
      const location = res.headers.get('location')
      if (!location) return { res, finalUrl: current.toString() }
      const next = new URL(location, current)
      if (next.protocol !== 'https:' && next.protocol !== 'http:') throw new Error('blocked redirect')
      current = next
      continue
    }
    return { res, finalUrl: current.toString() }
  }
  throw new Error('too many redirects')
}

/** Stream-reads at most `limit` bytes — response bodies are never loaded whole. */
async function readBodyCapped(res: Response, limit = BODY_LIMIT): Promise<string> {
  if (!res.body) return ''
  const reader = res.body.getReader()
  const decoder = new TextDecoder()
  let out = ''
  try {
    for (;;) {
      const { done, value } = await reader.read()
      if (done) break
      out += decoder.decode(value, { stream: true })
      if (out.length >= limit) {
        out = out.slice(0, limit)
        break
      }
    }
  } finally {
    try { await reader.cancel() } catch { /* connection already closed */ }
  }
  return out
}

async function resolveDns(hostname: string) {
  const records: Record<string, unknown> = { hostname }
  try {
    const res = await fetchWithTimeout(
      `https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(hostname)}&type=A`,
      { headers: { accept: 'application/dns-json' }, redirect: 'error' },
      8000
    )
    const data = await res.json()
    records.a = (data.Answer ?? [])
      .filter((a: { type: number }) => a.type === 1)
      .map((a: { data: string }) => a.data)
  } catch {
    records.a = []
  }
  return records
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    // Authenticate the caller (anon JWT is fine; user must be logged in)
    const authHeader = req.headers.get('Authorization') ?? ''
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    )
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError || !user) {
      return json({ error: 'Authentication required.' }, 401)
    }

    const { url: raw } = (await req.json()) as ScanRequest
    const target = normalizeUrl(String(raw ?? ''))
    if (!target) return json({ error: 'Invalid URL. Please verify the URL.' }, 400)
    if (isPrivateHost(target.hostname)) {
      return json({ error: 'This address cannot be scanned.' }, 400)
    }

    let finalUrl = target.toString()
    let html = ''
    const headers: Record<string, string> = {}
    let status = 0
    const cookies: string[] = []

    try {
      const fetched = await fetchTarget(target)
      finalUrl = fetched.finalUrl
      const res = fetched.res
      status = res.status
      res.headers.forEach((value, key) => {
        headers[key] = value
        if (key === 'set-cookie') cookies.push(value)
      })
      html = await readBodyCapped(res)
    } catch {
      return json({ error: 'Unable to reach this website. Please verify the URL.' }, 502)
    }

    // Resource inventory from HTML (scripts, iframes, images, links)
    const resources = {
      scripts: [...html.matchAll(/<script[^>]+src=["']([^"']+)["']/gi)].map((m) => m[1]).slice(0, 100),
      iframes: [...html.matchAll(/<iframe[^>]+src=["']([^"']+)["']/gi)].map((m) => m[1]).slice(0, 50),
      images: [...html.matchAll(/<img[^>]+src=["']([^"']+)["']/gi)].map((m) => m[1]).slice(0, 100),
      styles: [...html.matchAll(/<link[^>]+href=["']([^"']+\.css[^"']*)["']/gi)].map((m) => m[1]).slice(0, 50),
      preconnects: [...html.matchAll(/<link[^>]+href=["']([^"']+)["'][^>]*rel=["']preconnect["']/gi)].map((m) => m[1]).slice(0, 50),
      pixels: [...html.matchAll(/<(img|script)[^>]+src=["']([^"']*(?:pixel|beacon|collect|analytics|track)[^"']*)["']/gi)].map((m) => m[2]).slice(0, 50),
    }
    const generator = (html.match(/<meta[^>]+name=["']generator["'][^>]+content=["']([^"']+)["']/i) ?? [])[1] ?? null

    const dns = await resolveDns(target.hostname)

    return json({
      url: finalUrl,
      finalUrl,
      status,
      headers,
      cookies,
      resources,
      generator,
      htmlLength: html.length,
      dns,
      scannedAt: new Date().toISOString(),
    })
  } catch {
    return json({ error: 'Scan temporarily unavailable.' }, 500)
  }
})

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
}
